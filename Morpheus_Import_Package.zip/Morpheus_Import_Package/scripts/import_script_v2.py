import requests
import json
import os
import logging
import sys
import re
from requests.auth import HTTPBasicAuth
#from cryptography.fernet import Fernet

# Default log level is ERROR
log_level = logging.ERROR

# Add a command-line argument to enable different log levels
if "--info" in sys.argv:
    log_level = logging.INFO
    sys.argv.remove("--info")
elif "--debug" in sys.argv:
    log_level = logging.DEBUG
    sys.argv.remove("--debug")
elif "--warning" in sys.argv:
    log_level = logging.WARNING
    sys.argv.remove("--warning")

# Define a custom log format for DEBUG level that includes the line number
log_format_debug = "%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"

# Configure the logging module
logging.basicConfig(level=log_level, format=log_format_debug if log_level == logging.DEBUG else "%(asctime)s - %(levelname)s - %(message)s")

# Load Morpheus Configuration

config_path = os.path.join(os.path.dirname(__file__), '..', 'config.json')
with open(config_path, 'r') as config_file:
    config = json.load(config_file)
"""
# Load the encryption key
key_path = os.path.join(os.path.dirname(__file__), 'vault.key')
with open(key_path, 'rb') as key_file:
    key = key_file.read()

# Decrypt the credentials
enc_path = os.path.join(os.path.dirname(__file__), 'vault.enc')
with open(enc_path, 'rb') as enc_file:
    encrypted_data = enc_file.read()

cipher = Fernet(key)
config = json.loads(cipher.decrypt(encrypted_data).decode())
"""
# Extract Morpheus configuration from the decrypted data
morpheus_url = config['morpheus_url']
username = config['username']
password = config['password']
client_id = config['client_id']
client_secret = config['client_secret']

# Disable SSL warnings for testing purposes
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

def Authenticate():
    """
    Authenticates with the Morpheus API and retrieves an access token.

    Returns:
        str: The access token for API authentication.

    Rasies:
        requests.exceptions.HTTPError: If the authentication request fails.
    """
    logging.debug("Entering Authenticate method and Starting authentication process...")
    auth_data = {
        'grant_type': 'password',
        'username': username,
        'password': password,
        'scope': 'write'
    }
    try:
        # Authenticate and get the access token using Basic Auth
        auth_response = requests.post(
            f'{morpheus_url}/oauth/token',
            data=auth_data,
            auth=HTTPBasicAuth(client_id, client_secret),
            verify=False  # Disable SSL verification for testing
        )
        logging.debug("Authentication request sent. Awaiting response...")
        auth_response.raise_for_status()
        access_token = auth_response.json()['access_token']
        logging.debug(f"Access token obtained: {access_token}")
        logging.debug("Exiting Authenticate method with access token.")
        return access_token
    except requests.exceptions.HTTPError as err:
        logging.error(f"Authentication failed: {err}")
        logging.error(f"Response content: {auth_response.content.decode('utf-8')}")
        print("Error: Authentication failed. Please check your credentials and configuration.")
        sys.exit(1)

def list_workflows():
    """
    List available workflows in the 'import' directory.

    Returns:
        list: A list of workflow names available for import.

    Raises:
        FileNotFoundError: If the 'import' directory does not exist.
    """
    logging.debug("Entering list_workflows method...")
    import_dir = os.path.join(os.path.dirname(__file__), '..', 'import')
    logging.debug(f"Import directory path: {import_dir}")

    if not os.path.exists(import_dir):
        logging.error("The 'import' directory does not exist at path: {import_dir}")
        raise FileNotFoundError(f"The 'import' directory does not exist at path: {import_dir}")

    workflows = [name for name in os.listdir(import_dir) if os.path.isdir(os.path.join(import_dir, name))]
    logging.debug(f"Workflows found in the 'import' directory: {workflows}")
    logging.debug("Exiting list_workflows method with workflows.")
    return workflows

def clean_field_name(field_name):
    """
    Cleans the field name by removing leading and trailing whitespace and converting to lowercase.

    Args:
        field_name (str): The field name to clean.

    Returns:
        str: The cleaned field name.
    """
    if not field_name:
        return ""
    cleaned_field_name = re.sub(r'\s+', '', field_name).strip().lower()
    if ' ' in field_name or field_name != cleaned_field_name:
        logging.error(f"Field name '{field_name}' is invalid. It should be lowercase and have no spaces. "
                      f"Cleaned version: '{cleaned_field_name}'")
    return cleaned_field_name

def clean_description(description):
    """
    Cleans the description text by removing leading and trailing whitespace.

    Args:
        text (str): The description text to clean.

    Returns:
        str: The cleaned description text.
    """
    if not description:
        return ""
    return description.strip()

def sanitize_name(name):
    """
    Sanitizes the name by removing leading and trailing whitespace.
    Preserves the original case and internal spaces.

    Args:
        name (str): The name to sanitize.

    Returns:
        str: The sanitized name.
    """
    if not name:
        return ""
    return name.strip()

def fetch_paginated_data(base_url, headers, resource_key, params=None, max_records=100, sort_field=None, sort_direction=None):
    """
    Fetches all records from a paginated API endpoint.

    Args:
        base_url (str): The base URL of the API endpoint.
        headers (dict): The headers for the API request.
        resource_key (str): The key in the API response that contains the list of records (e.g., 'tasks', 'optionTypeLists').
        params (dict): Additional parameters for the API request.
        max_records (int): The maximum number of records per page (default is 100).
        sort_field (str, optional): The field to sort the records by.
        sort_direction (str, optional): The direction to sort the records ('asc' or 'desc').

    Returns:
        list: A combined list of all records fetched from the API.

    Raises:
        Exception: If there is an issue with the API request or response
    """
    logging.info(f"Fetching data from '{base_url}' with resource key '{resource_key}'...")
    if params is None:
        params = {}
    all_records = []
    current_offset = 0
    total_records_fetched = 0
    total_available_records = None # we'll get this from the API response

    try:
        while True:
            params.update({'offset': current_offset, 'max': max_records})
            if sort_field and sort_direction:
                params.update({'sort': sort_field, 'direction': sort_direction})

            logging.debug(f"Fetching data from '{base_url}' with params: '{params}'...")
            response = requests.get(base_url, headers=headers, params=params, verify=False)
            response.raise_for_status()
            data = response.json()

            # Combine records from the current page
            current_records = data.get(resource_key, [])
            num_current_records = len(current_records)
            logging.debug(f"Number of records fetched for current request (offset={current_offset}): {num_current_records}")
            all_records.extend(current_records)
            total_records_fetched += num_current_records

            # check if all records are fetched
            meta = data.get('meta', {})
            logging.debug(f"Pagination Meta information: {json.dumps(meta, indent=4)}")
            if not meta:
                logging.warning(f"No 'meta' key found in the response for offset {current_offset}. Assuming last page.")
                break # exit the loop if no meta information is available

            # Get total from meta if not already known (from the first request)
            if total_available_records is None:
                total_available_records = meta.get('total')
                if total_available_records is None:
                    raise Exception("Error: 'total' key missing in API response meta for the first page.")
                logging.debug(f"Total records available reported by API: {total_available_records}")

            # Prepare for the next request
            current_offset += num_current_records

            # check if all records are fetched
            if total_records_fetched >= total_available_records:
                logging.debug(f"All {total_available_records} records fetched across {len(all_records) // max_records + (1 if len(all_records) % max_records > 0 else 0)} pages (actual requests).")
                break

        logging.debug(f"Total records fetched: {len(all_records)}")
        return all_records

    except requests.exceptions.RequestException as e:
        error_message = (
            f"Error: Unable to fetch data from the API endpoint '{base_url}'. "
            "Please check your network connection, ensure the API is reachable, and verify your authentication credentials. "
            "Restart the script after resolving the issue."
        )
        logging.error(error_message)
        logging.error(f"Details: {e}")
        raise Exception(error_message)

    except KeyError as e:
        error_message = (
            f"Error: Unexpected response structure from the API. Missing key '{e}'. "
            "Please ensure the API response format matches the expected structure. "
            "Contact support if the issue persists."
        )
        logging.error(error_message)
        logging.error(f"Response content: {response.text}")
        raise Exception(error_message)

    except Exception as e:
        error_message = (
            "Error: An unexpected error occurred while fetching data. "
            "Please contact support with the following details."
        )
        logging.error(error_message)
        logging.error(f"Detailed error: {e}")
        raise Exception(error_message)


def import_option_list(option_list_name, workflow_name, access_token):
    """
    Imports an option list into the target instance.

    Args:
        option_list_name (str): The name of the option list to import.
        workflow_name (str): The name of the workflow associated with the option list.
        access_token (str): The access token for authentication API requests.

    Returns:
        tuple: ("REUSE", message), ("CREATED", message), or ("ERROR", message)
    """
    logging.debug(f"Entering import_option_list method for option list: {option_list_name} and workflow: {workflow_name}")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    import_path = os.path.join(os.path.dirname(__file__), '..', 'import', workflow_name, 'options', f'option_list_{option_list_name}_import.json')
    logging.debug(f"Constructed import path for option list: {import_path}")

    # Check if the import path exists
    if not os.path.exists(import_path):
        error = (
            f"Error: Import file not found for option list '{option_list_name}'.\n"
            f"Expected at: {import_path}\n"
            "Please ensure the file exists and retry the import process."
        )
        return "ERROR", error

    # Load option list data from JSON file
    logging.debug(f"Loading option list data from file: {import_path}")
    with open(import_path, 'r') as json_file:
        option_list_data = json.load(json_file)
    logging.debug(f"Loaded option list data: {json.dumps(option_list_data, indent=4)}")

    # Fetch existing option lists
    logging.debug("Fetching existing option lists from the target instance...")
    existing_option_lists = fetch_paginated_data(
        f'{morpheus_url}/api/library/option-type-lists',
        headers,
        resource_key='optionTypeLists',
    )
    logging.info(f"Total existing option lists fetched: {len(existing_option_lists)}")
    logging.debug(f"Fetched existing option lists: {json.dumps(existing_option_lists, indent=4)}")

    # Check if the option list already exists
    logging.debug(f"Checking if option list '{option_list_name}' already exists...")
    existing_option_list = next((ol for ol in existing_option_lists if ol['name'].strip().lower() == option_list_name.strip().lower()), None)

    if existing_option_list:
        # Reuse the existing option list
        message = (
            f"REUSE: Option list '{option_list_name}' matches existing. Reusing it with ID '{existing_option_list['id']}'."
        )
        return "REUSE", message
    else:
        # Create a new option list
        logging.debug(f"Option list '{option_list_name}' does not exist. Creating a new option list...")
        try:
            response = requests.post(f'{morpheus_url}/api/library/option-type-lists', headers=headers, json=option_list_data, verify=False)
            response.raise_for_status()
            new_option_list_id = response.json()['optionTypeList']['id']
            message = (
                f"CREATED: Option list '{option_list_name}' created successfully with ID '{new_option_list_id}'."
            )
            return "CREATED", message
        except requests.exceptions.HTTPError as err:
            error = (
                f"Error: Failed to import option list '{option_list_name}'.\n"
                f"HTTP Error: {err}\n"
                f"Response: {response.content.decode('utf-8')}"
            )
            return "ERROR", error

def import_input_parameter(input_parameter_name, context_name, access_token, context_type="workflow"):
    """
    Imports an input parameter into the target instance.

    Args:
        input_parameter_name (str): The name of the input parameter to import.
        context_name (str): The name of the workflow or layout associated with the input parameter.
        access_token (str): The access token for authentication API requests.
        context_type (str): Either "workflow" or "layout" for proper path resolution.

    Returns:
        tuple: ("REUSE", message), ("CREATED", message), or ("ERROR", message)

    Raises:
        Exception: If the input parameter fails to import.
    """
    logging.debug(f"Entering  import_input_parameter method for input parameter: '{input_parameter_name}' and {context_type}: '{context_name}'")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    # Step 1: Load the input parameter JSON file
    if context_type == "layout":
        import_path = os.path.join(os.path.dirname(__file__), '..', 'import', 'layouts', context_name, 'input_parameters', f'input_parameter_{input_parameter_name}_import.json')
    else: # workflow context
        import_path = os.path.join(os.path.dirname(__file__), '..', 'import', context_name, 'input_parameters', f'input_parameter_{input_parameter_name}_import.json')
    logging.debug(f"Constructed import path for input parameter: {import_path}")

    if not os.path.exists(import_path):
        error = (
            f"Error: Import file not found for input parameter '{input_parameter_name}'. "
            f"Expected at: {import_path}\n"
            "Please ensure the file exists and retry."
        )
        return "ERROR", error

    # step 1: Load the input parameter data from the JSON file
    with open(import_path, 'r') as json_file:
        input_parameter_data = json.load(json_file)
    logging.debug(f"Loaded input parameter data: {json.dumps(input_parameter_data, indent=4)}")

    # Step 2: Validate the name, fieldName and description field for input parameter
    input_name = sanitize_name(input_parameter_data["optionType"]["name"])
    input_fieldname = clean_field_name(input_parameter_data["optionType"]["fieldName"])
    input_description = clean_description(input_parameter_data["optionType"].get("description", ""))
    logging.debug(f"Sanitized input parameter details: name='{input_name}', fieldName='{input_fieldname}', description='{input_description}'")

    # Step 2a: check if the description or the fieldName is missing or empty for an input parameter
    missing_fields = []
    if not input_description:
        missing_fields.append("description")
    if not input_fieldname:
        missing_fields.append("fieldName")

    if missing_fields:
        error = (
            f"Error: Missing or empty fields for input parameter '{input_parameter_name}'.\n"
            f"Ensure 'description' and 'fieldName' are provided in the imported JSON file: {', '.join(missing_fields)}.\n"
            "Please include these fields in the import file and retry the import process."
        )
        return "ERROR", error

    # Step 3: Fetch existing input parameters from the target instance
    logging.debug("Fetching existing input parameters from the target instance...")

    existing_input_parameters = fetch_paginated_data(
        f'{morpheus_url}/api/library/option-types',
        headers,
        resource_key='optionTypes',
    )
    logging.info(f"existing input parameters: {len(existing_input_parameters)}")
    logging.debug(f"Fetched existing input parameters: {json.dumps(existing_input_parameters, indent=4)}")

    # Step 4: find all with matching name
    matching_by_name = [ip for ip in existing_input_parameters if sanitize_name(ip['name']) == input_name]
    logging.debug(f"Matching option found: {json.dumps(matching_by_name, indent=4) if matching_by_name else 'None'}")
    #print(f"Debug-1: Matching input parameters by name: {len(matching_by_name)} for input name: '{input_name}'.") # debug purpose, delete later

    # step 4a: check for fieldName conflicts
    conflicting_fieldNames = [ip for ip in matching_by_name if clean_field_name(ip['fieldName']) != input_fieldname]
    if conflicting_fieldNames:
        # conflict: same name, different fieldName
        error = (
            f"[CONFLICT] Input Parameter Name: '{input_name}'\n"
            f" - Existing fieldNames in target instance: {[ip['fieldName'] for ip in conflicting_fieldNames]}\n"
            f" - fieldName in import file: '{input_fieldname}'\n"
            "These fieldNames do not match for the same input parameter name, which is not allowed in Morpheus.\n"
            "To resolve this conflict, please modify either the existing input parameter in Morpheus or the import file so that both the name and fieldName are identical, then retry the import."
        )
        return "ERROR", error

    #print(f"name and fieldname matched, till her no conflicts found for input name: '{input_name}'.") # debug purpose, delete later

    # Step 4b: check for description match among those with same name and fieldName
    matching_by_name_and_field = [
        ip for ip in matching_by_name if clean_field_name(ip['fieldName']) == input_fieldname
    ]
    logging.debug(f"Matching input parameters by name and fieldName: {json.dumps(matching_by_name_and_field, indent=4) if matching_by_name_and_field else 'None'}")
    #print(f"Debug-2: matched name and fieldName= {len(matching_by_name_and_field)} for input name: '{input_name}'.") # debug purpose, delete later

    # If any match with same description, REUSE
    for ip in matching_by_name_and_field:
        existing_description = clean_description(ip.get('description', ''))
        if existing_description == input_description:
            message = (
                f"REUSE: Input parameter '{input_name}' with fieldName '{input_fieldname}' and description '{input_description}' matches existing. Reusing it with ID '{ip['id']}'."
            )
            logging.info(message)
            return "REUSE", message

    # If no match with same description, allow versioning (create new)
    # But check if any of the existing have empty description (should not happen, but warn)
    for ip in matching_by_name_and_field:
        if not clean_description(ip.get('description', '')):
            error = (
                f"Error: Existing input parameter '{input_name}' with fieldName '{input_fieldname}' in Morpheus has an empty description.\n"
                f"Expected description: '{input_description}'\n"
                "Please update the description in Morpheus or rename the existing input parameter, then retry."
            )
            return "ERROR", error

    # Step 5: Resolve option list if it exists
    if "optionList" in input_parameter_data["optionType"] and input_parameter_data["optionType"]["optionList"] is not None:
        option_list_name = input_parameter_data["optionType"]["optionList"]["name"]
        logging.debug(f"Resolving option list for input parameter '{input_parameter_name}': {option_list_name}")

        # Use fetch_paginated_data to get all option lists
        existing_option_lists = fetch_paginated_data(
            f'{morpheus_url}/api/library/option-type-lists',
            headers,
            resource_key='optionTypeLists',
        )
        logging.info(f"Total existing option lists fetched: {len(existing_option_lists)}")
        # Find the matching option list by name
        option_list = next((ol for ol in existing_option_lists if ol['name'] == option_list_name), None)
        if option_list:
            input_parameter_data["optionType"]["optionList"]["id"] = option_list["id"]
            logging.debug(f"Resolved option list '{option_list_name}' with ID {option_list['id']} for input parameter '{input_parameter_name}'.")
        else:
            error = (
                f"Error: Option list '{option_list_name}' not found in Morpheus instance.\n "
                "Please import the required option list first, then retry the import of the input parameter."
            )
            return "ERROR", error
    # Step 6: Create the input parameter
    try:
        logging.debug(f"Creating input parameter: '{input_parameter_name}'")
        response = requests.post(
            f'{morpheus_url}/api/library/option-types',
            headers=headers,
            json=input_parameter_data,
            verify=False
        )
        response.raise_for_status()
        logging.debug(f"Exiting import_input_parameter function with Input parameter '{input_parameter_name}' created successfully.")
        message = (
            f"CREATED: Input parameter '{input_parameter_name}' with fieldName '{input_fieldname}' and description '{input_description}' created as new version."
        )
        return "CREATED", message
    except requests.exceptions.HTTPError as err:
        error = (
            f"Error: Failed to import input parameter '{input_parameter_name}'.\n"
            f"HTTP Error: {err}\n"
            f"Response: {response.content.decode('utf-8')}"
        )
        return "ERROR", error

def import_subworkflow(subworkflow_name, context_name, access_token, subworkflow_id_map, context_type="workflow"):
    """
    Imports a sub-workflow and its tasks into the target instance.

    Args:
        subworkflow_name (str): The name of the sub-workflow to import.
        context_name (str): The name of the main workflow or layout associated with the sub-workflow.
        access_token (str): The access token for authentication API requests.
        subworkflow_id_map (dict): A dictinoary to store sub-workflow names and their corresponding IDs in the target instance.
        context_type (str): Either "workflow" or "layout" for proper path resolution.

    Returns:
        tuple: ("SUCCESS", message) or ("ERROR", message)
    """
    try:
        # Determine the path based on context type
        if context_type == "layout":
            subworkflow_path = os.path.join(
                os.path.dirname(__file__), '..', 'import', 'layouts', context_name, 'subworkflows', subworkflow_name
            )
        else: # workflow context
            subworkflow_path = os.path.join(
                os.path.dirname(__file__), '..', 'import', context_name, 'subworkflows', subworkflow_name
            )

        # check if the sub-workflow already exists
        existing_subworkflow = check_existing_workflow(subworkflow_name, access_token)
        if existing_subworkflow:
            subworkflow_id = existing_subworkflow['id']
            subworkflow_id_map[subworkflow_name] = subworkflow_id # Populate the dictionary with the sub-workflow name and its ID
            logging.debug(f"Sub-workflow '{subworkflow_name}' already exists with ID {subworkflow_id}. Reusing it.")
            return "REUSE", f"REUSE: Sub-workflow '{subworkflow_name}' already exists with ID: {subworkflow_id}. Reusing it."

        # Import tasks for the sub-workflow
        subworkflow_tasks_dir = os.path.join(subworkflow_path, 'tasks')
        if os.path.exists(subworkflow_tasks_dir):
            print(f"Importing tasks for sub-workflow: '{subworkflow_name}'...")
            subworkflow_task_names = [
                os.path.splitext(file)[0].replace('task_', '', 1).replace('_import', '')
                for file in os.listdir(subworkflow_tasks_dir)
            ]
            print(f"Tasks found for sub-workflow '{subworkflow_name}': {subworkflow_task_names}")
            for task_name in subworkflow_task_names:
                logging.debug(f"Importing task: '{task_name}' for sub-workflow: '{subworkflow_name}'...")
                task_status, task_message = import_task(task_name, context_name, access_token, subworkflow_name=subworkflow_name, context_type=context_type)
                if task_status == "ERROR":
                    return "ERROR", task_message # Stop the import process if task import fails
                print(task_message) # Show the task import result to the user

            # Add a success message after all tasks are processed
            print(f"All tasks for sub-workflow '{subworkflow_name}' were successfully processed.")
        else:
            return "ERROR", (
                f"Sub-workflow tasks directory not found for '{subworkflow_name}'.\n"
                f"Expected at: {subworkflow_tasks_dir}.\n"
                "Please ensure the directory exists and contains task import files."
            )

        #Import the sub-workflow configuration
        subworkflow_config_path = os.path.join(subworkflow_path, f'workflow_{subworkflow_name}_import.json')
        if os.path.exists(subworkflow_config_path):
            logging.debug(f"Sub-workflow configuration file found for '{subworkflow_name}' at path: {subworkflow_config_path}")
            print(f"Importing sub-workflow configuration for '{subworkflow_name}'...")
            # Pass context_type and layout_name to import_workflow
            if context_type == "layout":
                workflow_status, workflow_message = import_workflow(
                    subworkflow_name, access_token,
                    subworkflow_name=subworkflow_name,
                    context_type=context_type,
                    layout_name=context_name
                )
            else:
                workflow_status, workflow_message = import_workflow(
                    context_name, access_token,
                    subworkflow_name=subworkflow_name,
                    context_type=context_type
                )

            if workflow_status == "SUCCESS":
                # Extract the new ID of the imported sub-workflow
                new_subworkflow_id = re.search(r'ID (\d+)', workflow_message).group(1)
                subworkflow_id_map[subworkflow_name] = new_subworkflow_id # Populate the dictionary with the sub-workflow name and its new ID
                logging.debug(f"Sub-workflow '{subworkflow_name}' imported successfully with new ID {new_subworkflow_id}.")
                return "CREATED", f"CREATE: Sub-workflow '{subworkflow_name}' imported successfully with new ID: {new_subworkflow_id}."
            else:
                return "ERROR", workflow_message
        else:
            return "ERROR", (
                f"Sub-workflow configuration file not found for '{subworkflow_name}'.\n"
                f"Expected at: {subworkflow_config_path}\n"
                "Please ensure the file exists and retry the import."
            )
    except Exception as e:
        return "ERROR", f"Failed to import sub-workflow '{subworkflow_name}': {e}"

def import_task(task_name, context_name, access_token, subworkflow_name=None, subworkflow_id_map=None, context_type="workflow"):
    """
    Imports a task into the target instance and resolve sub-workflow IDs for conditional tasks.

    Args:
        task_name (str): The name of the task to import.
        context_name (str): The name of the workflow or layout associated with the task.
        access_token (str): The access token for authentication API requests.
        subworkflow_name (str, optional): The name of the sub-workflow if the task belongs to a sub-workflow.
        subwrokflow_id_map (dict, optional): A dictionary mapping sub-workflow names to their new IDs in the target instance, used for resolving sub-workflow IDs in conditional tasks.
        context_type (str): Either "workflow" or "layout" for proper path resolution.

    Returns:
        tuple: ("CREATED", message), ("REUSE", message), or ("ERROR", message)
    """
    try:
        logging.debug(f"Entering import_task method for task: '{task_name}' for {context_type}: '{context_name}'")

        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }

        # Determing the import path based on whether the task belongs to a sub-workflow
        if context_type == "layout":
            if subworkflow_name:
                import_path = os.path.join(
                    os.path.dirname(__file__), '..', 'import', 'layouts', context_name, 'subworkflows', subworkflow_name, 'tasks', f'task_{task_name}_import.json'
                )
            else:
                import_path = os.path.join(
                    os.path.dirname(__file__), '..', 'import', 'layouts', context_name, 'tasks', f'task_{task_name}_import.json'
                )
        else: # workflow context
            if subworkflow_name:
                import_path = os.path.join(
                    os.path.dirname(__file__), '..', 'import', context_name, 'subworkflows', subworkflow_name, 'tasks', f'task_{task_name}_import.json'
                )
            else:
                import_path = os.path.join(
                    os.path.dirname(__file__), '..', 'import', context_name, 'tasks', f'task_{task_name}_import.json'
                )

        logging.debug(f"Constructed import path for task: {import_path}")

        if not os.path.exists(import_path):
            return "ERROR", (
                f"Import file not found for task '{task_name}'.\n"
                f"Expected at: {import_path}\n"
                "Please ensure the file exists in the correct directory and retry the import process."
            )
        # Load task data from JSON file
        logging.debug(f"Loading task data from file: {import_path}")
        with open(import_path, 'r') as json_file:
            task_data = json.load(json_file)
            logging.debug(f"Loaded task data: {json.dumps(task_data, indent=4)}")

        # Validate task code
        task_code = task_data["task"].get("code")
        if not task_code:
            return "ERROR", (
                f"Task '{task_name}' has an empty or missing 'code'.\n"
                f"Please ensure the 'code' field is present in the task JSON file: {import_path}."
            )

        # Resolve subworkflow IDs for conditional tasks
        if task_data["task"].get("taskType", {}).get("code") == "conditionalWorkflow":
            logging.debug(f"Task '{task_name}' is a conditional workflow. Resolving sub-workflow IDs...")
            task_options = task_data["task"].get("taskOptions", {})

            # Resolve 'ifOperationalWorkflowId' using 'ifOperationalWorkflowName'
            if "ifOperationalWorkflowName" in task_options and task_options["ifOperationalWorkflowName"]:
                subworkflow_name = task_options["ifOperationalWorkflowName"]
                if subworkflow_name in subworkflow_id_map:
                    task_options["ifOperationalWorkflowId"] = subworkflow_id_map[subworkflow_name]
                    logging.debug(f"Resolved 'ifOperationalWorkflowId' for task '{task_name}' to ID {subworkflow_id_map[subworkflow_name]} using name '{subworkflow_name}'.")
                else:
                    return "ERROR", f"Sub-workflow '{subworkflow_name}' not found in the ID map. Cannot resolve 'ifOperationalWorkflowId'. Ensure the sub-workflow '{subworkflow_name}' is imported correctly."

            # Resolve 'elseOperationalWorkflowId' using 'elseOperationalWorkflowName'
            if "elseOperationalWorkflowName" in task_options and task_options["elseOperationalWorkflowName"]:
                subworkflow_name = task_options["elseOperationalWorkflowName"]
                if subworkflow_name in subworkflow_id_map:
                    task_options["elseOperationalWorkflowId"] = subworkflow_id_map[subworkflow_name]
                    logging.debug(f"Resolved 'elseOperationalWorkflowId' for task '{task_name}' to ID {subworkflow_id_map[subworkflow_name]} using name '{subworkflow_name}'.")
                else:
                    return "ERROR", f"Sub-workflow '{subworkflow_name}' not found in the ID map. Cannot resolve 'elseOperationalWorkflowId'. Ensure the sub-workflow '{subworkflow_name}' is imported correctly."

        # Fetch existing tasks
        logging.debug("Fetching existing tasks from the target instance...")
        existing_tasks = fetch_paginated_data(
            f'{morpheus_url}/api/tasks',
            headers,
            resource_key='tasks',
        )
        logging.info(f"Total existing tasks fetched: {len(existing_tasks)}")
        logging.debug(f"Fetched existing tasks: {json.dumps(existing_tasks, indent=4)}")

        # Check for existing task by code
        existing_task_by_name = next((t for t in existing_tasks if t['name'].lower() == task_name.lower()), None)

        if existing_task_by_name:
            if existing_task_by_name['code'] == task_code:
                return "REUSE", f"REUSE: Task '{task_name}' with code '{task_code}' already exists and reused successfully with ID '{existing_task_by_name['id']}'."
            else:
               # Name conflict with different code
                return "ERROR", (
                    f"[CONFLICT] Task Name: '{task_name}'\n"
                    f"- A task with this name already exists in Morpheus, but with a different code ('{existing_task_by_name['code']}').\n"
                    "- Morpheus requires task names to be unique.\n"
                    "To resolve:\n"
                    f"  - Either rename the task in your import file '(task_{task_name}_import.json)', or\n"
                    "  - Rename/delete the existing task in Morpheus, then retry the import.\n"
                    "Import process stopped for this task."
                )

        # Create the task
        logging.debug(f"Creating task: '{task_name}'")
        response = requests.post(f'{morpheus_url}/api/tasks', headers=headers, json=task_data, verify=False)
        response.raise_for_status()
        new_task_id = response.json()['task']['id']
        logging.debug(f"Task '{task_name}' created successfully with ID {new_task_id}.")
        return "CREATED", f"CREATED: Task '{task_name}' created successfully with ID {new_task_id}."
    except Exception as e:
        return "ERROR", f"Failed to import task '{task_name}': {e}"

def check_existing_workflow(workflow_name, access_token):
    """
    Checks if a workflow with the given name already exists in the target instance.

    Args:
        workflow_name (str): The name of the workflow to check.
        access_token (str): The access token for authentication API requests.

    Returns:
        dict: The existing workflow data if found, otherwise None.
    """
    logging.debug(f"Checking if the workflow '{workflow_name}' already exists...")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
        }

    # Fetch all existing workflows using the centralized pagination function
    logging.debug("Fetching existing workflows from the target instance...")
    existing_workflows = fetch_paginated_data(
        f'{morpheus_url}/api/task-sets',
        headers,
        resource_key='taskSets',
    )
    logging.info(f"Total existing workflows fetched: {len(existing_workflows)}")

    # Find and return the workflow with the matching name
    matching_workflow = next((wf for wf in existing_workflows if wf['name'] == workflow_name), None)
    if matching_workflow:
        logging.debug(f"Workflow '{workflow_name}' already exists with ID {matching_workflow['id']} and its configuration: {json.dumps(matching_workflow, indent=4)}. in the target instance.")
    else:
        logging.debug(f"Workflow '{workflow_name}' does not exist in the target instance.")
    return matching_workflow

# Function to import a workflow and resolve its components
def import_workflow(workflow_name, access_token, subworkflow_name=None, context_type="workflow", layout_name=None):
    """
    Imports a workflow into the target instance

    Args:
        workflow_name (str): The name of the workflow to import.
        access_token (str): The access token for authentication API requests.
        subworkflow_name (str, optional): The name of the sub-workflow if importing a sub-workflow.
        context_type (str): Either "workflow" or "layout" for proper path resolution.
        layout_name (str, optional): The layout name when context_type is "layout".
    Returns:
        tuple: ("SUCCESS", message) or ("ERROR", message)
    """
    logging.debug(f"Entering import_workflow method and Starting import of workflow: {workflow_name}")
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    # Determing the import path based on whether its a main workflow or a sub-workflow
    if context_type == "layout":
        if subworkflow_name:
            import_path = os.path.join(
                os.path.dirname(__file__), '..', 'import', 'layouts', layout_name, 'subworkflows', subworkflow_name, f'workflow_{subworkflow_name}_import.json'
            )
        else:
            import_path = os.path.join(
                os.path.dirname(__file__), '..', 'import', 'layouts', layout_name, f'workflow_{workflow_name}_import.json'
            )
    else: # Workflow context
        if subworkflow_name:
            import_path = os.path.join(
                os.path.dirname(__file__), '..', 'import', workflow_name, 'subworkflows', subworkflow_name, f'workflow_{subworkflow_name}_import.json'
            )
        else:
            import_path = os.path.join(
                os.path.dirname(__file__), '..', 'import', workflow_name, f'workflow_{workflow_name}_import.json'
            )
    logging.debug(f"Workflow import path: {import_path}")

    if not os.path.exists(import_path):
        return "ERROR", f"Import file not found for workflow '{workflow_name}'. Please ensure the file 'workflow_{workflow_name}_import.json' is in the expected directory: '{import_path}'. Stopping the import process."

    with open(import_path, 'r') as json_file:
        workflow_data = json.load(json_file)
        logging.debug(f"Loaded workflow data: {json.dumps(workflow_data, indent=4)}")

    # Validate workflow data
    if "taskSet" not in workflow_data or not isinstance(workflow_data["taskSet"], dict):
        return "ERROR", f"Invalid workflow JSON for '{workflow_name}'. Missing or invalid 'taskSet'. Expected a dictionary under the 'taskSet' key."

    # Detect workflow type
    workflow_type = workflow_data["taskSet"].get("type", "operation").lower()
    logging.debug(f"Detected workflow type for '{workflow_name}': {workflow_type}")

    # Resolve input parameters (optionTypes)
    if workflow_type == 'operation' and not subworkflow_name:
        logging.debug("Resolving input parameters (optionTypes)....")
        existing_option_types = fetch_paginated_data(
            f'{morpheus_url}/api/library/option-types',
            headers,
            resource_key='optionTypes',
        )
        logging.info(f"Total existing option types fetched: {len(existing_option_types)}")

        result = resolve_option_types(workflow_data, existing_option_types)
        if result["status"] == "ERROR":
            return "ERROR", result["message"]

    # Resolve task IDs
    logging.debug("Resolving task IDs...")
    existing_tasks = fetch_paginated_data(
        f'{morpheus_url}/api/tasks',
        headers,
        resource_key='tasks',
    )
    logging.info(f"Total existing tasks fetched: {len(existing_tasks)}")
    logging.debug(f"total Existing tasks fetched from the target instance: {json.dumps(existing_tasks, indent=4)}")

    result = resolve_tasks(workflow_data, existing_tasks)
    if result['status'] == "ERROR":
        return "ERROR", result["message"]

    logging.debug(f"Final workflow payload before sending: {json.dumps(workflow_data, indent=4)}")

    # Create the workflow
    try:
        response = requests.post(
            f'{morpheus_url}/api/task-sets',
            headers=headers,
            json=workflow_data,
            verify=False
        )
        response.raise_for_status()
        workflow_id = response.json()['taskSet']['id']
        logging.debug(f"Workflow '{workflow_name}' imported successfully with ID {workflow_id}.")
        return "SUCCESS", f"Workflow '{workflow_name}' imported successfully with ID {workflow_id}."
    except requests.exceptions.HTTPError as err:
        return "ERROR", f"Failed to import workflow '{workflow_name}': {err}\nResponse content: {response.content.decode('utf-8')}"

def resolve_option_types(workflow_data, existing_option_types):
    """
    Resolves input parameters (optionTypes) in the workflow by mapping name, fieldName, and description to IDs.

    Args:
        workflow_data (dict): The workflow data containing optionTypes to resolve.
        existing_option_types (list): A List of existing optionTypes in the target instance.

    Returns:
        Str: Error message if an issue occurs, or "SUCCESS" if all optionTypes are resolved successfully.
    """
    logging.debug("Entered resolve_option_types method and Resolving input parameters IDs (optionTypes)....")

    # Handle case where no optionTypes are present in the workflow JSON
    if not workflow_data["taskSet"].get("optionTypes", []):
        return {
            "status": "ERROR",
            "message": "No optionTypes found the workflow JSON. Input parameters are required for the workflow to function. Please ensure the workflow JSON includes valid optionTypes."
        }

    resolved_option_types = []
    for option_type in workflow_data["taskSet"].get("optionTypes", []):
        option_name = sanitize_name(option_type["name"])
        option_fieldname = clean_field_name(option_type["fieldName"])
        option_description = clean_description(option_type.get("description", ""))

        # Pre-check for missing or empty description
        if not option_description or not option_fieldname:
            return {
                "status": "ERROR",
                "message": f"Missing or empty fields for input name '{option_name}'. Ensure 'description' and 'fieldName' are provided."
            }
        logging.debug(f"Resolving optionType: name='{option_name}', fieldName='{option_fieldname}', description='{option_description}'")

        # Find all matching optionTypes by name
        matching_by_name = [
            ot for ot in existing_option_types if sanitize_name(ot["name"]) == option_name
        ]

        # Check for fieldName conflicts
        conflicting_fieldNames = [
            ot for ot in matching_by_name if clean_field_name(ot["fieldName"]) != option_fieldname
        ]
        if conflicting_fieldNames:
            return {
                "status": "ERROR",
                "message": f"Conflict detected for input parameter '{option_name}'. FieldName mismatch. Ensure fieldName matches, or update the import file or Morpheus accordingly."
            }

        # Check for description match among those with the same name and fieldName
        matching_by_name_and_field = [
            ot for ot in matching_by_name if clean_field_name(ot["fieldName"]) == option_fieldname
        ]

        # Handle case where no matching entries are found
        if not matching_by_name_and_field:
            return {
                "status": "ERROR",
                "message": f"No matching entries found for input parameter '{option_name}' with fieldName '{option_fieldname}'. Ensure the input parameter exists in Morpheus."
            }
        """
        # Debuging prupose:
        simplified_entries = [
            {
                "id": ot["id"],
                "name": ot["name"],
                "fieldName": ot["fieldName"],
                "description": ot.get("description", "")
            }
            for ot in matching_by_name_and_field
        ]
        print(f"is it addressing multiple entries:", json.dumps(simplified_entries, indent=4)) # debug purpose, delete later
        """
        # Find the first matching entry by description
        matching_entry = next(
            (ot for ot in matching_by_name_and_field if clean_description(ot.get("description", "")) == option_description),
            None
        )
        if matching_entry:
            resolved_option_types.append(matching_entry["id"])
            logging.debug(f"Reusing existing optionType: name='{option_name}', fieldName='{option_fieldname}', id={matching_entry['id']}")
        else:
            # No match found, raise an error
            existing_description = [clean_description(ot.get("description", "")) for ot in matching_by_name_and_field]
            return {
                "status": "ERROR",
                "message": (
                    f"Description mismatch for input parameter '{option_name}'.\n"
                    f"Expected description: '{option_description}'\n"
                    f"Existing descriptions: {existing_description}\n"
                    "Ensure descriptions match, or update the import file or Morpheus accordingly."
                )
            }
    # Update the workflow data with resolved optionType IDs
    logging.debug(f"Resolved optionTypes: {json.dumps(resolved_option_types, indent=4)}")
    workflow_data["taskSet"]["optionTypes"] = resolved_option_types
    return {"status": "SUCCESS"}

def resolve_tasks(workflow_data, existing_tasks):
    """
    Resolve tasks in the workflow by mapping task codes to IDs.

    Args:
        workflow_data (dict): The workflow data containing tasks to resolve.
        existing_tasks (list): A list of existing tasks in the target instance.

    Returns:
        str: "SUCCESS" if all tasks are resolved successfully, or a detailed error message string if an error occurs.
    """
    logging.debug("Entered resolve_tasks method and Resolving task IDs...")

    # Handle case where no tasks are present in the workflow JSON
    task_set_tasks = workflow_data["taskSet"].get("taskSetTasks", [])
    if not task_set_tasks:
        return {
            "status": "ERROR",
            "message": "No taskSetTasks found in the workflow JSON. Tasks are required for the workflow to function. Please ensure the workflow JSON includes valid taskSetTasks."
        }

    # Create a mapping of task code to task ID
    task_code_to_id = {task['code']: task['id'] for task in existing_tasks}
    logging.debug(f"Task code to ID mapping: {json.dumps(task_code_to_id, indent=4)}")

    # Update taskSetTasks with correct IDs and build the tasks array
    tasks_array = []
    for task_set_task in task_set_tasks:
        task_name = task_set_task["task"].get("name")
        task_code = task_set_task["task"].get("code")
        task_phase = task_set_task.get("taskPhase")
        if not task_code:
            return {
                "status": "ERROR",
                "message": f"For task '{task_name}' in taskSetTasks is missing the 'code' field. Ensure all tasks have a valid code."
            }
        if not task_phase:
            return {
                "status": "ERROR",
                "message": f"For task '{task_name}' in taskSetTasks is missing the 'taskPhase' field. Ensure all tasks have a valid taskPhase."
            }
        if task_code in task_code_to_id:
            task_set_task["task"]["id"] = task_code_to_id[task_code]
            tasks_array.append({
                "taskId": task_code_to_id[task_code],
                "taskPhase": task_phase
            })
            logging.debug(f"Resolved task: code='{task_code}', id={task_code_to_id[task_code]}, phase='{task_phase}'")
        else:
            return {
                "status": "ERROR",
                "message": f"For task '{task_name}' with code '{task_code}' not found in the target instance. Ensure the task exists before importing the workflow."
            }

    if not tasks_array:
        return {
            "status": "ERROR",
            "message": "No tasks could be resolved for the workflow. The tasks array is empty. Ensure task codes match existing tasks."
        }

    workflow_data["taskSet"]["tasks"] = tasks_array
    logging.debug(f"Resolved tasks: {json.dumps(workflow_data['taskSet']['tasks'], indent=4)}")
    return {"status": "SUCCESS"}

###############################
#
# Below functions are used to import layouts and its dependencies
#
###############################
def list_layouts():
    """
    List available layouts in the 'import/layouts' directory.
    """
    import_layouts_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'layouts')
    if not os.path.exists(import_layouts_dir):
        raise FileNotFoundError(f"The 'import/layouts' directory does not exist: {import_layouts_dir}")

    layouts = [name for name in os.listdir(import_layouts_dir)
               if os.path.isdir(os.path.join(import_layouts_dir, name))]

    return layouts

def check_existing_layout(layout_name, instance_type_id, access_token):
    """
    Checks if a layout with the given name already exists in the target instance.

    Args:
        layout_name (str): The name of the layout to check.
        instance_type_id (int): The ID of the instance type to check against.
        access_token (str): The access token for authentication API requests.

    Returns:
        dict: The existing layout data if found, otherwise None.
    """
    logging.debug(f"Checking if layout '{layout_name}' already exists for instance type ID {instance_type_id}...")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    try:
        # Fetch all layouts for the specific instance type
        existing_layouts = fetch_paginated_data(
            f'{morpheus_url}/api/library/instance-types/{instance_type_id}/layouts',
            headers,
            resource_key='instanceTypeLayouts'
        )
        logging.info(f"Total existing layouts fetched for instance type {instance_type_id}: {len(existing_layouts)}")

        # Find matching layout by name
        matching_layout = next((layout for layout in existing_layouts
                               if layout['name'].strip() == layout_name.strip()), None)

        if matching_layout:
            logging.debug(f"Layout '{layout_name}' already exists with ID {matching_layout['id']}")
            return matching_layout
        else:
            logging.debug(f"Layout '{layout_name}' does not exist for instance type {instance_type_id}")
            return None

    except Exception as e:
        logging.error(f"Error checking existing layouts: {e}")
        return None

def create_instance_type(layout_dir, instance_type_name, access_token):
    """
    Creates an instance type in Morpheus from the sanitized config file.
    Returns the created instance type dict or None.
    """
    instance_type_file = os.path.join(layout_dir, f'instance_type_{instance_type_name}_sanitized.json')
    if not os.path.exists(instance_type_file):
        logging.error(f"Sanitized instance type config not found: {instance_type_file}")
        return None

    with open(instance_type_file, 'r') as f:
        instance_type_data = json.load(f)

    headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
    payload = {"instanceType": instance_type_data}

    try:
        response = requests.post(
            f"{morpheus_url}/api/library/instance-types",
            headers=headers,
            json=payload,
            verify=False
        )
        response.raise_for_status()
        instance_type = response.json().get("instanceType")
        print(f"CREATED: Instance type '{instance_type_name}' created with ID {instance_type['id']}")
        return instance_type
    except Exception as e:
        print(f"ERROR: Failed to create instance type '{instance_type_name}': {e}")
        return None

def check_existing_container_type_by_name(container_name, access_token):
    """
    Check if a container type exists by name only
    """
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{morpheus_url}/api/library/container-types", headers=headers, verify=False)

        if response.status_code == 200:
            container_types = response.json().get("containerTypes", [])

            # Match by name (case-insensitive)
            if container_name:
               name_match = next((ct for ct in container_types if ct["name"].lower() == container_name.lower()), None)
               return name_match
        return None
    except Exception as e:
        logging.error(f"Error checking existing container type '{container_name}': {e}")
        return None

def import_layout(layout_name, access_token):
    """
    Import layout configuration after dependencies are resolved.
    """
    logging.debug(f"Starting import of layout: '{layout_name}'.")

    layout_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'layouts', layout_name)

    # Validation: Check if layout directory exists
    if not os.path.exists(layout_dir):
        return "ERROR", f"Layout directory not found: '{layout_dir}'. Please ensure the layout exists in the 'import/layouts' directory."

    # Early check: Load layout configuration to get instance type info
    layout_file = os.path.join(layout_dir, f'layout_{layout_name}_sanitized.json')
    if not os.path.exists(layout_file):
        return "ERROR", f"Layout configuration file not found: '{layout_file}'. Please ensure the file exists in the layout directory."

    with open(layout_file, 'r') as f:
        layout_data = json.load(f)
        logging.debug(f"Loaded layout configuration: {json.dumps(layout_data, indent=4)}")

    # validate layout structure
    if "instanceTypeLayout" not in layout_data:
        return "ERROR", f"Invalid layout configuration. Missing 'instanceTypeLayout' in '{layout_file}'. Please ensure the layout JSON structure is correct."

    instance_type_info = layout_data.get("instanceTypeLayout", {}).get("instanceType", {})
    instance_type_name = instance_type_info.get("name")
    instance_type_code = instance_type_info.get("code")

    if not instance_type_name or not instance_type_code:
        return "ERROR", f"Instance type information is missing in the layout configuration for '{layout_name}'. Ensure 'name' and 'code' are provided in 'instanceTypeLayout'."

    # Resolve instance type ID early
    headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
    logging.debug(f"Resolving instance type '{instance_type_name}' with code '{instance_type_code}'...")
    instance_types = fetch_paginated_data(
        f'{morpheus_url}/api/instance-types',
        headers,
        resource_key='instanceTypes',
    )
    instance_type = next((it for it in instance_types
                          if it['name'] == instance_type_name and it['code'] == instance_type_code), None)
    if not instance_type:
        print(f"Instance type '{instance_type_name}' not found. Attempting to create it from sanitized config...")
        instance_type = create_instance_type(layout_dir, instance_type_name, access_token)
        if not instance_type:
            return "ERROR", f"Instance type '{instance_type_name}' with code '{instance_type_code}' not found in Morpheus. Ensure the instance type exists before importing the layout."

    instance_type_id = instance_type['id']
    logging.debug(f"Resolved instance type '{instance_type_name}' with ID {instance_type_id}.")

    # Early Check: Does layout already exist?
    existing_layout = check_existing_layout(layout_name, instance_type_id, access_token)
    if existing_layout:
        layout_id = existing_layout['id']
        return "SUCCESS", f"REUSE: Layout '{layout_name}' already exists with ID: {layout_id}. Reusing it."

    # Only proceed with imports if layout doesn't exist
    print(f"Layout '{layout_name}' does not exist in the target morpheus instance. Starting import process...")

    # Step 1: Validate and Import input parameters using existing method (REQUIRED)
    input_parameters_dir = os.path.join(layout_dir, 'input_parameters')
    if not os.path.exists(input_parameters_dir):
        return "ERROR", f"Input parameters directory not found for layout '{layout_name}': '{input_parameters_dir}'. Please ensure the directory exists and contains input parameter files."

    input_files = [f for f in os.listdir(input_parameters_dir)
                   if f.startswith('input_parameter_') and f.endswith('_import.json')]

    if not input_files:
        return "ERROR", f"No input parameter files found for layout '{layout_name}' in '{input_parameters_dir}'. Please ensure the directory contains valid input parameter files."

    print(f"Importing {len(input_files)} input parameters for layout '{layout_name}'...")
    for input_file in input_files:
        input_name = input_file.replace('input_parameter_', '').replace('_import.json', '')
        logging.debug(f"Importing input parameter: {input_name}")

        # Use existing method with layout context
        result, message = import_input_parameter(input_name, layout_name, access_token, context_type="layout")
        if result == "ERROR":
            return "ERROR", f"Failed to import input parameter '{input_name}': {message}"
        print(message)

    # Validate workflow exists (REQUIRED)
    workflow_files = [f for f in os.listdir(layout_dir)
                      if f.startswith('workflow_') and f.endswith('_import.json')]
    if not workflow_files:
        return "ERROR", f"Workflow is required for layout '{layout_name}' but no workflow file found in: {layout_dir}"

    if len(workflow_files) > 1:
        return "ERROR", f"Multiple workflow files found for layout '{layout_name}'. Expected only one workflow per layout."

    # Import sub-workflows if they exist (before importing tasks)
    subworkflows_dir = os.path.join(layout_dir, 'subworkflows')
    subworkflow_id_map = {} # Initialize the sub-workflow ID mapping dicitinoary

    if os.path.exists(subworkflows_dir):
        logging.debug(f"Sub-workflow directory found for layout: '{layout_name}' at path: {subworkflows_dir}")
        print(f"Importing sub-workflows associated with the layout: '{layout_name}'...")
        # Get sub-workflow namees
        subworkflow_names = [
            name for name in os.listdir(subworkflows_dir)
            if os.path.isdir(os.path.join(subworkflows_dir, name))
        ]
        if subworkflow_names:
            for subworkflow_name in subworkflow_names:
                logging.debug(f"Importing sub-workflow: '{subworkflow_name}' for layout '{layout_name}'...")

                # Use existing import_subworkflow method with laoyut context
                subworkflow_status, subworkflow_message = import_subworkflow(
                    subworkflow_name, layout_name, access_token, subworkflow_id_map, context_type="layout"
                )

                if subworkflow_status == "ERROR":
                    return "ERROR", f"Failed to import sub-workflow '{subworkflow_name}': {subworkflow_message}"
                print(subworkflow_message)
            logging.debug(f"Final Sub-workflow ID mapping: {json.dumps(subworkflow_id_map, indent=4)}")
            print(f"Sub-workflows imported successfully for layout '{layout_name}'. ID mapping: {subworkflow_id_map}")

    # Import workflow and its tasks
    workflow_file = workflow_files[0]
    workflow_name = workflow_file.replace('workflow_', '').replace('_import.json', '')

    # Validate and import tasks (REQUIRED for workflow)
    tasks_dir = os.path.join(layout_dir, 'tasks')
    if not os.path.exists(tasks_dir):
        return "ERROR", f"Tasks are required for workflow '{workflow_name}' in layout '{layout_name}' but tasks directory not found: '{tasks_dir}'."

    task_files = [f for f in os.listdir(tasks_dir)
                  if f.startswith('task_') and f.endswith('_import.json')]

    if not task_files:
        return "ERROR", f"No task files found for workflow '{workflow_name}' in layout '{layout_name}'. Tasks are required."

    print(f"Importing {len(task_files)} tasks for workflow '{workflow_name}' in layout '{layout_name}'...")
    for task_file in task_files:
        task_name = os.path.splitext(task_file)[0].replace('task_', '', 1).replace('_import', '')
        logging.debug(f"Importing task: {task_name}")

        # Use existing method with layout context
        result, message = import_task(
            task_name, layout_name, access_token,
            subworkflow_id_map=subworkflow_id_map,
            context_type="layout"
        )
        if result == "ERROR":
            return "ERROR", f"Failed to import task '{task_name}': {message}"
        print(message)

    # Import the workflow configuration
    print(f"Importing workflow '{workflow_name}' for layout '{layout_name}'...")

    # Check if workflow already exists
    existing_workflow = check_existing_workflow(workflow_name, access_token)
    if existing_workflow:
        workflow_id = existing_workflow['id']
        print(f"Workflow '{workflow_name}' already exists with ID: {workflow_id}. Reusing it.")
    else:
        # Import the workflow using existing method
        result, message = import_workflow(workflow_name, access_token, context_type="layout", layout_name=layout_name)
        if result == "ERROR":
            return "ERROR", f"Failed to import workflow '{workflow_name}': {message}"
        print(message)

        # Extract the workflow ID from success message (only when creating new workflow)
        workflow_id = re.search(r'ID (\d+)', message).group(1)

    # Ensure workflow_id is integeer for later use
    workflow_id = int(workflow_id)

    # Resolve tasksSets (workflows)
    layout_config = layout_data["instanceTypeLayout"]

    # Link the workflow to the layout using taskSetId
    layout_config['taskSetId'] = workflow_id
    print(f"Added taskSetId in layout payload to reference workflow ID: {workflow_id}")

    # Remove taskSets if it exists (API doesn't support it)
    if "taskSets" in layout_config:
        del layout_config["taskSets"]
        print("Removed taskSets from layout payload - not supported by layout creation API.")

    # Resolve input parameter dependencies
    if "optionTypes" in layout_config and layout_config["optionTypes"]:
        headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
        existing_option_types = fetch_paginated_data(
            f'{morpheus_url}/api/library/option-types',
            headers,
            resource_key='optionTypes',
        )

        resolved_option_types = []
        for option_type in layout_config["optionTypes"]:
            input_name = sanitize_name(option_type.get("name"))
            input_fieldname = clean_field_name(option_type.get("fieldName"))
            input_description = clean_description(option_type.get("description"))

            # Find matching input parameter by name, fieldName and description
            matching_input = None
            for existing_input in existing_option_types:
                if (sanitize_name(existing_input.get("name")) == input_name and
                        clean_field_name(existing_input.get("fieldName")) == input_fieldname and
                        clean_description(existing_input.get("description")) == input_description):
                    matching_input = existing_input
                    break
            if matching_input:
                resolved_option_types.append(matching_input["id"])
                print(f"Resolved input parameter '{input_name}' to ID {matching_input['id']}")
            else:
                return "ERROR", f"Input parameter '{input_name}' with fieldName '{input_fieldname}' and description '{input_description}' not found in Morpheus. Ensure the input parameter exists before importing the layout."
        layout_config["optionTypes"] = resolved_option_types

    # Resolve containerType (node types)
    if "containerTypes" in layout_config and layout_config["containerTypes"]:
        print(f"Resolving container types for layout '{layout_name}'...")
        resolved_container_types = []

        for container_type in layout_config["containerTypes"]:
            container_name = container_type.get("name")

            if not container_name:
                return "ERROR", f"Container type missing name in layout '{layout_name}'"

            logging.debug(f"Resolving container type: '{container_name}'")

            # check if container type exists by name or code
            existing_container = check_existing_container_type_by_name(container_name, access_token)

            if existing_container:
                container_id = existing_container['id']
                resolved_container_types.append(container_id)
                print(f"REUSE: Container type '{container_name}' found with ID: {container_id}")
            else:
                print(f"WARNING: Container type '{container_name}' not found in target instance.")
                print(f"Please ensure node type '{container_name}' exists before importing this layout.")
                return "ERROR", f"Required container type '{container_name}' not found in target instance. Layout import cannot continue."

        # Update layout config with resolved IDs only
        layout_config["containerTypes"] = resolved_container_types
        print(f"Resolved container types to IDs: {resolved_container_types}")

    # Final Step: Create the layout
    try:
        headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}

        # Remove instanceType from payload since it's in the URL
        if 'instanceType' in layout_data['instanceTypeLayout']:
            del layout_data['instanceTypeLayout']['instanceType']

        # Create layout using correct API endpoint
        print(f"Creating layout '{layout_name}'...")
        #print(f"Layout data before sending: {json.dumps(layout_data, indent=4)}")
        #exit()
        response = requests.post(
            f'{morpheus_url}/api/library/instance-types/{instance_type_id}/layouts',
            headers=headers,
            json=layout_data,
            verify=False
        )
        response.raise_for_status()
        layout_response = response.json()
        layout_id = layout_response['instanceTypeLayout']['id']
        return "SUCCESS", f"Layout '{layout_name}' imported successfully with ID {layout_id}."

    except requests.exceptions.HTTPError as err:
        error_content = ""
        try:
            error_content = response.content.decode('utf-8')
        except:
            pass
        return "ERROR", f"Failed to import layout '{layout_name}': {err}{error_content}"
    except Exception as e:
        return "ERROR", f"Failed to import layout '{layout_name}': {e}"

#################################
#
# Main function to import workflows and layouts
#
#################################

# Main function
def main():
    """
    Main function to authenticate, list available workflows, and import the selected workflow.
    Prompts the user to select a workflow and imports it along with its associated option lists, input parameters, and tasks.
    """
    try:
        # Step 1: Authenticate and get the access token
        logging.debug("Calling Authenticate method...")
        access_token = Authenticate()
        logging.debug("Access token received: [MASKED]")

        # Prompt user for import type (single choice, not loop)
        print("\nSelect the type of import:")
        print("1. Import Workflows...")
        print("2. Import Layouts...")

        # Prompt user for import type
        while True:
            try:
                choice = input("\nEnter your choice (1 or 2): ").strip()

                if choice == '1':
                    # Step 2: List Available workflows in the 'import' directory
                    logging.debug(" Calling list_workflows method...")
                    workflows = list_workflows()
                    logging.debug(f"Workflows available for import: {workflows}")

                    if not workflows:
                        logging.warning("No workflows available for import in the 'import' folder.")
                        print("No workflows available for import. Please ensure the 'import' folder contains workflow configurations.")
                        return

                    print("\nAvailable workflows:")
                    for i, workflow in enumerate(workflows, 1):
                        print(f'{i}. {workflow}')
                    print("\n*** Initial Import ***")
                    print(f'{len(workflows) + 1}. Import all Workflows') # Highlight "All Workflows"

                    # Step 3: Prompt the user to select a workflow
                    while True:
                        try:
                            choice = int(input("\nSelect a workflow to import (enter the number): "))

                            if 1 <= choice <= len(workflows): # Valid workflow selection
                                selected_workflows = [workflows[choice - 1]]
                                logging.debug(f"User selected workflow: {json.dumps(selected_workflows, indent=4)}")
                                break
                            elif choice == len(workflows) + 1: # "All Workflows" option
                                selected_workflows = workflows[:] # All workflows
                                logging.debug(f"User selected 'All Workflows' option. Importing all workflows: {json.dumps(selected_workflows, indent=4)}")
                                break
                            else:
                                logging.error("Invalid choice. User selected an out-of-range workflow number.")
                                print("Invalid choice. Please select a valid workflow number.")
                        except ValueError:
                            logging.error("Invalid input. User entered a non-integer value.")
                            print("Invalid input. Please enter a number.")
                            return

                    # Step 4: Iterate through selected workflows and import each one
                    for workflow_name in selected_workflows:
                        try:
                            logging.debug(f"Started import process for selected workflow: {workflow_name}")

                            # Step 4.1: Load the workflow JSON file
                            import_path = os.path.join(os.path.dirname(__file__), '..', 'import', workflow_name, f'workflow_{workflow_name}_import.json')
                            if not os.path.exists(import_path):
                                raise FileNotFoundError(
                                    f"Workflow import file not found: {import_path}. "
                                    f"Please ensure the file exists in the expected directory and retry the import process."
                                )

                            with open(import_path, 'r') as json_file:
                                workflow_data = json.load(json_file)
                                logging.debug(f"Loaded workflow data: {json.dumps(workflow_data, indent=4)}")

                            # Step 5: Check if the workflow already exists
                            existing_workflow = check_existing_workflow(workflow_name, access_token)
                            if existing_workflow:
                                workflow_id = existing_workflow['id']
                                existing_description = existing_workflow.get('description', None)
                                imported_description = workflow_data.get('taskSet', {}).get('description', None)

                                # Check if the existing description is missing or empty
                                if not existing_description:
                                    raise ValueError(
                                        f"Description is missing or empty for workflow '{workflow_name}' in the target instance. "
                                        f"Please add a description and try again."
                                    )

                                # Strip the description only if it exists
                                existing_description = existing_description.strip()
                                logging.debug(f"Existing description for workflow '{workflow_name}': {existing_description}")

                                # check if the description is missing or empty
                                if not imported_description:
                                    raise ValueError(
                                        f"Description is missing or empty in the workflow JSON for '{workflow_name}'. "
                                        f"Please ensure the 'description' field is populated and retry the import process."
                                    )

                                # Strip the imported description only if it exists
                                imported_description = imported_description.strip()
                                logging.debug(f"Imported description for workflow '{workflow_name}': {imported_description}")

                                # Compare description
                                if existing_description == imported_description:
                                    logging.debug(f"The workflow '{workflow_name}' already exists with ID {workflow_id}. Reusing it.")
                                    print(f"Workflow '{workflow_name}' already exists with ID: {workflow_id}. Reusing it.")
                                    # Add a visual separator after reusing a workflow
                                    print("\n" + "-" * 80 + "\n")  # Visual separator
                                    if len(selected_workflows) == 1: # Single workflow selected
                                        return # Exit the function gracefully
                                    else:
                                        continue # Skip to the next workflow in the loop
                                else:
                                    logging.debug(f"Description mismatch detected for workflow '{workflow_name}'. Treating as a new version.")
                                    print(f"Description mismatch detected for workflow '{workflow_name}'. Proceeding to create a new workflow.")

                            logging.debug(f"workflow '{workflow_name}' does not exist in the target instance. Proceeding to import it.")

                            # Step 6: Detect workflow type (operation or provision)
                            workflow_type = workflow_data.get('taskSet', {}).get('type', 'operation').lower()
                            logging.debug(f"Detected workflow type for '{workflow_name}': {workflow_type}")

                            if workflow_type not in ['operation', 'provision']:
                                raise ValueError(
                                    f"Invalid workflow type '{workflow_type}' for workflow '{workflow_name}'. "
                                    "Supported types are 'operation' and 'provision'."
                                )

                            # Handle workflows based on type:
                            if workflow_type == 'operation':
                                logging.debug(f"Handling operation workflow: {workflow_name}")
                                # Step 6a: Import option lists associated with the workflow
                                logging.debug(f"Importing option lists for workflow: {workflow_name}")
                                options_dir = os.path.join(os.path.dirname(__file__), '..', 'import', workflow_name, 'options')
                                logging.debug(f"Options directory path: {options_dir}")

                                if os.path.exists(options_dir):
                                    logging.debug(f"Option directory exists for workflow: '{workflow_name}'...")
                                    print(f"Importing option lists associated with the workflow: '{workflow_name}'...")

                                    # Extract option list names from the directory
                                    option_list_names = [
                                        os.path.splitext(file)[0].replace('option_list_', '').replace('_import', '')
                                        for file in os.listdir(options_dir)
                                    ]
                                    logging.debug(f"Option list names extracted: {option_list_names}")

                                    # Import each option list
                                    for option_list_name in option_list_names:
                                        logging.debug(f"Processing option list: '{option_list_name}'...")
                                        result, message = import_option_list(option_list_name, workflow_name, access_token)
                                        if result == "ERROR":
                                            print(message)
                                            sys.exit(1) # Stop the entire process if any option list fails to import
                                        elif result in ["REUSE", "CREATED"]:
                                            print(message)
                                        else:
                                            print(f"Unexpected result '{result}' for option list '{option_list_name}'.")
                                            sys.exit(1)
                                else:
                                    logging.error(f"No option lists directory found for workflow: '{workflow_name}'. Expected at: {options_dir}")
                                    sys.exit(1) # Stop the entire process if no option lists are found

                                # Step 6b: Import input parameters associated with the workflow
                                logging.debug(f"Starting import of input parameters for workflow: {workflow_name}")
                                input_parameters_dir = os.path.join(os.path.dirname(__file__), '..', 'import', workflow_name, 'input_parameters')
                                logging.debug(f"Input parameters directory path: {input_parameters_dir}")

                                if os.path.exists(input_parameters_dir):
                                    logging.debug(f"Input parameters directory exists for workflow: '{workflow_name}'...")
                                    print(f"Importing input parameters associated with the workflow: '{workflow_name}'...")
                                    # Extract input parameter files from the directory
                                    input_parameter_files = [
                                        f for f in os.listdir(input_parameters_dir)
                                        if f.startswith('input_parameter_') and f.endswith('_import.json')
                                    ]
                                    logging.debug(f"Input files found: {json.dumps(input_parameter_files, indent=4)}")
                                    # Extract input parameter names from the directory
                                    input_parameter_names = [
                                        f.replace('input_parameter_', '').replace('_import.json', '')
                                        for f in input_parameter_files
                                    ]
                                    #print(f"The input count for workflow '{workflow_name}' is: {len(input_parameter_names)}")
                                    logging.debug(f"Input parameters found: {json.dumps(input_parameter_names, indent=4)}")

                                    # Import each input parameter
                                    for input_parameter_name in input_parameter_names:
                                        logging.debug(f"Processing input parameter: '{input_parameter_name}'...")
                                        result, message = import_input_parameter(input_parameter_name, workflow_name, access_token)
                                        if result == "ERROR":
                                            print(message)
                                            sys.exit(1)
                                        elif result == "REUSE":
                                            print(message)
                                        elif result == "CREATED":
                                            print(message)
                                        else:
                                            print(f"Unknown result '{result}' for input parameter '{input_parameter_name}'.")
                                            sys.exit(1)
                                else:
                                    logging.error(f"No input parameters found for workflow: '{workflow_name}'")
                                    sys.exit(1) # Stop the entire process if no input parameters are found

                            elif workflow_type == 'provision':
                                logging.debug(f"Handling provision workflow: '{workflow_name}'")
                                print(f"Skipping option lists and input parameters for provision workflow: '{workflow_name}'...")

                            # Step 7: Import sub-workflows if they exist
                            subworkflows_dir = os.path.join(os.path.dirname(__file__), '..', 'import', workflow_name, 'subworkflows')
                            subworkflow_id_map = {} # Initialize the sub-workflow ID mapping dictionary

                            if os.path.exists(subworkflows_dir):
                                logging.debug(f"Subworkflows directory found for workflow: '{workflow_name}' at path: {subworkflows_dir}")
                                print(f"Importing sub-workflows associated with the workflow: '{workflow_name}'...")

                                # Iterate through each sub-workflow folder
                                subworkflow_names = [
                                    name for name in os.listdir(subworkflows_dir)
                                    if os.path.isdir(os.path.join(subworkflows_dir, name))
                                ]
                                logging.debug(f"Sub-workflow names found: {subworkflow_names}")

                                if not subworkflow_names:
                                    logging.error(f"No sub-workflow found in directory: '{subworkflows_dir}' for workflow: '{workflow_name}'")
                                    sys.exit(1)

                                for subworkflow_name in subworkflow_names:
                                    logging.debug(f"Tasks directory found for sub-workflow: '{subworkflow_name}'...")
                                    subworkflow_status, subworklflow_message = import_subworkflow(subworkflow_name, workflow_name, access_token, subworkflow_id_map)
                                    if subworkflow_status == "ERROR":
                                        logging.error(f"Error importing sub-workflow '{subworkflow_name}': {subworklflow_message}")
                                        sys.exit(1)
                                    elif subworkflow_status in ["REUSE", "CREATED"]:
                                        print(subworklflow_message)
                                    else:
                                        logging.error(f"Unexpected result for Sub-workflow '{subworkflow_name}' : {subworkflow_status}")
                                        sys.exit(1)

                                # Log the final mapping of sub-workflow names to their new IDs
                                logging.debug(f"Final Sub-workflow ID mapping: {json.dumps(subworkflow_id_map, indent=4)}")
                                print(f"Sub-workflows imported successfully. ID mapping: {subworkflow_id_map}")

                            # Step 8: Import tasks associated with the workflow
                            logging.debug(f"Starting import of tasks for workflow: {workflow_name}")
                            tasks_dir = os.path.join(os.path.dirname(__file__), '..', 'import', workflow_name, 'tasks')
                            logging.debug(f"Tasks directory path: {tasks_dir}")

                            if os.path.exists(tasks_dir):
                                logging.debug(f"Importing tasks associated with the workflow: '{workflow_name}'")
                                print(f"Importing tasks associated with the workflow: '{workflow_name}'...")

                                # Extract task names from the directory
                                task_names = [
                                    os.path.splitext(file)[0].replace('task_', '', 1).replace('_import', '')
                                    for file in os.listdir(tasks_dir)
                                ]
                                logging.debug(f"Task names extracted: '{task_names}'...")

                                if not task_names:
                                    logging.error(f"No tasks found in directory: '{tasks_dir}' for workflow: '{workflow_name}'")
                                    sys.exit(1)

                                # Import each task
                                for task_name in task_names:
                                    logging.debug(f"Processing task: '{task_name}'...")
                                    task_status, task_message = import_task(task_name, workflow_name, access_token, subworkflow_id_map=subworkflow_id_map)
                                    # Handle the result of the task import
                                    if task_status == "ERROR":
                                        logging.error(f"Error import task '{task_name}': {task_message}")
                                        sys.exit(1)
                                    elif task_status in ["REUSE", "CREATED"]:
                                        print(task_message)
                                    else:
                                        logging.error(f"Unexpected result for task '{task_name}': {task_status}")
                                        sys.exit(1)

                            # Step 9: Import the selected workflow
                            logging.debug(f"Starting the import process for workflow '{workflow_name}'.")
                            print(f"Importing workflow '{workflow_name}'...")

                            logging.debug(f"Calling import_workflow for workflow: '{workflow_name}' with access token...")
                            status, message = import_workflow(workflow_name, access_token)
                            logging.debug(f"Result from import_workflow for workflow '{workflow_name}': {status}, Message: {message}")

                            # Handle the result of the workflow import
                            if status == "SUCCESS":
                                print(message)
                                # Add a visual separator after successfully importing a workflow
                                print("\n" + "-" * 80 + "\n") # Visual separator
                                break # Exit the loop after successful import of the workflow
                            elif status == "ERROR":
                                logging.error(message)
                                sys.exit(1)
                            else:
                                logging.error(f"Unexpected result from import_workflow: {status}")
                                sys.exit(1)
                        except Exception as e:
                            raise Exception(f"An error occurred while processing workflow '{workflow_name}': {e}")
                elif choice == "2":
                    layouts = list_layouts()
                    if not layouts:
                        print("No layouts available for import. Please ensure the 'import/layouts' directory contains layout configurations.")
                        return

                    print("\nAvailable layouts:")
                    for i, layout in enumerate(layouts, 1):
                        print(f'{i}. {layout}')

                    # Get user selection
                    while True:
                        try:
                            layout_choice = int(input("\nSelect a layout to import (enter the number): "))
                            if 1 <=layout_choice <= len(layouts):
                                selected_layout = layouts[layout_choice - 1]
                                break
                            else:
                                print(f"Invalid selection. Please enter a number between 1 and {len(layouts)}.")
                        except ValueError:
                            print("Invalid input. Please enter a number.")

                    # Import the selected layout
                    print(f"Starting import process for layout: {selected_layout}...")
                    status, message = import_layout(selected_layout, access_token)

                    if status == "SUCCESS":
                        print(message)
                        print("\n" + "-" * 80 + "\n") # Visual separator
                        break
                    else:
                        print(f"Error: {message}")
                        sys.exit(1) # Exit with a non-zero status code to indicate failure
                else:
                    print("Invalid choice. Please enter 1 or 2.")
                    continue # Ask again for valid input

            except ValueError:
                print("Invalid input. Please enter a number (1 or 2).")
                continue # Ask again for valid input

        # Program ends here after successful import
        print("Import process completed successfully.")
    except Exception as err:
        logging.error(f"An error occurred: {err}")
        sys.exit(1) # Exit with a non-zero status code to indicate failure


if __name__ == '__main__':
    main()
#!/usr/bin/env python3

# =============================================================================
# MORPHEUS WORKFLOW IMPORT SCRIPT v2 - CENTRALIZED STRUCTURE
# =============================================================================

# =============================================================================
# 1. STANDARD LIBRARY IMPORTS
# =============================================================================
import json
import os
import logging
import sys
import re

# =============================================================================
# 2. THIRD-PARTY LIBRARY IMPORTS
# =============================================================================
import requests
from requests.auth import HTTPBasicAuth
#from cryptography.fernet import Fernet

# =============================================================================
# 3. CONFIGURATION & LOGGING SETUP
# =============================================================================

def setup_logging():
    """
    Sets up logging configuration based on command-line arguments.
    Supports different log levels: ERROR (default), WARNING, INFO, DEBUG.
    """
    # Default log level is ERROR
    log_level = logging.ERROR

    # Parse command-line arguments for log levels
    if "--error" in sys.argv:
        log_level = logging.ERROR
        sys.argv.remove("--error")
    elif "--debug" in sys.argv:
        log_level = logging.DEBUG
        sys.argv.remove("--debug")
    elif "--warning" in sys.argv:
        log_level = logging.WARNING
        sys.argv.remove("--warning")
    elif "--info" in sys.argv:
        log_level = logging.INFO
        sys.argv.remove("--info")

    # Define a custom log format for DEBUG level that includes the line number
    log_format_debug = "%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"
    log_format_standard = "%(asctime)s - %(levelname)s - %(message)s"

    # Configure the logging module
    logging.basicConfig(
        level=log_level,
        format=log_format_debug if log_level == logging.DEBUG else log_format_standard
    )

    return log_level

def load_configuration():
    """
    Loads configuration from a JSON file.

    Returns:
        dict: The configuration data.
    """
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config.json')

    try:
        with open(config_path, 'r') as config_file:
            config = json.load(config_file)
        logging.debug(f"Configuration loaded successfully from: {config_path}")
        return config
    except FileNotFoundError:
        logging.error(f"Configuration file not found: {config_path}")
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    except json.JSONDecodeError as e:
        logging.error(f"Error decoding JSON from configuration file: {e}")
        raise ValueError(f"Invalid JSON in configuration file: {e}")

def load_encrypted_configuration():
    """
    Load encrypted Morpheus configuraition (future implementation)
    """
    #TODO: Implement encrypted configuration loading
    #key_path = os.path.join(os.path.dirname(__file__), 'vault.key')
    #with open(key_path, 'rb') as key_file:
    #    key = key_file.read()
    #
    ## Decrypt the credentials
    #enc_path = os.path.join(os.path.dirname(__file__), 'vault.enc')
    #with open(enc_path, 'rb') as enc_file:
    #    encrypted_data = enc_file.read()
    #
    #cipher = Fernet(key)
    #config = json.loads(cipher.decrypt(encrypted_data).decode())
    # return config
    pass

# =============================================================================
# 4. GLOBAL CONFIGURATION INITIALIZATION
# =============================================================================

# Initialize logging and configuration
log_level = setup_logging()
config = load_configuration()

# Extract Morpheus configuration for global access
morpheus_url = config['morpheus_url']
username = config['username']
password = config['password']
client_id = config['client_id']
client_secret = config['client_secret']

# SSL Certificate Configuration
# ssl_cert_path can be:
#   - Empty string or missing: SSL verification disabled
#   - Relative path: resolved relative to config.json location
#   - Absolute path: used as-is
ssl_cert_path = config.get('ssl_cert_path', '')

if ssl_cert_path:
    # Check if it's an absolute path
    if os.path.isabs(ssl_cert_path):
        cert_path = ssl_cert_path
    else:
        # Resolve relative path from config.json location
        cert_path = os.path.join(os.path.dirname(__file__), '..', ssl_cert_path)
    
    if os.path.isfile(cert_path):
        ssl_verify = cert_path
        logging.debug(f"SSL certificate path resolved to: {ssl_verify}")
    else:
        error_msg = f"SSL certificate file not found: {cert_path}"
        logging.error(error_msg)
        raise FileNotFoundError(error_msg)
else:
    ssl_verify = False
    logging.debug("SSL verification disabled (ssl_cert_path not specified)")

# Disable SSL warnings if SSL verification is disabled
if not ssl_verify:
    requests.packages.urllib3.disable_warnings(
        requests.packages.urllib3.exceptions.InsecureRequestWarning
    )
    logging.debug("SSL warnings disabled (ssl_verify=False).")
else:
    logging.debug("SSL verification enabled (ssl_verify=True).")

# =============================================================================
# 5. AUTHENTICATION
# =============================================================================

def Authenticate():
    """
    Authenticates with the Morpheus API and retrieves an access token.

    Returns:
        str: The access token for API authentication.

    Rasies:
        requests.exceptions.HTTPError: If the authentication request fails.
    """
    logging.debug("Entering Authenticate method and Starting authentication process...")
    auth_data = {
        'grant_type': 'password',
        'username': username,
        'password': password,
        'scope': 'write'
    }
    try:
        # Authenticate and get the access token using Basic Auth
        auth_response = requests.post(
            f'{morpheus_url}/oauth/token',
            data=auth_data,
            auth=HTTPBasicAuth(client_id, client_secret),
            verify=ssl_verify  # SSL verification controlled by config
        )
        logging.debug("Authentication request sent. Awaiting response...")
        auth_response.raise_for_status()
        access_token = auth_response.json()['access_token']
        logging.debug(f"Access token obtained successfully")
        logging.debug("Exiting Authenticate method with access token.")
        return access_token
    except requests.exceptions.HTTPError as err:
        logging.error(f"Authentication failed: {err}")
        logging.error(f"Response content: {auth_response.content.decode('utf-8')}")
        print("Error: Authentication failed. Please check your credentials and configuration.")
        sys.exit(1)

# =============================================================================
# 6. CORE UTILITY FUNCTIONS
# =============================================================================
def fetch_paginated_data(base_url, headers, resource_key, params=None, max_records=100, sort_field=None, sort_direction=None):
    """
    Fetches all records from a paginated API endpoint.

    Args:
        base_url (str): The base URL of the API endpoint.
        headers (dict): The headers for the API request.
        resource_key (str): The key in the API response that contains the list of records (e.g., 'tasks', 'optionTypeLists').
        params (dict): Additional parameters for the API request.
        max_records (int): The maximum number of records per page (default is 100).
        sort_field (str, optional): The field to sort the records by.
        sort_direction (str, optional): The direction to sort the records ('asc' or 'desc').

    Returns:
        list: A combined list of all records fetched from the API.

    Raises:
        Exception: If there is an issue with the API request or response
    """
    logging.debug(f"Fetching data from '{base_url}' with resource key '{resource_key}'...")
    if params is None:
        params = {}
    all_records = []
    current_offset = 0
    total_records_fetched = 0
    total_available_records = None # we'll get this from the API response

    try:
        while True:
            params.update({'offset': current_offset, 'max': max_records})
            if sort_field and sort_direction:
                params.update({'sort': sort_field, 'direction': sort_direction})

            logging.debug(f"Fetching data from '{base_url}' with params: '{params}'...")
            response = requests.get(base_url, headers=headers, params=params, verify=ssl_verify)  # SSL verification controlled by config
            response.raise_for_status()
            data = response.json()

            # Combine records from the current page
            current_records = data.get(resource_key, [])
            num_current_records = len(current_records)
            logging.debug(f"Number of records fetched for current request (offset={current_offset}): {num_current_records}")
            all_records.extend(current_records)
            total_records_fetched += num_current_records

            # check if all records are fetched
            meta = data.get('meta', {})
            logging.debug(f"Pagination Meta information: {json.dumps(meta, indent=4)}")
            if not meta:
                logging.warning(f"No 'meta' key found in the response for offset {current_offset}. Assuming last page.")
                break # exit the loop if no meta information is available

            # Get total from meta if not already known (from the first request)
            if total_available_records is None:
                total_available_records = meta.get('total')
                if total_available_records is None:
                    raise Exception("Error: 'total' key missing in API response meta for the first page.")
                logging.debug(f"Total records available reported by API: {total_available_records}")

            # Prepare for the next request
            current_offset += num_current_records

            # check if all records are fetched
            if total_records_fetched >= total_available_records:
                logging.debug(f"All {total_available_records} records fetched across {len(all_records) // max_records + (1 if len(all_records) % max_records > 0 else 0)} pages (actual requests).")
                break

        logging.debug(f"Total records fetched: {len(all_records)}")
        return all_records

    except requests.exceptions.RequestException as e:
        error_message = (
            f"Error: Unable to fetch data from the API endpoint '{base_url}'. "
            "Please check your network connection, ensure the API is reachable, and verify your authentication credentials. "
            "Restart the script after resolving the issue."
        )
        logging.error(error_message)
        logging.error(f"Details: {e}")
        raise Exception(error_message)

    except KeyError as e:
        error_message = (
            f"Error: Unexpected response structure from the API. Missing key '{e}'. "
            "Please ensure the API response format matches the expected structure. "
            "Contact support if the issue persists."
        )
        logging.error(error_message)
        logging.error(f"Response content: {response.text}")
        raise Exception(error_message)

    except Exception as e:
        error_message = (
            "Error: An unexpected error occurred while fetching data. "
            "Please contact support with the following details."
        )
        logging.error(error_message)
        logging.error(f"Detailed error: {e}")
        raise Exception(error_message)

def sanitize_name(name):
    """
    Sanitizes the name by removing leading and trailing whitespace.
    Preserves the original case and internal spaces.

    Args:
        name (str): The name to sanitize.

    Returns:
        str: The sanitized name.
    """
    if not name:
        return ""
    return name.strip()

def clean_field_name(field_name):
    """
    Cleans the field name by removing leading and trailing whitespace and converting to lowercase.

    Args:
        field_name (str): The field name to clean.

    Returns:
        str: The cleaned field name.
    """
    if not field_name:
        return ""
    cleaned_field_name = re.sub(r'\s+', '', field_name).strip().lower()
    if ' ' in field_name or field_name != cleaned_field_name:
        logging.error(f"Field name '{field_name}' is invalid. It should be lowercase and have no spaces. "
                      f"Cleaned version: '{cleaned_field_name}'")
    return cleaned_field_name

def clean_description(description):
    """
    Cleans the description text by removing leading and trailing whitespace.

    Args:
        text (str): The description text to clean.

    Returns:
        str: The cleaned description text.
    """
    if not description:
        return ""
    return description.strip()

def convert_memory_memory_bytes_to_mb(memory_bytes):
    """
    Convert memory from bytes to MB from Morpheus API.

    Args:
        memory_bytes (int or float): Memory in bytes from layout export.

    Returns:
        str: Memory in MB as required by API
    """
    if memory_bytes is None or memory_bytes == 0:
        return None

    try:
        memory_mb = int(memory_bytes) // (1024 ** 2)
        return str(memory_mb)
    except (ValueError, TypeError) as e:
        logging.warning(f"Error converting memory value: '{memory_bytes}': {e}")
        return None

# =============================================================================
# 7. FILE DISCOVERY & METADATA EXTRACTION
# =============================================================================
def find_component_file_by_name(component_dir, component_name):
    """
    Find component file in centralize directory by matching sanitized name.
    Handles hash-based filename discovery.

    Args:
        component_dir (str): The directory where component files are stored.
        component_name (str): The sanitized name of the component to find.

    Returns:
        str: Full path to component file, or None if not found.
    """
    if not os.path.exists(component_dir):
        logging.error(f"Component directory does not exist: {component_dir}")
        return None

    # Convert component name to sanitized form for matching
    sanitized_search = re.sub(r'[<>:"/\\|?*\s()-]+', '_', component_name)
    sanitized_search = re.sub(r'_+', '_', sanitized_search).strip('_')

    logging.debug(f"Searching for component '{component_name}' with sanitized name '{sanitized_search}' in directory '{component_dir}'")

    for file in os.listdir(component_dir):
        if file.endswith('.json'):
            base_name = file.replace('.json', '')
            parts = base_name.split('_')
            if len(parts) >= 2:
                potential_hash = parts[-1]
                if len(potential_hash) == 8 and all(c in '0123456789abcdef' for c in potential_hash.lower()):
                    file_component_name = '_'.join(parts[:-1])
                    if file_component_name == sanitized_search:
                        full_path = os.path.join(component_dir, file)
                        logging.debug(f"Found matching component file: {full_path}")
                        return full_path

    logging.debug(f"Component file not found for '{component_name}' in directory '{component_dir}'")
    return None

def extract_workflow_info_from_file(file_path):
    """
    Extract workflow metadata from the acutal JSON file.
    This give us accurate name and description for duplicate detection.
    """
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)

        if "taskSet" not in data:
            return None

        task_set = data["taskSet"]
        return {
            'name': task_set.get('name', ''),
            'description': task_set.get('description', ''),
            'type': task_set.get('type', '')
        }
    except Exception as e:
        logging.error(f"Error reading workflow file '{file_path}': {e}")
        return None

def create_user_friendly_workflow_names(workflow_entries):
    """
    Create user-friendly display names, showing distinguishing details for duplicates.
    """
    #Group workflows by clean name
    name_groups = {}
    for entry in workflow_entries:
        clean_name = entry['name']
        if clean_name not in name_groups:
            name_groups[clean_name] = []
        name_groups[clean_name].append(entry)

    display_names = []

    for clean_name, entries in name_groups.items():
        if len(entries) == 1:
            # Single entry - show clean name only
            display_names.append({
                'display_name': clean_name,
                'filename': entries[0]['filename'],
                'metadata': entries[0]
            })
        else:
            # Multiple entries - show distinguishing details
            for entry in entries:
                description = entry.get('description', 'No description')

                if len(description) > 50:
                    display_description = f"{description[:47]}..."
                else:
                    display_description = description

                # create distinguishing display name
                display_name = f"{clean_name} - \"{display_description}\""

                display_names.append({
                    'display_name': display_name,
                    'filename': entry['filename'],
                    'metadata': entry
                })

    # Sort by workflow type first (operational before provisioning)
    def sort_key(item):
        workflow_type = item['metadata'].get('type', 'operation').lower()
        # Operational = 0, provisioning = 1 for sorting order
        type_priority = 0 if workflow_type == 'operation' else 1
        return (type_priority, item['display_name'])

    display_names.sort(key=sort_key)

    return display_names

def extract_layout_info_from_file(file_path):
    """
    Extract layout metadata from the actual JSON file.
    This gives us accurate name and description for duplicate detection.

    Args:
        file_path (str): Path to the layout JSON file

    Returns:
        dict: Layout metadata or None if extraction fails
    """
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)

        if "instanceTypeLayout" not in data:
            return None

        instance_type_layout = data["instanceTypeLayout"]
        return {
            'name': instance_type_layout.get('name', ''),
            'description': instance_type_layout.get('description', ''),
            'instanceType': instance_type_layout.get('instanceType', {}).get('name', '')
        }
    except Exception as e:
        logging.error(f"Error reading layout file '{file_path}': {e}")
        return None

def create_user_friendly_layout_names(layout_entries):
    """
    Create user-friendly display names for layouts, showing distinguishing details for duplicates.

    Args:
        layout_entries (list): List of layout metadata entries

    Returns:
        list: Processed layout entries with display names
    """
    # Group layouts by clean name
    logging.debug(f"Processing layout_entries: {json.dumps(layout_entries, indent=4)} entries")

    name_groups = {}
    for entry in layout_entries:
        clean_name = entry['name']
        if clean_name not in name_groups:
            name_groups[clean_name] = []
        name_groups[clean_name].append(entry)

    logging.debug(f"Name_groups = {json.dumps(name_groups, indent=4)} unique names")


    display_names = []

    for clean_name, entries in name_groups.items():
        if len(entries) == 1:
            # Single entry - show clean name only
            display_names.append({
                'display_name': clean_name,
                'filename': entries[0]['filename'],
                'metadata': entries[0]
            })
        else:
            # Multiple entries - show distinguishing details
            logging.debug(f"Multiple entries for '{clean_name}': {len(entries)} entries")
            for i, entry in enumerate(entries):
                distinguishing_details = []

                # Add instance type if available
                if entry.get('instanceType'):
                    distinguishing_details.append(f"Instance Type: {entry['instanceType']}")

                # Add description if available (show more characters for better distinction)
                if entry.get('description'):
                    # Show first 80 chars of description for better distinction
                    desc_preview = entry['description'][:80] + ('...' if len(entry['description']) > 80 else '')
                    distinguishing_details.append(f"Desc: {desc_preview}")

                # If we still can't distinguish, add filename hash
                if len(distinguishing_details) == 0 or (len(entries) > 1 and all(
                    e.get('instanceType') == entry.get('instanceType') and
                    e.get('description', '')[:80] == entry.get('description', '')[:80]
                    for e in entries
                )):
                    # Extract hash from filename for final distinction
                    filename_parts = entry['filename'].replace('.json', '').split('_')
                    if len(filename_parts) >= 2:
                        hash_part = filename_parts[-1]
                        distinguishing_details.append(f"Hash: {hash_part}")

                detail_str = f" ({', '.join(distinguishing_details)})" if distinguishing_details else " (No details)"

                display_name = f"{clean_name}{detail_str}"
                display_names.append({
                    'display_name': display_name,
                    'filename': entry['filename'],
                    'metadata': entry
                })
                logging.debug(f"Multiple entries: {display_name}")

    # Sort display names for consistent ordering
    display_names.sort(key=lambda x: x['display_name'])

    return display_names

# =============================================================================
# 8. COMPONENT LISTING FUNCTIONS (Discovery)
# =============================================================================
def list_workflows():
    """
    List available workflows from centralized morpheus_configuraiton/workflows/ directory.
    Discover workflows from hash-based filenames and extracts original names.
    shows clean names with distinguishing details for duplicates.

    Returns:
        list: A list of workflow names available for import.

    Raises:
        FileNotFoundError: If the 'import' directory does not exist.
    """
    logging.debug("Entering list_workflows method for centralized structure...")

    # Update to centralized structure path
    workflows_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'workflows')
    logging.debug(f"Workflows directory path: {workflows_dir}")

    if not os.path.exists(workflows_dir):
        logging.error(f"The centralized workflows directory does not exist at path: {workflows_dir}")
        raise FileNotFoundError(f"The centralized workflows directory does not exist at path: {workflows_dir}")

    # Discover workflow files (hash-based filenames)
    workflow_files = [f for f in os.listdir(workflows_dir) if f.endswith('.json')]

    if not workflow_files:
        logging.warning("No workflow files found in the centralized workflows directory.")
        return []

    # Parse workflow files and extract metadata
    workflow_entries = []
    for file in workflow_files:
        workflow_info = extract_workflow_info_from_file(os.path.join(workflows_dir, file))
        if workflow_info:
            workflow_info['filename'] = file
            workflow_entries.append(workflow_info)
    logging.debug(f"Extracted workflow entries: {workflow_entries}")

    # Group by component name and create user-friendly display names
    display_names = create_user_friendly_workflow_names(workflow_entries)

    logging.debug(f"User-friendly workflow names: {display_names}")
    return display_names

def list_layouts(): # FUTURE: Update for centralized structure
    """
    List available layouts from centralized 'morpheus_configuration/layouts' directory.
    Discovers layouts from hash-based filenames and extract original names.

    Returns:
        list: A list of layout names available for import.

    Raises:
        FileNotFoundError: If the 'import' directory does not exist.
    """
    logging.debug("Entering list_layouts method for centralized structure...")

    # Update to centralized structure path
    layouts_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'layouts')
    logging.debug(f"Layouts directory path: {layouts_dir}")

    if not os.path.exists(layouts_dir):
        logging.error(f"The centralized layouts directory does not exist at path: {layouts_dir}")
        raise FileNotFoundError(f"The centralized layouts directory does not exist at path: {layouts_dir}")

    # Discover layout files (hash-based filenames) - look for sanitized versions for import
    layout_files = [f for f in os.listdir(layouts_dir) if f.endswith('.json')]

    if not layout_files:
        logging.warning("No layout files found in the centralized layouts directory.")
        return []

    # Parse layout files and extract metadata
    layout_entries = []
    for file in layout_files:
        layout_info = extract_layout_info_from_file(os.path.join(layouts_dir, file))
        if layout_info:
            layout_info['filename'] = file
            layout_entries.append(layout_info)
    logging.debug(f"Extracted layout entries: {layout_entries}")

    # Group by component name and create user-friendly display names
    display_names = create_user_friendly_layout_names(layout_entries)

    logging.debug(f"User-friendly layout names: {display_names}")
    return display_names

# =============================================================================
# 9. USER INTERFACE & SELECTION
# =============================================================================
def get_import_type_choice():
    """
    Handle main import type selection with proper error handling

    Returns:
        str: Selected import type ('1' for workflows, '2' for layouts) or None if cancelled
    """
    print("\n" + "="*60)
    print("🚀 MORPHEUS COMPONENT IMPORT TOOL v2")
    print("="*60)
    print("\nSelect the type of import:")
    print("1. Import Workflow(s) with Dependencies")
    print("2. Import Layout(s) with Dependencies")
    print("="*60)

    # Step 3: Get user choice and delegate to clean handlers
    while True:
        try:
            choice = input("\n🎯 Select import option (1 or 2): ").strip()

            if choice in ['1', '2']:
                return choice
            else:
                print("❌ Invalid choice. Please enter 1 or 2.")
        except KeyboardInterrupt:
            print("\n🛑 Import selection cancelled by user.")
            return None

def get_workflow_selection():
    """
    Handle workflow selection UI with batch import options

    Returns:
        list: List of selected workflow into dictionaries, or empty list if cancelled
    """
    logging.debug("Loading workflows from centralized directory...")
    workflow_displays = list_workflows()

    logging.debug(f"Workflows available for import: {json.dumps(workflow_displays, indent=4)}") # debug purpose, delete la

    if not workflow_displays:
        return None

    print(f"\n📋 Found {len(workflow_displays)} workflow(s) available for import:")
    for i, workflow_info in enumerate(workflow_displays, 1):
        print(f'{i}. {workflow_info["display_name"]}')

    print(f"\n🎯 Batch Import Options:")
    print(f'{len(workflow_displays) + 1}. Import all Workflows') # Highlight "All Workflows"

    # Step 3: Prompt the user to select a workflow
    while True:
        try:
            choice = int(input(f"\n➤ Select workflow to import (1-{len(workflow_displays) + 1}): "))

            if 1 <= choice <= len(workflow_displays):
                # Single workflow selection
                selected_workflow_info = workflow_displays[choice - 1]
                return [{'name': selected_workflow_info['metadata']['name'],
                        'filename': selected_workflow_info['filename']}]
            elif choice == len(workflow_displays) + 1:
                # All Workflows Selection
                return [{'name': wf['metadata']['name'], 'filename': wf['filename']}
                       for wf in workflow_displays]
            else:
                print(f"❌ Invalid choice. Please enter a number between 1 and {len(workflow_displays) + 1}.")
        except ValueError:
            print("❌ Invalid input. Please enter a number.")
        except KeyboardInterrupt:
            return []

def get_layout_selection():
    """
    Handle layout selection UI with batch import options

    Returns:
        list: List of selected laoyut info dictionaries, or empty list if cancelled
    """
    logging.debug("Loading layouts from centralized directory...")
    layout_displays = list_layouts()

    logging.debug(f"Layouts available for import: {json.dumps(layout_displays, indent=4)}")

    if not layout_displays:
        return None

    print(f"\n📋 Found {len(layout_displays)} layout(s) available for import:")
    for i, layout_info in enumerate(layout_displays, 1):
        print(f'{i}. {layout_info["display_name"]}')

    print(f"\n🎯 Batch Import Options:")
    print(f'{len(layout_displays) + 1}. Import all Layouts')

    # Prompt user to select a layout
    while True:
        try:
            choice = int(input(f"\n➤ Select layout to import (1-{len(layout_displays) + 1}): "))

            if 1 <= choice <= len(layout_displays):
                # Single layout selection
                selected_layout_info = layout_displays[choice - 1]
                return [{'name': selected_layout_info['metadata']['name'],
                        'filename': selected_layout_info['filename']}]
            elif choice == len(layout_displays) + 1:
                # All Layouts Selection
                return [{'name': layout['metadata']['name'], 'filename': layout['filename']}
                       for layout in layout_displays]
            else:
                print(f"❌ Invalid choice. Please enter a number between 1 and {len(layout_displays) + 1}.")
        except ValueError:
            print("❌ Invalid input. Please enter a number.")
        except KeyboardInterrupt:
            return []

# =============================================================================
# 10. DEPENDENCY ANALYSIS ENGINE
# =============================================================================
def analyze_workflow_task_dependencies(workflow_data):
    """
    Analyze workflow JSON to extract required tasks and their conditional subworkflows.
    works for both operation and provision workflow types.

    Args:
        workflow_data (dict): The JSON data of the workflow.

    Returns:
        tuple: (required_tasks, required_subworkflows)
    """
    required_tasks = set()
    required_subworkflows = set()

    task_set_tasks = workflow_data.get('taskSet', {}).get('taskSetTasks', [])

    # Extract tasks directly from workflow
    for task_set_task in task_set_tasks:
        task_info = task_set_task.get('task', {})
        task_name = task_info.get('name')

        if task_name:
            required_tasks.add(task_name)
            logging.debug(f"Found task '{task_name}' in workflow")

            # Check if this task might be a conditional workflow by loading its JSON
            task_subworkflows = analyze_task_for_conditional_subworkflows(task_name)
            required_subworkflows.update(task_subworkflows)

    # Extract tasks from the subworkflows themselves
    for subworkflow_name in required_subworkflows.copy(): # use copy to avoid modification during iteration
        subworkflow_tasks = extract_tasks_from_subworkflow(subworkflow_name)
        required_tasks.update(subworkflow_tasks)
        logging.debug(f"Found {len(subworkflow_tasks)} tasks in subworkflow '{subworkflow_name}': {subworkflow_tasks}")

    return required_tasks, required_subworkflows

def extract_tasks_from_subworkflow(subworkflow_name):
    """
    Load subworkflow JSON from centralized directory and extract its tasks.

    Args:
        subworkflow_name (str): Name of the subworkflow to analyze

    Returns:
        set: Set of task names used by this subworkflow.
    """
    tasks = set()

    # load subworkflow from centralized directory
    subworkflows_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'subworkflows')
    subworkflow_file_path = find_component_file_by_name(subworkflows_dir, subworkflow_name)

    if not subworkflow_file_path:
        logging.warning(f"Subworkflow file not found for subworkflow '{subworkflow_name}' in centralized structure.")
        return tasks

    try:
        with open(subworkflow_file_path, 'r') as f:
            subworkflow_data = json.load(f)

        # Extract tasks from subworkflow
        task_set_tasks = subworkflow_data.get('taskSet', {}).get('taskSetTasks', [])

        for task_set_task in task_set_tasks:
            task_info = task_set_task.get('task', {})
            task_name = task_info.get('name')

            if task_name:
                tasks.add(task_name)
                logging.debug(f"Found task '{task_name}' in subworkflow '{subworkflow_name}'")
    except Exception as e:
        logging.error(f"Error extracting tasks from subworkflow '{subworkflow_name}': {e}")

    return tasks

def analyze_task_for_conditional_subworkflows(task_name):
    """
    Load task JSON from centralized directory and chek if it references subworkflows.

    Args:
        task_name (str): Name of the task to analyze

    Returns:
        set: A set of subworkflow names referenced by the task.
    """
    subworkflows = set()

    # Load task from centralized directory
    tasks_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'tasks')
    task_file_path = find_component_file_by_name(tasks_dir, task_name)

    if not task_file_path:
        logging.debug(f"Task file not found for task '{task_name}' in centralized structure.")
        return subworkflows

    try:
        with open(task_file_path, 'r') as f:
            task_data = json.load(f)

        # Check if it's a conditional workflow task
        task_type_code = task_data.get("task", {}).get("taskType", {}).get("code")
        if task_type_code == "conditionalWorkflow":
            task_options = task_data.get("task", {}).get("taskOptions", {})

            # Extract subworkflow names
            if_workflow = task_options.get("ifOperationalWorkflowName")
            else_workflow = task_options.get("elseOperationalWorkflowName")

            if if_workflow:
                subworkflows.add(if_workflow)
                logging.debug(f"Found 'if' subworkflow: '{if_workflow}' in task '{task_name}'")

            if else_workflow:
                subworkflows.add(else_workflow)
                logging.debug(f"Found 'else' subworkflow: '{else_workflow}' in task '{task_name}'")
    except Exception as e:
        logging.error(f"Error analyzing task '{task_name}' for subworkflows: {e}")

    return subworkflows

# =============================================================================
# 11. EXISTENCE CHECKING UTILITIES
# =============================================================================
def check_existing_workflow(workflow_name, access_token, workflow_description=None):
    """
    Checks if a workflow with the given name (and optionally description) already exists in the target instance.

    Args:
        workflow_name (str): The name of the workflow to check.
        access_token (str): The access token for authentication API requests.
        workflow_descriotion(str, optional): Description of precise matching.
                                            If None, uses name-only matching.

    Returns:
        dict: The existing workflow data if found, otherwise None.

    Note: When workflow_description is None (layout context), name-only matching is used with warnings if multiple workflows found.
    """
    logging.debug(f"Checking if the workflow '{workflow_name}' already exists. Description={'provided' if workflow_description else 'none'}")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
        }

    # Fetch all existing workflows using the centralized pagination function
    logging.debug("Fetching existing workflows from the target instance...")
    existing_workflows = fetch_paginated_data(
        f'{morpheus_url}/api/task-sets',
        headers,
        resource_key='taskSets',
    )
    logging.info(f"Total existing workflows fetched: {len(existing_workflows)}")

    # Find and return the workflow with the matching name
    matching_by_name = [wf for wf in existing_workflows if wf['name'].strip() == workflow_name.strip()]

    if not matching_by_name:
        logging.debug(f"No workflows found with name '{workflow_name}'.")
        return None

    # If no description provided (layout context), use name-only matching
    if workflow_description is None:
        if len(matching_by_name) == 1:
            return matching_by_name[0]
        else:
            # Multiple workflows with same name - warn and use first
            logging.warning(f"WARNING: Found {len(matching_by_name)} workflows with name '{workflow_name}'. "
                          f"Using first match (ID: {matching_by_name[0]['id']}) due to layout import limitation. "
                          f"Consider using unique workflow names.")
            return matching_by_name[0] # I have doubt here, need clarify with Sonja

    # Description provided - do precise matching
    clean_target_description = clean_description(workflow_description)
    for workflow in matching_by_name:
        existing_description = clean_description(workflow.get('description', ''))
        if existing_description == clean_target_description:
            logging.debug(f"Workflow '{workflow_name}' with matching description found (ID: {workflow['id']}")
            return workflow

    logging.debug(f"Workflow '{workflow_name}' found by name but description mismatch. "
                 f"Expected: '{clean_target_description}'. "
                 f"Existing: {[clean_description(wf.get('description', '')) for wf in matching_by_name]}")
    return None

def check_existing_layout(layout_name, layout_description, access_token): #<- LAYOUT SECTION
    """
    Checks if a layout with the given name already exists in the target instance.
    Optimized with SAP-specific server-side filtering for better performance.

    Args:
        layout_name (str): The name of the layout to check.
        layout_description (str): The description of the layout to check.
        access_token (str): The access token for authentication API requests.

    Returns:
        dict: The existing layout data if found, otherwise None.
    """
    logging.debug(f"Checking if layout '{layout_name}' already exists globally...")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    try:
        # First, get all layouts for the specific instance type
        existing_layouts = fetch_paginated_data(
            f'{morpheus_url}/api/library/layouts',
            headers,
            resource_key='instanceTypeLayouts',
            params={'phrase': 'SAP'}, # Server-side filtering for SAP layouts
            max_records=100,
            sort_field='name',
            sort_direction='asc'
        )
        logging.info(f"Total existing layouts fetched globally: {len(existing_layouts)}")

        # Clean the layout description for comparison
        clean_layout_description = clean_description(layout_description)

        # Find all layouts matching by name
        matching_by_name = [layout for layout in existing_layouts
                            if layout['name'].strip() == layout_name.strip()]

        if not matching_by_name:
            logging.debug(f"No Layouts found with name '{layout_name}'.")
            return None

        # Among those with matching name, find one with matching description
        for layout in matching_by_name:
            existing_description = clean_description(layout.get('description', ''))
            if existing_description == clean_layout_description:
                logging.debug(f"Layout '{layout_name}' with description '{layout_description}' already exists with ID {layout['id']}")
                return layout

        logging.debug(f"Layout '{layout_name}' found by name but description mismatch. "
                    f"Expected: '{clean_layout_description}'. "
                    f"Existing: {[clean_description(l.get('description', '')) for l in matching_by_name]}")
        return None

    except Exception as e:
        logging.error(f"Error checking existing layouts: {e}")
        return None

def check_existing_container_type_by_name(container_name, access_token): #<- LAYOUT SECTION
    """
    Check if a container type exists by name only
    """
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{morpheus_url}/api/library/container-types", headers=headers, verify=ssl_verify)

        if response.status_code == 200:
            container_types = response.json().get("containerTypes", [])

            # Match by name (case-insensitive)
            if container_name:
               name_match = next((ct for ct in container_types if ct["name"].lower() == container_name.lower()), None)
               return name_match
        return None
    except Exception as e:
        logging.error(f"Error checking existing container type '{container_name}': {e}")
        return None

# =============================================================================
# 12. FOUNDATION COMPONENT IMPORT
# =============================================================================
def import_option_list(option_list_name, access_token):
    """
    Imports an option list into the target instance from centralized directory.

    Args:
        option_list_name (str): The name of the option list to import.
        access_token (str): The access token for authentication API requests.

    Returns:
        tuple: ("REUSE", message), ("CREATED", message), or ("ERROR", message)
    """
    logging.debug(f"Entering import_option_list method for option list: {option_list_name}")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    options_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'option_lists')
    import_path = find_component_file_by_name(options_dir, option_list_name)

    if not import_path:
        error = (
            f"Error: Import file not found for option list '{option_list_name}' in centralized structure.\n"
            f"Searched in: {options_dir}\n"
            "Please ensure the file exists and retry the import process."
        )
        return "ERROR", error
    logging.debug(f"Using import path for option list: {import_path}")

    # Load option list data from JSON file
    logging.debug(f"Loading option list data from file: {import_path}")
    with open(import_path, 'r') as json_file:
        option_list_data = json.load(json_file)
    logging.debug(f"Loaded option list data: {json.dumps(option_list_data, indent=4)}")

    # Extract import description for comparison
    import_description = clean_description(option_list_data["optionTypeList"].get("description", ""))
    logging.debug(f"Import option list description: '{import_description}'")

    # Fetch existing option lists
    logging.debug("Fetching existing option lists from the target instance...")
    existing_option_lists = fetch_paginated_data(
        f'{morpheus_url}/api/library/option-type-lists',
        headers,
        resource_key='optionTypeLists',
    )
    logging.debug(f"Total existing option lists fetched: {len(existing_option_lists)}")
    logging.debug(f"Fetched existing option lists: {json.dumps(existing_option_lists, indent=4)}")

    # check if the option list already exists
    logging.debug(f"Checking if option list '{option_list_name}' already exists with matching description...")

    # Find all option lists with matching name (case-insensitive)
    matching_by_name = [ol for ol in existing_option_lists
                        if ol['name'].strip().lower() == option_list_name.strip().lower()]

    if matching_by_name:
        # Check for exact match with description
        for existing_ol in matching_by_name:
            existing_description = clean_description(existing_ol.get('description', ''))

            if existing_description == import_description:
                logging.debug(f"Found exact match: name and description both match for option list '{option_list_name}'")
                return "REUSE", f"REUSE: Option list '{option_list_name}' with matching description already exists in target instance with ID {existing_ol['id']}. Reusing existing component."

        # Name matches but description differs - potential conflict
        existing_descriptions = [clean_description(ol.get('description', '')) for ol in matching_by_name]
        error = (
            f"[OPTION LIST CONFLICT] Option list name '{option_list_name}' already exists with different description.\n"
            f"Import description: '{import_description}'\n"
            f"Existing description(s): {existing_descriptions}\n"
            f"RESOLUTION: Rename the existing option list in Morpheus (e.g., '{option_list_name} Legacy') to resolve the conflict.\n"
            f"NOTE: This ensures precise matching and prevents unintended data mixing."
        )
        return "ERROR", error

    # No conflicts - create new option list
    logging.debug(f"Option list '{option_list_name}' does not exist. Creating a new option list...")
    try:
        response = requests.post(f'{morpheus_url}/api/library/option-type-lists', headers=headers, json=option_list_data, verify=ssl_verify)
        response.raise_for_status()
        new_option_list_id = response.json()['optionTypeList']['id']
        return "CREATED", f"CREATED: Option list '{option_list_name}' successfully created in target instance with ID {new_option_list_id}."
    except requests.exceptions.HTTPError as err:
        error = (
            f"Error: Failed to import option list '{option_list_name}'.\n"
            f"HTTP Error: {err}\n"
            f"Response: {response.content.decode('utf-8')}"
        )
        return "ERROR", error

def import_input_parameter(input_parameter_name,access_token):
    """
    Imports an input parameter into the target instance.

    Args:
        input_parameter_name (str): The name of the input parameter to import.
        access_token (str): The access token for authentication API requests.

    Returns:
        tuple: ("REUSE", message), ("CREATED", message), or ("ERROR", message)

    Raises:
        Exception: If the input parameter fails to import.
    """
    logging.debug(f"Entering  import_input_parameter method for input parameter: '{input_parameter_name}' from centralized directory...")

    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    inputs_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'inputs')
    import_path = find_component_file_by_name(inputs_dir, input_parameter_name)

    if not import_path:
        error = (
            f"Error: Import file not found for input parameter '{input_parameter_name}' in centralized structure.\n"
            f"Searched in: {inputs_dir}\n"
            "Please ensure the file exists and retry the import process."
        )
        return "ERROR", error

    logging.debug(f"Using import path for input parameter: {import_path}")

    # Load the input parameter data from the JSON file
    with open(import_path, 'r') as json_file:
        input_parameter_data = json.load(json_file)
    logging.debug(f"Loaded input parameter data: {json.dumps(input_parameter_data, indent=4)}")

    # Step 2: Validate the name, fieldName and description field for input parameter
    input_name = sanitize_name(input_parameter_data["optionType"]["name"])
    input_fieldname = clean_field_name(input_parameter_data["optionType"]["fieldName"])
    input_description = clean_description(input_parameter_data["optionType"].get("description", ""))
    logging.debug(f"Sanitized input parameter details: name='{input_name}', fieldName='{input_fieldname}', description='{input_description}'")

    # Step 2a: check if the description or the fieldName is missing or empty for an input parameter
    missing_fields = []
    if not input_description:
        missing_fields.append("description")
    if not input_fieldname:
        missing_fields.append("fieldName")

    if missing_fields:
        error = (
            f"Error: Missing or empty fields for input parameter '{input_parameter_name}'.\n"
            f"Ensure 'description' and 'fieldName' are provided in the imported JSON file: {', '.join(missing_fields)}.\n"
            "Please include these fields in the import file and retry the import process."
        )
        return "ERROR", error

    # Step 3: Fetch existing input parameters from the target instance
    logging.debug("Fetching existing input parameters from the target instance...")

    existing_input_parameters = fetch_paginated_data(
        f'{morpheus_url}/api/library/option-types',
        headers,
        resource_key='optionTypes',
    )
    logging.info(f"existing input parameters: {len(existing_input_parameters)}")
    logging.debug(f"Fetched existing input parameters: {json.dumps(existing_input_parameters, indent=4)}")

    # Step 4: find all with matching name
    matching_by_name = [ip for ip in existing_input_parameters if sanitize_name(ip['name']) == input_name]
    logging.debug(f"Matching option found: {json.dumps(matching_by_name, indent=4) if matching_by_name else 'None'}")
    #print(f"Debug-1: Matching input parameters by name: {len(matching_by_name)} for input name: '{input_name}'.") # debug purpose, delete later

    # step 4a: check for fieldName conflicts
    conflicting_fieldNames = [ip for ip in matching_by_name if clean_field_name(ip['fieldName']) != input_fieldname]
    if conflicting_fieldNames:
        # conflict: same name, different fieldName
        error = (
            f"[FIELDNAME CONFLICT] Input Parameter Name: '{input_name}'\n"
            f" - Existing fieldNames in target instance: {[ip['fieldName'] for ip in conflicting_fieldNames]}\n"
            f" - fieldName in import file: '{input_fieldname}'\n"
            "RESOLUTION: Rename the existing input parameter in Morpheus to resolve this conflict.\n"
            "IMPORTANT: Do Not Modify the fieldName in the import JSON as fieldNames are required for task dependencies.\n"
            "Example: Rename existing parameter from '{input_name}' to '{input_name} Legacy' in Morpheus, then retry import."
        )
        return "ERROR", error

    #print(f"name and fieldname matched, till her no conflicts found for input name: '{input_name}'.") # debug purpose, delete later

    # Step 4b: check for description match among those with same name and fieldName
    matching_by_name_and_field = [
        ip for ip in matching_by_name if clean_field_name(ip['fieldName']) == input_fieldname
    ]
    logging.debug(f"Matching input parameters by name and fieldName: {json.dumps(matching_by_name_and_field, indent=4) if matching_by_name_and_field else 'None'}")
    #print(f"Debug-2: matched name and fieldName= {len(matching_by_name_and_field)} for input name: '{input_name}'.") # debug purpose, delete later

    # If any match with same description, REUSE
    for ip in matching_by_name_and_field:
        existing_description = clean_description(ip.get('description', ''))
        if existing_description == input_description:
            option_list_info = ""
            if "optionList" in input_parameter_data["optionType"] and input_parameter_data["optionType"]["optionList"] is not None:
                option_list_name = input_parameter_data["optionType"]["optionList"]["name"]
                option_list_info = f" → Uses option list '{option_list_name}'"

            message = (
                f"REUSE: Input parameter '{input_name}' with fieldName '{input_fieldname}' and description '{input_description}' matches existing. Reusing it with ID '{ip['id']}'.{option_list_info}"
            )
            logging.info(message)
            return "REUSE", f"REUSE: Input parameter '{input_parameter_name}' already exists in target instance with ID {ip['id']}. Reusing existing component."

    # If no match with same description, allow versioning (create new)
    # But check if any of the existing have empty description (should not happen, but warn)
    for ip in matching_by_name_and_field:
        if not clean_description(ip.get('description', '')):
            error = (
                f"Error: Existing input parameter '{input_name}' with fieldName '{input_fieldname}' in Morpheus has an empty description.\n"
                f"Expected description: '{input_description}'\n"
                "Please update the description in Morpheus or rename the existing input parameter, then retry."
            )
            return "ERROR", error

    # Step 5: Resolve option list if it exists
    option_list_info = ""
    if "optionList" in input_parameter_data["optionType"] and input_parameter_data["optionType"]["optionList"] is not None:
        option_list_name = input_parameter_data["optionType"]["optionList"]["name"]
        logging.debug(f"Resolving option list for input parameter '{input_parameter_name}': {option_list_name}")

        # Use fetch_paginated_data to get all option lists
        existing_option_lists = fetch_paginated_data(
            f'{morpheus_url}/api/library/option-type-lists',
            headers,
            resource_key='optionTypeLists',
        )
        logging.info(f"Total existing option lists fetched: {len(existing_option_lists)}")
        # Find the matching option list by name
        option_list = next((ol for ol in existing_option_lists if ol['name'] == option_list_name), None)
        if option_list:
            input_parameter_data["optionType"]["optionList"]["id"] = option_list["id"]
            option_list_info = f" → Option list '{option_list_name}' resolved (ID: {option_list['id']})"
            logging.debug(f"Resolved option list '{option_list_name}' with ID {option_list['id']} for input parameter '{input_parameter_name}'.")
        else:
            error = (
                f"Error: Option list '{option_list_name}' not found in Morpheus instance.\n "
                "Please import the required option list first, then retry the import of the input parameter."
            )
            return "ERROR", error
    # Step 6: Create the input parameter
    try:
        logging.debug(f"Creating input parameter: '{input_parameter_name}'")
        response = requests.post(
            f'{morpheus_url}/api/library/option-types',
            headers=headers,
            json=input_parameter_data,
            verify=ssl_verify
        )
        response.raise_for_status()
        logging.debug(f"Exiting import_input_parameter function with Input parameter '{input_parameter_name}' created successfully.")
        message = (
            f"CREATED: Input parameter '{input_parameter_name}' successfully created in target instance with ID {response.json()['optionType']['id']}.{option_list_info}"
        )
        return "CREATED", message
    except requests.exceptions.HTTPError as err:
        error = (
            f"Error: Failed to import input parameter '{input_parameter_name}'.\n"
            f"HTTP Error: {err}\n"
            f"Response: {response.content.decode('utf-8')}"
        )
        return "ERROR", error

# =============================================================================
# 13. WORKFLOW COMPONENT IMPORT
# =============================================================================
def import_task_from_centralized(task_name, access_token):
    """
    Imports task from centralized tasks directory with subworkflow resolution.

    Note: Conditional tasks are created without subworkflow IDs initially.
    They will be updated later via update_condtional_task_subworkflows function.

    Args:
        task_name (str): The name of the task to import
        access_token (str): The access token for authentication API requests

    Returns:
        tuple: (status, message)
    """
    # Load task from centralized directory
    tasks_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'tasks')
    task_file_path = find_component_file_by_name(tasks_dir, task_name)

    if not task_file_path:
        return "ERROR", f"Task file not found for '{task_name}' in centralized directory: {tasks_dir}"

    try:
        with open(task_file_path, 'r') as f:
            task_data = json.load(f)

        # Resolve subworkflow IDs for conditional tasks (ONLY if subworkflow_id_map has data)
        if task_data["task"].get("taskType", {}).get("code") == "conditionalWorkflow":
            logging.debug(f"Conditional task '{task_name}' will be imported without sub-workflow IDs (will be updated later)")

        # Use existing task import logic
        headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}

        # Check if task already exists
        existing_tasks = fetch_paginated_data(
            f'{morpheus_url}/api/tasks',
            headers,
            resource_key='tasks',
        )

        task_code = task_data["task"].get("code")
        if not task_code:
            return "ERROR", f"Task '{task_name}' has an empty or missing 'code'"

        existing_task = next((t for t in existing_tasks if t['name'].strip() == task_name.strip()), None)

        if existing_task:
            if existing_task['code'] == task_code:
                return "REUSE", f"REUSE: Task '{task_name}' already exists in target instance with ID {existing_task['id']}. Reusing existing component."
            else:
                return "ERROR", (
                    f"TASK NAME CONFLICT: Task '{task_name}' already exists with a different code.\n"
                    f"Expected code: '{task_code}'\n"
                    f"Existing code: '{existing_task['code']}'\n"
                    f"RESOLUTION: Rename the existing task in Morpheus to resolve this conflict.\n"
                    f"Example: Rename existing task from '{task_name}' to '{task_name} Legacy' in Morpheus.\n"
                    f"IMPORTANT: Do Not modify task names in import JSON as workflows reference tasks by name."
                )

        # Create the task
        logging.debug(f"Creating task: '{task_name}'")
        response = requests.post(f'{morpheus_url}/api/tasks', headers=headers, json=task_data, verify=ssl_verify)
        response.raise_for_status()
        new_task_id = response.json()['task']['id']
        logging.debug(f"Task '{task_name}' created successfully with ID {new_task_id}.")
        # Successfully created task, return immediately
        return "CREATED", f"CREATED: Task '{task_name}' successfully created in target instance with ID {new_task_id}."
    except Exception as e:
        return "ERROR", f"Failed to import task '{task_name}': {e}"

def import_subworkflow_from_centralized(subworkflow_name, access_token):
    """
    Imports a sub-workflow from centralized workflow directory.

    Args:
        subworkflow_name (str): The name of the sub-workflow to import.
        access_token (str): The access token for authentication API requests.

    Returns:
        tuple: (status, message, subworkflow_id)
    """
    # First, load subworkflow from centralized directory to get description
    subworkflows_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'subworkflows')
    subworkflow_file_path = find_component_file_by_name(subworkflows_dir, subworkflow_name)

    if not subworkflow_file_path:
        return "ERROR", f"Subworkflow file not found for '{subworkflow_name}' in centralized subworkflows directory: {subworkflows_dir}", None

    try:
        with open(subworkflow_file_path, 'r') as f:
            subworkflow_data = json.load(f)

        # Extract description for precise matching
        subworkflow_description = subworkflow_data.get('taskSet', {}).get('description', '')

        # Check if sub-workflow already exists using unified function with description
        if subworkflow_description:
            existing_subworkflow = check_existing_workflow(subworkflow_name, access_token, subworkflow_description.strip())
        else:
            # Fallback to name-only matching if no description (Sonja)
            existing_subworkflow = check_existing_workflow(subworkflow_name, access_token)

        if existing_subworkflow:
            subworkflow_id = existing_subworkflow['id']
            return "REUSE", f"REUSE: Sub-workflow '{subworkflow_name}' already exists in target instance with ID {subworkflow_id}. Reusing existing component.", subworkflow_id

        # Import the subworkflow using existing resolve_tasks logic
        headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
        existing_tasks = fetch_paginated_data(
            f'{morpheus_url}/api/tasks',
            headers,
            resource_key='tasks',
        )

        result = resolve_tasks(subworkflow_data, existing_tasks)
        if result['status'] == 'ERROR':
            return "ERROR", result["message"], None

        # create the subworkflow
        response = requests.post(f'{morpheus_url}/api/task-sets', headers=headers, json=subworkflow_data, verify=ssl_verify)
        response.raise_for_status()
        subworkflow_id = response.json()['taskSet']['id']
        return "CREATED", f"CREATED: Sub-workflow '{subworkflow_name}' successfully created in target instance with ID {subworkflow_id}.", subworkflow_id
    except Exception as e:
        return "ERROR", f"Error importing sub-workflow '{subworkflow_name}': {e}", None

def _is_conditional_task(task_name):
    """
    Helper function to check if a task is conditional
    """
    tasks_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'tasks')
    task_file_path = find_component_file_by_name(tasks_dir, task_name)

    if task_file_path:
        try:
            with open(task_file_path, 'r') as f:
                task_data = json.load(f)
            return task_data.get('task', {}).get('taskType', {}).get('code') == "conditionalWorkflow"
        except:
            pass
    return False

# =============================================================================
# 14. CORE COMPONENT IMPORT
# =============================================================================
def import_workflow(workflow_name, access_token, workflow_filename=None):
    """
    Imports a workflow into the target instance
    Includes fallback task dependency resolution for layout import scenarios.

    Args:
        workflow_name (str): The name of the workflow to import.
        access_token (str): The access token for authentication API requests.
        workflow_filename (str, optional): Specific filename of centralized structure.

    Returns:
        tuple: ("SUCCESS", message) or ("ERROR", message)
    """
    logging.debug(f"Entering import_workflow method for workflow: {workflow_name}")
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    # Step 1: Centralized structure: Determine workflow file path
    if workflow_filename:
        # Use specific filename when provided (from main function)
        workflows_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'workflows')
        import_path = os.path.join(workflows_dir, workflow_filename)
    else:
        # Discovery by name (fallback for direct function calls)
        workflows_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'workflows')
        import_path = find_component_file_by_name(workflows_dir, workflow_name)

    if not import_path or not os.path.exists(import_path):
        return "ERROR", f"Import file not found for workflow '{workflow_name}' in centralized structure.Expected path: {import_path}"

    # Step 2: Load and validate workflow data
    with open(import_path, 'r') as json_file:
        workflow_data = json.load(json_file)
        logging.debug(f"Loaded workflow data: {json.dumps(workflow_data, indent=4)}")

    # Validate workflow data
    if "taskSet" not in workflow_data or not isinstance(workflow_data["taskSet"], dict):
        return "ERROR", f"Invalid workflow JSON for '{workflow_name}'. Missing or invalid 'taskSet'. Expected a dictionary under the 'taskSet' key."

    # Step 3: Check if workflow already exists (early exit optimization)
    workflow_description = workflow_data["taskSet"].get("description", '')
    existing_workflow = check_existing_workflow(workflow_name, access_token, workflow_description.strip() if workflow_description else None)
    if existing_workflow:
        workflow_id = existing_workflow['id']
        return "REUSE", f"REUSE: Workflow '{workflow_name}' already exists in target instance with ID {workflow_id}. Reusing existing component."

    # Step 4: Detect workflow type and resolve optionTypes for operation workflows
    workflow_type = workflow_data["taskSet"].get("type", "operation").lower()
    logging.debug(f"Detected workflow type for '{workflow_name}': {workflow_type}")

    # Resolve input parameters (optionTypes) for operation workflow only
    if workflow_type == 'operation':
        logging.debug("Resolving input parameters (optionTypes)....")
        existing_option_types = fetch_paginated_data(
            f'{morpheus_url}/api/library/option-types',
            headers,
            resource_key='optionTypes',
        )
        logging.info(f"Total existing option types fetched: {len(existing_option_types)}")

        result = resolve_option_types(workflow_data, existing_option_types)
        if result["status"] == "ERROR":
            return "ERROR", result["message"]

    # Step 5: Fallback task dependency resolution
    # This handles missing tasks when import_workflow is called from layout import
    # Main workflow import (option 1) pre-imports tasks, so this acts as fallback only
    logging.debug("Resolving dependencies with fallback import capability...")

    existing_tasks = fetch_paginated_data(
        f'{morpheus_url}/api/tasks',
        headers,
        resource_key='tasks',
    )

    # Try to resolve tasks first
    result = resolve_tasks(workflow_data, existing_tasks)
    if result["status"] == "ERROR":
        return ("ERROR", result["message"])

    # Step 6: Create the workflow
    try:
        response = requests.post(
            f'{morpheus_url}/api/task-sets',
            headers=headers,
            json=workflow_data,
            verify=ssl_verify
        )
        response.raise_for_status()
        workflow_id = response.json()['taskSet']['id']
        logging.debug(f"Workflow '{workflow_name}' imported successfully with ID {workflow_id}.")
        return "CREATED", f"CREATED: Workflow '{workflow_name}' successfully created in target instance with ID {workflow_id}."
    except requests.exceptions.HTTPError as err:
        return "ERROR", f"Failed to import workflow '{workflow_name}': {err}\nResponse content: {response.content.decode('utf-8')}"

def resolve_instance_type(instance_type_name, instance_type_code, access_token):
    """
    Resolves instance type by CODE only. Creates if not found.
    CODE-centric approach: CODE is the unique identifier, names can vary.

    Args:
        instance_type_name (str): The name of the instance type to create.
        instance_type_code (str): Code of the instance type (unique identifier)
        access_token (str): The access token for authentication API requests.

    Returns:
        tuple: ("REUSE", message, instance_type_id), ("CREATED", message, instance_type_id), or ("ERROR", message, None)
    """
    logging.debug(f"Resolving instance type: name='{instance_type_name}', code='{instance_type_code}'")

    headers =  {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}

    # Step 1: Load configuration to get creation payload
    instance_types_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'instance_types')
    instance_type_file_path = find_component_file_by_name(instance_types_dir, instance_type_name)

    if not instance_type_file_path:
        return "ERROR", f"Instance type configuration file not found for '{instance_type_name}' in: {instance_types_dir}", None

    # Step 2: Load and validate instance type configuration
    try:
        with open(instance_type_file_path, 'r') as f:
            instance_type_data = json.load(f)

        # Validate instance type structure
        if "instanceType" not in instance_type_data:
            return "ERROR", f"Invalid instance type configuration in '{instance_type_file_path}'. Missing 'instanceType' key. Please ensure the JSON structure is correct.", None

        # Extract name and code from configuration
        config = instance_type_data["instanceType"]
        config_name = config.get("name")
        config_code = config.get("code")

        if not config_name or not config_code:
            return "ERROR", f"Instance type configuration in '{instance_type_file_path}' is missing 'name' or 'code' fields. Please ensure both fields are provided.", None

        # Validate input parameters match configuration
        if config_name != instance_type_name or config_code != instance_type_code:
            return "ERROR", f"Instance type name or code mismatch in '{instance_type_file_path}'. Expected name: '{instance_type_name}', code='{instance_type_code}'. Config file has: name='{config_name}', code='{config_code}'. Please ensure the file name matches the 'name' field and the 'code' field in the JSON.", None

        logging.debug(f"Loaded instance type configuration: name='{config_name}', code='{config_code}' from '{instance_type_file_path}'")
    except json.JSONDecodeError as e:
        return "ERROR", f"Invalid JSON format in instance type configuration file '{instance_type_file_path}': {e}. Please correct the JSON and try again.", None
    except Exception as e:
        return "ERROR", f"Failed to load instance type configuration from '{instance_type_file_path}': {e}. Please check the file and try again.", None

    # Step 3: Check if instance type already exists (with code validation)
    try:
        logging.debug(f"Fetching SAP instance types using server-side filtering for better performance...")
        existing_instance_types = fetch_paginated_data(
            f'{morpheus_url}/api/instance-types',
            headers,
            resource_key='instanceTypes',
            params={'phrase': 'SAP'},  # Server-side filtering for SAP instance types
            max_records=100,  # Increased since we're only getting SAP ones
            sort_field='name',
            sort_direction='asc'
        )
        logging.debug(f"Server-side filtered {len(existing_instance_types)} SAP instance types from API")

        # look for exact match on both name and code
        existing_instance_type_by_code = next((it for it in existing_instance_types if it.get('code') == instance_type_code), None)

        if existing_instance_type_by_code:
            # Code exists -> REUSE (regardless of name)
            instance_type_id = existing_instance_type_by_code['id']
            existing_instance_name = existing_instance_type_by_code.get('name', 'Unknown')

            # Log name difference if any (information only)
            if existing_instance_name != instance_type_name:
                logging.info(f"Instance type CODE '{instance_type_code}' exists with different name. "
                           f"Existing: '{existing_instance_name}', Expected: '{instance_type_name}'. Using existing.")

            logging.debug(f"Found existing instance type with code '{instance_type_code}' with name '{existing_instance_name}' found with ID {instance_type_id}")
            return "REUSE", f"REUSE: Instance type '{instance_type_name}' with code '{instance_type_code}' already exists with ID {instance_type_id}", instance_type_id

        logging.debug(f"Instance type with code '{instance_type_code}' not found. Creating new one.")

    except Exception as e:
        return "ERROR", f"Error checking existing instance types: {e}", None

    # Step 4: Create the instance type (no conflicts found)
    try:
        logging.debug(f"Creating instance type: name='{instance_type_name}' with code '{instance_type_code}' from centralized configuration...")

        response = requests.post(
            f"{morpheus_url}/api/library/instance-types",
            headers=headers,
            json=instance_type_data,
            verify=ssl_verify
        )
        response.raise_for_status()

        created_instance_type = response.json().get("instanceType")
        if not created_instance_type:
            return "ERROR", f"Failed to create instance type '{instance_type_name}': Invalid response from API - missing 'instanceType' in response", None

        instance_type_id = created_instance_type['id']
        created_instance_type_name = created_instance_type.get("name")
        created_instance_type_code = created_instance_type.get("code")

        # Verify the created instance type has correct name and code
        if created_instance_type_code != instance_type_code:
            return "ERROR", f"Created instance type validation failed for '{instance_type_name}'. Expected name='{instance_type_name}', code='{instance_type_code}'. Got name='{created_instance_type.get('name')}', code='{created_instance_type.get('code')}'", None

        logging.debug(f"Instance type '{instance_type_name}' created successfully with ID {instance_type_id}, code='{instance_type_code}'")
        return "CREATED", f"CREATED: Instance type '{instance_type_name}' with code '{instance_type_code}' created successfully with ID {instance_type_id}", instance_type_id

    except requests.exceptions.HTTPError as err:
        error_content = getattr(err.response, 'text', 'No response content')
        return "ERROR", f"Failed to create instance type '{instance_type_name}': {err}\nResponse: {error_content}", None
    except Exception as e:
        return "ERROR", f"Failed to create instance type '{instance_type_name}': {e}", None

def import_layout(layout_name, access_token, layout_filename=None, workflow_id=None, instance_type_id=None):
    """
    Import layout from centralized morpheus_configuration structure.
    This is a pure creation function - assumes all dependencies are already imported.

    Args:
        layout_name (str): The name of the layout to import.
        access_token (str): The access token for authentication
        layout_filename (str, optional): Specific filename from list_layouts()
        workflow_id (int, optional): Pre-resolved workflow ID
        instance_type_id (int, optional): Pre-resolved instance type ID

    Returns:
        tuple: ("REUSE", message) or ("CREATED", message) or ("ERROR", message)
    """
    logging.info(f"Creating layout: '{layout_name}' (dependencies assumed resolved)")
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    # Step 1: Determine layout file path
    if layout_filename:
        # Use specific filename when provided (from main function)
        layout_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'layouts')
        layout_file_path = os.path.join(layout_dir, layout_filename)
    else:
        # Discovery by name (fallback for direct function calls)
        layouts_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'layouts')
        layout_file_path = find_component_file_by_name(layouts_dir, layout_name)

    logging.debug(f"layout_file_path: {layout_file_path}")

    # Validation: Check if layout file already exists
    if not layout_file_path or not os.path.exists(layout_file_path):
        return "ERROR", f"Import layout file not found for '{layout_name}' in centralized structure. Please ensure the layout exists in the '{layout_file_path}' directory."

    # Step 2: Load and validate layout data
    try:
        with open(layout_file_path, 'r') as f:
            layout_data = json.load(f)
        logging.debug(f"Loaded layout data{json.dumps(layout_data, indent=4)}")
    except Exception as e:
        logging.error(f"Failed to load layout configuration from '{layout_file_path}': {e}")
        return ("ERROR", f"Failed to load layout configuration from '{layout_file_path}':{e}. Please check the file and try again.")

    # validate layout structure
    if "instanceTypeLayout" not in layout_data:
        return ("ERROR", f"Invalid layout configuration. Missing 'instanceTypeLayout' in '{layout_filename}'. Please ensure the layout JSON structure is correct.")

    # Extract layout name and description for existence checking
    layout_config = layout_data["instanceTypeLayout"]
    layout_description = layout_config.get("description", "")

    # Step 3: Check if layout already exists (early return)
    existing_layout = check_existing_layout(layout_name, layout_description, access_token)
    if existing_layout:
        return ("REUSE", f"Layout '{layout_name}' already exists with ID {existing_layout['id']}. Reusing existing component.")

    # Step 4: Resolve Instance Type ID
    if instance_type_id is None:
        instance_type_info = layout_config.get("instanceType", {})
        instance_type_name = instance_type_info.get("name")
        instance_type_code = instance_type_info.get("code")

        if not instance_type_name or not instance_type_code:
            return "ERROR", f"Instance type information is missing in the layout configuration for '{layout_name}'. Ensure 'name' and 'code' are provided in 'instanceTypeLayout'."

        # Resolve instance type
        status, message, instance_type_id = resolve_instance_type(instance_type_name, instance_type_code, access_token)

        if status == "ERROR":
            return "ERROR", message

        # Log the result
        logging.debug(f"Instance type resolution: {status} - {message}")
        logging.info(f"✅ {status}: Instance type '{instance_type_name}' - ID {instance_type_id}")

    # Step 5: Resolve workflow ID (if not provided)
    if workflow_id is None:
        workflow_name = None
        workflow_description = None

        if "taskSets" in layout_config and layout_config["taskSets"]:
            taskset = layout_config["taskSets"][0]
            workflow_name = taskset.get("name")
            workflow_description = taskset.get("description")
        elif "taskSet" in layout_config:
            workflow_name = layout_config["taskSet"].get("name")
            workflow_description = layout_config["taskSet"].get("description")

        if not workflow_name:
            logging.debug(f"Layout '{layout_name}' has no workflow - supporting bare-metal deployment")
            # For bare-metal layouts, we don't need a workflow
            workflow_id = None  # Set to None explicitly
        else:
            # Resolve workflow
            existing_workflow = check_existing_workflow(workflow_name, access_token, workflow_description)
            if existing_workflow:
                workflow_id = existing_workflow['id']
            else:
                # Check if workflow exists with same name but different description
                name_only_check = check_existing_workflow(workflow_name, access_token, None)
                if name_only_check:
                    return ("ERROR",
                    f"WORKFLOW CONFLICT DETECTED:\n"
                    f"  Layout requires workflow: '{workflow_name}'\n"
                    f"  Expected description: '{workflow_description}'\n"
                    f"  Found conflicting workflow in target instance with different description.\n\n"
                    f"RESOLUTION OPTIONS:\n"
                    f"  1. Change the workflow name in the target instance to allow new workflow import\n"
                    f"  2. Update the workflow description in target instance to: '{workflow_description}'\n\n"
                    f"Please check the target Morpheus instance and resolve this conflict before retrying.")
                else:
                    return ("ERROR", f"Required workflow '{workflow_name}' not found in target instance (should be imported by dependencies)")

    # Step 6: Resolve input parameter IDs
    if "optionTypes" in layout_config and layout_config["optionTypes"]:
        existing_option_types = fetch_paginated_data(
            f'{morpheus_url}/api/library/option-types',
            headers,
            resource_key='optionTypes',
        )

        resolved_option_types = []
        for option_type in layout_config["optionTypes"]:
            option_name = sanitize_name(option_type.get("name", ""))
            option_fieldname = clean_field_name(option_type.get("fieldName", ""))
            option_description = clean_description(option_type.get("description", ""))

            # Find matching input parameter by name, fieldName, and description
            matching_option_type = None
            for existing_input in existing_option_types:
                if (sanitize_name(existing_input.get("name")) == option_name and
                    clean_field_name(existing_input.get("fieldName")) == option_fieldname and
                    clean_description(existing_input.get("description")) == option_description):
                    matching_option_type = existing_input
                    break

            if matching_option_type:
                resolved_option_types.append(matching_option_type['id'])
                logging.debug(f"Resolved input parameter '{option_name}' to ID {matching_option_type['id']}")
            else:
                return "ERROR", f"Required input parameter '{option_name}' with fieldName '{option_fieldname}' not found (should be imported by dependencies)"

        # Update layout with resolved option type IDs
        layout_config['optionTypes'] = resolved_option_types
        logging.debug(f"Updated layout optionTypes with resolved IDs: {resolved_option_types}")

    # Step 7: Prepare layout payload
    # Link workflow using taskSetId (only if workflow exists)
    if workflow_id is not None:
        layout_config['taskSetId'] = workflow_id
        logging.debug(f"Set taskSetId to workflow ID: {workflow_id}")
    else:
        # For bare-metal layouts, remove any workflow references
        if 'taskSetId' in layout_config:
            del layout_config['taskSetId']
        logging.debug("No workflow set for bare-metal layout")

    # Remove taskSets if present (use taskSetId instead)
    if "taskSets" in layout_config:
        del layout_config["taskSets"]
        logging.debug("Removed taskSets from layout config")

    # Remove instanceType from payload (provided in URL)
    if 'instanceType' in layout_config:
        del layout_config['instanceType']
        logging.debug("Removed instanceType from layout payload")

    # Convert memory requirement from bytes to MB for API compatibility
    if "memoryRequirement" in layout_config and layout_config["memoryRequirement"] is not None:
        original_memory_bytes = layout_config["memoryRequirement"]
        layout_config["memoryRequirement"] = convert_memory_memory_bytes_to_mb(original_memory_bytes)
        logging.info(f"Layout '{layout_name}': Converted memory requirement from {original_memory_bytes} bytes to {layout_config['memoryRequirement']} MB for API")

    # Step 8: Create the layout
    try:
        logging.info(f"Creating layout '{layout_name}' in target instance...")

        # Use instance-type-specific endpoint (your proven approach)
        response = requests.post(
            f'{morpheus_url}/api/library/instance-types/{instance_type_id}/layouts',
            headers=headers,
            json=layout_data,
            verify=ssl_verify
        )
        response.raise_for_status()

        created_layout = response.json().get("instanceTypeLayout")
        if not created_layout:
            return "ERROR", f"Failed to create layout - unexpected API response structure"

        layout_id = created_layout['id']
        logging.info(f"Layout '{layout_name}' created successfully with ID {layout_id}")

        return "CREATED", f"CREATED: Layout '{layout_name}' successfully created in target instance with ID {layout_id}."

    except requests.exceptions.HTTPError as err:
        error_content = getattr(err.response, 'text', 'No response content')
        return "ERROR", f"Failed to create layout '{layout_name}': {err}\nResponse: {error_content}"
    except Exception as e:
        return "ERROR", f"Unexpected error creating layout '{layout_name}': {e}"

# =============================================================================
# 15. RESOLUTION & LINKING ENGINE
# =============================================================================
def resolve_option_types(workflow_data, existing_option_types):
    """
    Resolves input parameters (optionTypes) in the workflow by mapping name, fieldName, and description to IDs.

    Args:
        workflow_data (dict): The workflow data containing optionTypes to resolve.
        existing_option_types (list): A List of existing optionTypes in the target instance.

    Returns:
        Str: Error message if an issue occurs, or "SUCCESS" if all optionTypes are resolved successfully.
    """
    logging.debug("Entered resolve_option_types method and Resolving input parameters IDs (optionTypes)....")

    # Handle case where no optionTypes are present in the workflow JSON
    if not workflow_data["taskSet"].get("optionTypes", []):
        return {
            "status": "ERROR",
            "message": "No optionTypes found the workflow JSON. Input parameters are required for the workflow to function. Please ensure the workflow JSON includes valid optionTypes."
        }

    resolved_option_types = []
    for option_type in workflow_data["taskSet"].get("optionTypes", []):
        option_name = sanitize_name(option_type["name"])
        option_fieldname = clean_field_name(option_type["fieldName"])
        option_description = clean_description(option_type.get("description", ""))

        # Pre-check for missing or empty description
        if not option_description or not option_fieldname:
            return {
                "status": "ERROR",
                "message": f"Missing or empty fields for input name '{option_name}'. Ensure 'description' and 'fieldName' are provided."
            }
        logging.debug(f"Resolving optionType: name='{option_name}', fieldName='{option_fieldname}', description='{option_description}'")

        # Find all matching optionTypes by name
        matching_by_name = [
            ot for ot in existing_option_types if sanitize_name(ot["name"]) == option_name
        ]

        # Check for fieldName conflicts
        conflicting_fieldNames = [
            ot for ot in matching_by_name if clean_field_name(ot["fieldName"]) != option_fieldname
        ]
        if conflicting_fieldNames:
            return {
                "status": "ERROR",
                "message": f"Conflict detected for input parameter '{option_name}'. FieldName mismatch. Ensure fieldName matches, or update the import file or Morpheus accordingly."
            }

        # Check for description match among those with the same name and fieldName
        matching_by_name_and_field = [
            ot for ot in matching_by_name if clean_field_name(ot["fieldName"]) == option_fieldname
        ]

        # Handle case where no matching entries are found
        if not matching_by_name_and_field:
            return {
                "status": "ERROR",
                "message": f"No matching entries found for input parameter '{option_name}' with fieldName '{option_fieldname}'. Ensure the input parameter exists in Morpheus."
            }
        """
        # Debuging prupose:
        simplified_entries = [
            {
                "id": ot["id"],
                "name": ot["name"],
                "fieldName": ot["fieldName"],
                "description": ot.get("description", "")
            }
            for ot in matching_by_name_and_field
        ]
        print(f"is it addressing multiple entries:", json.dumps(simplified_entries, indent=4)) # debug purpose, delete later
        """
        # Find the first matching entry by description
        matching_entry = next(
            (ot for ot in matching_by_name_and_field if clean_description(ot.get("description", "")) == option_description),
            None
        )
        if matching_entry:
            resolved_option_types.append(matching_entry["id"])
            logging.debug(f"Reusing existing optionType: name='{option_name}', fieldName='{option_fieldname}', id={matching_entry['id']}")
        else:
            # No match found, raise an error
            existing_description = [clean_description(ot.get("description", "")) for ot in matching_by_name_and_field]
            return {
                "status": "ERROR",
                "message": (
                    f"Description mismatch for input parameter '{option_name}'.\n"
                    f"Expected description: '{option_description}'\n"
                    f"Existing descriptions: {existing_description}\n"
                    "Ensure descriptions match, or update the import file or Morpheus accordingly."
                )
            }
    # Update the workflow data with resolved optionType IDs
    logging.debug(f"Resolved optionTypes: {json.dumps(resolved_option_types, indent=4)}")
    workflow_data["taskSet"]["optionTypes"] = resolved_option_types
    return {"status": "SUCCESS"}

def resolve_tasks(workflow_data, existing_tasks):
    """
    Resolve tasks in the workflow by mapping task codes to IDs.
    All tasks should exist since they were imported in the dependency phase.

    Args:
        workflow_data (dict): The workflow data containing tasks to resolve.
        existing_tasks (list): A list of existing tasks in the target instance.

    Returns:
        dict: {"status": "SUCCESS"} or {"status": "ERROR", "message": "error details"}
    """
    logging.debug("Entered resolve_tasks method and Resolving task IDs...")

    # Handle case where no tasks are present in the workflow JSON
    task_set_tasks = workflow_data["taskSet"].get("taskSetTasks", [])
    if not task_set_tasks:
        return {
            "status": "ERROR",
            "message": "No taskSetTasks found in the workflow JSON. Tasks are required for the workflow to function. Please ensure the workflow JSON includes valid taskSetTasks."
        }

    # Create comprehensive mappings for intelligent resolution
    task_name_to_task = {}

    for task in existing_tasks:
        task_name = task['name'].strip()

        # Since task names must be unique, each name maps to exactly one task
        task_name_to_task[task_name] = task

    logging.debug(f"Task name mapping: {len(task_name_to_task)} unique names found.")

    # Update taskSetTasks with correct IDs and build the tasks array
    tasks_array = []
    for task_set_task in task_set_tasks:
        task_name = task_set_task["task"].get("name")
        task_code = task_set_task["task"].get("code")
        task_phase = task_set_task.get("taskPhase")

        if not task_code:
            return {
                "status": "ERROR",
                "message": f"For task '{task_name}' in taskSetTasks is missing the 'code' field. Ensure all tasks have a valid code."
            }
        if not task_phase:
            return {
                "status": "ERROR",
                "message": f"For task '{task_name}' in taskSetTasks is missing the 'taskPhase' field. Ensure all tasks have a valid taskPhase."
            }

        # Check if task name already exists
        if task_name in task_name_to_task:
            existing_task = task_name_to_task[task_name]

            if existing_task['code'] == task_code:
                # Perfect match: same name and same code - REUSE
                task_id = existing_task['id']
                task_set_task["task"]["id"] = task_id
                tasks_array.append({
                    "taskId": task_id,
                    "taskPhase": task_phase
                })
                logging.debug(f"✅ Exact match: name='{task_name}', code='{task_code}', id={task_id}")
                continue
            else:
                # CONFLICT: Same name but different code
                return {
                    "status": "ERROR",
                    "message": (
                        f"TASK NAME CONFLICT: Task '{task_name}' already exists with a different code.\n"
                        f"Expected code: '{task_code}'\n"
                        f"Existing code: '{existing_task['code']}'\n"
                        f"RESOLUTION: Rename the existing task in Morpheus to resolve this conflict.\n"
                        f"Example: Rename existing task from '{task_name}' to '{task_name} Legacy' in Morpheus.\n"
                        f"IMPORTANT: Do Not modify task names in import JSON as Workflows reference tasks by name."
                    )
                }
        # ERROR: Task name doesn't exist (should have been imported in dependency phase)
        return {
            "status": "ERROR",
            "message": (
                f"IMPORT ERROR: Task '{task_name}' with code '{task_code}' not found in target instance.\n"
                f"This task should have been imported during the dependency phase.\n"
                f"This indicates a problem with the import process or the task import failed.\n"
                f"Please check the task import logs and retry the workflow import."
            )
        }

    if not tasks_array:
        return {
            "status": "ERROR",
            "message": "No tasks could be resolved for the workflow. The tasks array is empty. Ensure task codes match existing tasks."
        }

    workflow_data["taskSet"]["tasks"] = tasks_array
    logging.debug(f"Resolved tasks: {json.dumps(workflow_data['taskSet']['tasks'], indent=4)}")
    return {"status": "SUCCESS"}

def update_conditional_workflow_with_subworkflow_ids(task_name, access_token,subworkflow_id_map):
    """
    Update an existing conditional task with resolved subworkflow IDs.

    Args:
        task_name (str): Name of the conditional task to update.
        access_token (str): The access token for API authentication.
        subworkflow_id_map (dict): A mapping of subworkflow names to their resolved IDs.

    Returns:
        tuple: (status, message)
    """
    headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}

    try:
        # Get the existing task
        existing_tasks = fetch_paginated_data(
            f'{morpheus_url}/api/tasks',
            headers,
            resource_key='tasks',
        )

        existing_task = next((t for t in existing_tasks if t['name'].strip() == task_name.strip()), None)
        if not existing_task:
            return "ERROR", f"Task '{task_name}' not found for updating"

        # Load the task definition to get subworkflow names
        tasks_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'tasks')
        task_file_path = find_component_file_by_name(tasks_dir, task_name)

        if not task_file_path:
            return "ERROR", f"Task file not found for '{task_name}'"

        with open(task_file_path, 'r') as f:
            task_data = json.load(f)

        task_options = task_data["task"].get("taskOptions", {})
        update_payload = existing_task.copy()
        updated = False
        update_info = []

        # Update ifOperationalWorkflowId
        if_workflow_name = task_options.get("ifOperationalWorkflowName")
        if if_workflow_name and if_workflow_name in subworkflow_id_map:
            if "taskOptions" not in update_payload:
                update_payload["taskOptions"] = {}
            update_payload["taskOptions"]["ifOperationalWorkflowId"] = subworkflow_id_map[if_workflow_name]
            update_info.append(f"IF: '{if_workflow_name}' → ID {subworkflow_id_map[if_workflow_name]}")
            updated = True

        # Update elseOperationalWorkflowId
        else_workflow_name = task_options.get("elseOperationalWorkflowName")
        if else_workflow_name and else_workflow_name in subworkflow_id_map:
            if "taskOptions" not in update_payload:
                update_payload["taskOptions"] = {}
            update_payload["taskOptions"]["elseOperationalWorkflowId"] = subworkflow_id_map[else_workflow_name]
            update_info.append(f"ELSE: '{else_workflow_name}' → ID {subworkflow_id_map[else_workflow_name]}")
            updated = True

        if not updated:
            return "SKIPPED", f"Task '{task_name}' doesn't need subworkflow ID updates"

        # Update via API
        response = requests.put(f'{morpheus_url}/api/tasks/{existing_task["id"]}',
                               headers=headers,
                               json={"task": update_payload},
                               verify=ssl_verify)
        response.raise_for_status()

        update_details = ", ".join(update_info)
        return "UPDATED", f"UPDATED: Task '{task_name}' linked to sub-workflows ({update_details})"

    except Exception as e:
        return "ERROR", f"Failed to update task '{task_name}': {e}"

# =============================================================================
# 16. DEPENDENCY ORCHESTRATION
# =============================================================================
def import_workflow_dependencies(workflow_data, workflow_name, workflow_type, access_token):
    """
    Import all dependencies for a workflow in the correct order.

    Args:
        workflow_data (dict): The workflow JSON data
        workflow_name (str): The name of the workflow
        workflow_type (str): The type of the workflow ('operation' or 'provision')
        access_token (str): Authentication token

    Returns:
        tuple: (success: bool, subworkflow_id_map: dict)
    """
    try:
        # Phase 1: Analyze dependencies
        print("🔍 Analyzing dependencies...")
        logging.info("Starting dependency analysis")

        # Analze dependencies
        required_tasks, required_subworkflows = analyze_workflow_task_dependencies(workflow_data)
        required_option_lists = set()
        required_inputs = set()

        # For operation workflows - analyze inputs and option lists
        if workflow_type == 'operation':
            logging.debug(f"Handling operation workflow: {workflow_name}")

            # Import option lists associated with the workflow
            task_set = workflow_data.get("taskSet", {})

            # Extract input parameters and their option lists from workflow
            for option_type in task_set.get("optionTypes", []):
                input_name = option_type.get("name")
                if input_name:
                    required_inputs.add(input_name)

                # Check for option list dependencies
                option_list_ref = option_type.get("optionList")
                if option_list_ref and isinstance(option_list_ref, dict):
                    option_list_name = option_list_ref.get("name")
                    if option_list_name:
                        required_option_lists.add(option_list_name)

        elif workflow_type == 'provision':
            logging.debug(f"Handling provision workflow: {workflow_name}")
            # For provision workflows, dependencies come only from tasks and subworkflows
            # No input parameters or option lists are typically used

        # User: show dependency summary
        print(f"📊 Dependencies found:")
        print(f"   • Option Lists: {len(required_option_lists)}")
        print(f"   • Input Parameters: {len(required_inputs)}")
        print(f"   • Tasks: {len(required_tasks)}")
        print(f"   • Sub-workflows: {len(required_subworkflows)}")

        # Phase 2: Import Option Lists
        if required_option_lists:
            print(f"\n📦 [1/5] Importing {len(required_option_lists)} option list(s)...")
            logging.info(f"Starting import of {len(required_option_lists)} option lists")

            for option_list_name in sorted(required_option_lists):
                logging.debug(f"Processing option list: {option_list_name}")
                result, message = import_option_list(option_list_name, access_token)

                if result == "ERROR":
                    print(f"❌ ERROR: {message}")
                    return False
                elif result == "REUSE":
                    print(f"  ✅ {option_list_name} (found in target instance)")
                elif result == "CREATED":
                    print(f"  🆕 {option_list_name} (imported successfully)")
        else:
            print(f"\n📦 [1/5] Option lists: None required")

        # Phase 3: Input Parameters
        if required_inputs:
            print(f"\n🔧 [2/5] Importing {len(required_inputs)} input parameter(s)...")
            logging.info(f"Starting import of {len(required_inputs)} input parameters")

            for input_name in sorted(required_inputs):
                logging.debug(f"Processing input parameter: {input_name}")
                result, message = import_input_parameter(input_name, access_token)

                if result == "ERROR":
                    print(f"❌ ERROR: {message}")
                    return False
                elif result == "REUSE":
                    print(f"  ✅ {input_name} (found in target instance)")
                elif result == "CREATED":
                    print(f"  🆕 {input_name} (imported successfully)")
        else:
            print(f"\n🔧 [2/5] Input parameters: None required")

        # Phase 4: Import Tasks (Both operation and provision workflows)
        if required_tasks:
            print(f"\n⚙️  [3/5] Importing {len(required_tasks)} task(s)...")
            logging.info(f"Starting import of {len(required_tasks)} tasks")

            for task_name in sorted(required_tasks):
                logging.debug(f"Processing task: {task_name}")
                result, message = import_task_from_centralized(task_name, access_token)
                if result == "ERROR":
                    print(f"❌ ERROR: {message}")
                    return False, {}
                elif result == "REUSE":
                    print(f"  ✅ {task_name} (found in target instance)")
                elif result == "CREATED":
                    print(f"  🆕 {task_name} (imported successfully)")
        else:
            print(f"\n⚙️  [3/5] Tasks: None required")

        # Phase 5: Import Sub-workflows (Both operation and provision workflows)
        subworkflow_id_map = {}
        if required_subworkflows:
            print(f"\n📋 [4/5] Importing {len(required_subworkflows)} sub-workflow(s)...")
            logging.info(f"Starting import of {len(required_subworkflows)} sub-workflows")

            for i, subworkflow_name in enumerate(sorted(required_subworkflows), 1):
                logging.debug(f"Processing sub-workflow: {subworkflow_name}")
                result, message, subworkflow_id = import_subworkflow_from_centralized(subworkflow_name, access_token)

                if result == "ERROR":
                    #logging.error(f"Sub-workflow import failed: {message}")
                    print(f"❌ ERROR: {message}")
                    return False
                elif result == "REUSE":
                    subworkflow_id_map[subworkflow_name] = subworkflow_id
                    print(f"  ✅ {subworkflow_name} (found in target instance)")
                elif result == "CREATED":
                    subworkflow_id_map[subworkflow_name] = subworkflow_id
                    print(f"  🆕 {subworkflow_name} (imported successfully)")
        else:
            print(f"\n📋 [4/5] Sub-workflows: None required")

        # Phase 6: Update conditional tasks with subworkflow IDs (Both operation and provision workflows)
        if required_tasks and subworkflow_id_map:
            print(f"\n🔗 Updating conditional tasks with sub-workflow references...")
            logging.info("Updating conditional tasks with sub-workflow IDs")

            conditional_tasks = []
            for task_name in required_tasks:
                if _is_conditional_task(task_name):
                    conditional_tasks.append(task_name)

            if conditional_tasks:
                for task_name in conditional_tasks:
                    result, message = update_conditional_workflow_with_subworkflow_ids(task_name, access_token, subworkflow_id_map)

                    if result == "ERROR":
                        #logging.error(f"Conditional task update failed: {message}")
                        print(f"❌ ERROR: {message}")
                        return False
                    elif result == "UPDATED":
                        print(f"  ✅ Updated {task_name} with sub-workflow references")
        return True, subworkflow_id_map

    except Exception as e:
        error_msg = f"An error occurred during dependency import: {e}"
        #logging.error(error_msg)
        print(f"❌ ERROR: {error_msg}")
        return False, {}

def import_layout_dependencies(layout_data, layout_name, access_token):
    """
    Import all dependencies for a layout in the correct order.
    Follows same pattern as import_workflow_dependencies for consistency.

    Args:
        layout_data (dict): The layout JSON data
        layout_name (str): The name of the layout
        access_token (str): Authentication token

    Returns:
        tuple: (status: bool, workflow_id: int, instance_type_id: int)
    """
    try:
        logging.info(f"🔧 Starting dependency import for layout: '{layout_name}'")

        # Step 1: Resolve Instance Type (Critical Dependency)
        print(f"\n🎯 [1/4] Resolving instance type...")
        instance_type_info = layout_data.get("instanceTypeLayout", {}).get("instanceType", {})
        instance_type_name = instance_type_info.get("name")
        instance_type_code = instance_type_info.get("code")

        if not instance_type_name or not instance_type_code:
            error_msg = f"Missing instance type information in layout '{layout_name}'"
            #logging.error(error_msg)
            print(f"❌ ERROR: {error_msg}")
            return False, None, None

        status, message, instance_type_id = resolve_instance_type(instance_type_name, instance_type_code, access_token)
        if status == "ERROR":
            #logging.error(f"Instance type resolution failed: {message}")
            print(f"❌ ERROR: {message}")
            return False, None, None

        print(f"  ✅ {status}: {instance_type_name} (ID: {instance_type_id})")
        logging.debug(f"Instance type resolution: {status} - {message}")

        # Step 2: Import Option Lists (Foundation Dependencies)
        print(f"\n🎯 [2/4] Importing option lists...")
        layout_config = layout_data.get("instanceTypeLayout", {})
        option_list_dependencies = set()
        input_parameter_names = []

        # Extract option list dependencies from layout optionTypes
        if "optionTypes" in layout_config and layout_config["optionTypes"]:
            for option_type in layout_config["optionTypes"]:
                input_param_name = option_type.get("name")
                if input_param_name:
                    input_parameter_names.append(input_param_name)

        if input_parameter_names:
            logging.info(f"Found {len(input_parameter_names)} input parameters in layout")

            # Load each input parameter to find option list dependencies
            inputs_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'inputs')
            for input_name in input_parameter_names:
                input_file_path = find_component_file_by_name(inputs_dir, input_name)
                if input_file_path:
                    try:
                        with open(input_file_path, 'r') as f:
                            input_data = json.load(f)

                        if ("optionList" in input_data.get("optionType", {}) and
                            input_data["optionType"]["optionList"] is not None):
                            option_list_name = input_data["optionType"]["optionList"]["name"]
                            option_list_dependencies.add(option_list_name)
                    except Exception as e:
                        logging.warning(f"Could not analyze input parameter '{input_name}' for option lists: {e}")

            # Import option lists
            for option_list_name in sorted(option_list_dependencies):
                status, message = import_option_list(option_list_name, access_token)
                if status == "REUSE":
                    print(f"  ✅ {option_list_name} (reused)")
                elif status == "CREATED":
                    print(f"  🆕 {option_list_name} (imported)")
                elif status == "ERROR":
                    #logging.error(f"Option list import failed: {message}")
                    print(f"❌ ERROR: {message}")
                    return False, None, None
        else:
            print(f"  ℹ️  No option lists required")

        # Stp 3: Import Input Parametes
        print(f"\n🎯 [3/4] Importing input parameters...")
        if input_parameter_names:
            for input_name in input_parameter_names:
                status, message = import_input_parameter(input_name, access_token)
                if status == "REUSE":
                    print(f"  ✅ {input_name} (reused)")
                elif status == "CREATED":
                    print(f"  🆕 {input_name} (imported)")
                elif status == "ERROR":
                    #logging.error(f"Input parameter import failed: {message}")
                    print(f"❌ ERROR: {message}")
                    return False, None, None
        else:
            print(f"  ℹ️  No input parameters required")

        # Step 4: Import Workflow Dependencies
        print(f"\n🎯 [4/4] Importing workflow dependencies...")
        workflow_name = None
        workflow_description = None

        if "taskSets" in layout_config and layout_config["taskSets"]:
            workflow_name = layout_config["taskSets"][0].get("name")
            workflow_description = layout_config["taskSets"][0].get("description")
        elif "taskSet" in layout_config:
            workflow_name = layout_config["taskSet"].get("name")
            workflow_description = layout_config["taskSet"].get("description")

        if not workflow_name:
            print(f"  ℹ️  No workflow required (bare-metal layout)")
            logging.debug(f"Layout '{layout_name}' has no workflow dependency - supporting bare-metal deployment")
            return True, None, instance_type_id

        # Check if workflow exists
        existing_workflow = check_existing_workflow(workflow_name, access_token, workflow_description)
        if existing_workflow:
            workflow_id = existing_workflow['id']
            print(f"  ✅ {workflow_name} (reused, ID: {workflow_id})")
        else:
            # Check if workflow exists with name-only (for conflict detection)
            name_only_check = check_existing_workflow(workflow_name, access_token, None)
            if name_only_check:
                error_msg = (
                    f"WORKFLOW CONFLICT DETECTED:\n"
                    f"  Layout requires workflow: '{workflow_name}'\n"
                    f"  Expected description: '{workflow_description}'\n"
                    f"  Found conflicting workflow in target instance with different description.\n\n"
                    f"RESOLUTION OPTIONS:\n"
                    f"  1. Change the workflow name in the target instance to allow new workflow import\n"
                    f"  2. Update the workflow description in target instance to: '{workflow_description}'\n\n"
                    f"Please check the target Morpheus instance and resolve this conflict before retrying."
                )
                print(f"❌ ERROR: {error_msg}")
                return False, None, None

            # Workflow doesn't exist at all - import it with ALL its dependencies using proper orchestration
            print(f"  🔄 Importing '{workflow_name}' with dependencies...")
            workflow_info = {'name': workflow_name, 'filename': None}
            success = import_workflow_complete(workflow_info, access_token)
            if not success:
                error_msg = f"Failed to import workflow '{workflow_name}' and its dependencies"
                #logging.error(error_msg)
                print(f"❌ ERROR: {error_msg}")
                return False, None, None

            # Get the newly created workflow ID
            existing_workflow = check_existing_workflow(workflow_name, access_token)
            if existing_workflow:
                workflow_id = existing_workflow['id']
                print(f"  🆕 {workflow_name} (imported, ID: {workflow_id})")
            else:
                error_msg = f"Failed to retrieve workflow ID after creation"
                #logging.error(error_msg)
                print(f"❌ ERROR: {error_msg}")
                return False, None, None

        logging.info(f"✅ All dependencies imported successfully for layout '{layout_name}'")
        return True, workflow_id, instance_type_id

    except Exception as e:
        error_msg = f"Failed to import dependencies for layout '{layout_name}': {e}"
        #logging.error(error_msg)
        print(f"❌ ERROR: {error_msg}")
        return False, None, None

# =============================================================================
# 17. COMPLETE IMPORT HANDLERS
# =============================================================================
def import_workflow_complete(workflow_info, access_token):
    """
    Complete import process for one workflow with all dependencies

    Args:
        workflow_info (dict): Workflow information with 'name' and 'filename'
        access_token (str): Authentication token

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Load the workflow json file
        workflow_name = workflow_info['name']
        workflow_filename = workflow_info['filename']

        logging.info(f"Starting import process for selected workflow: '{workflow_name}'")
        logging.debug(f"Using specific file: {workflow_filename}")

        # User: Clear workflow header
        print(f"📋 Workflow: {workflow_name}")

        workflows_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'workflows')

        # Handle filename=None case (layout dependency scenario)
        if workflow_filename is None:
            # Use file discovery to find the workflow file
            workflow_file_path = find_component_file_by_name(workflows_dir, workflow_name)
            if not workflow_file_path:
                error_msg = f"Workflow file not found for '{workflow_name}' in centralized directory."
                #logging.error(error_msg)
                print(f"❌ ERROR: {error_msg}")
                return False
            workflow_file = workflow_file_path
        else:
            # Use provided filename (batch impact scenario)
            workflow_file = os.path.join(workflows_dir, workflow_filename)

        # Error Handling: Check if workflow file exists
        if not os.path.exists(workflow_file):
            error_msg = f"Workflow file not found: {workflow_filename}"
            #logging.error(error_msg)
            print(f"❌ ERROR: {error_msg}")
            return False

        with open(workflow_file, 'r') as json_file:
            workflow_data = json.load(json_file)

        # Logging: Technical validation
        logging.debug(f"Loaded workflow data successfully for '{workflow_name}'")

        # Detect workflow type
        workflow_type = workflow_data.get("taskSet", {}).get('type', 'operation').lower()
        print(f"📋 Type: {workflow_type.upper()}")

        if workflow_type not in ['operation', 'provision']:
            error_msg = f"Invalid workflow type '{workflow_type}' for '{workflow_name}'. Supported types are 'operation' and 'provision'."
            #logging.error(error_msg)
            print(f"❌ ERROR: {error_msg}")
            return False

        # Logging: Workflow type detection
        logging.info(f"Detected workflow type: {workflow_type}")

        # Check if the workflow already exists
        workflow_description = workflow_data.get('taskSet', {}).get('description', '')
        logging.debug("Checking if workflow already exists...")

        if not workflow_description:
            print(f"❌ ERROR: Description is missing in workflow JSON for '{workflow_name}'.")
            return False

        existing_workflow = check_existing_workflow(workflow_name, access_token, workflow_description.strip())
        if existing_workflow:
            workflow_id = existing_workflow['id']
            logging.debug(f"Workflow '{workflow_name}' already exists with ID {workflow_id}. Reusing it...")
            print(f"✅ REUSE: Workflow '{workflow_name}' already exists with ID: {workflow_id}")
            print("\n" + "-" * 80 + "\n")  # Visual separator
            return True

        logging.debug(f"workflow '{workflow_name}' does not exist in the target instance. Proceeding to import it.")

        # Import dependencies
        success, subworkflow_id_map = import_workflow_dependencies(
            workflow_data, workflow_name, workflow_type, access_token
        )
        if not success:
            return False

        # Import Main workflow (Both operation and provision workflows)
        print(f"\n🎯 [5/5] Importing main workflow...")
        logging.info(f"Starting import of main workflow: {workflow_name}")

        # Pass the correct filename parameter based on discovery method
        actual_filename = workflow_filename if workflow_filename is not None else os.path.basename(workflow_file)
        status, message = import_workflow(
            workflow_name=workflow_name,
            access_token=access_token,
            workflow_filename=actual_filename
        )

        if status == "REUSE":
            print(f"  ✅ {workflow_name} (found in target instance)")
        elif status == "CREATED":
            print(f"  🆕 {workflow_name} (imported successfully)")
        elif status == "ERROR":
            #logging.error(f"Workflow import failed: {message}")
            print(f"❌ ERROR: {message}")
            return False
        else:
            error_msg = f"Unexpected result from import_workflow: {status}"
            #logging.error(error_msg)
            print(f"❌ ERROR: {error_msg}")
            return False

        print("\n✅ Workflow import completed successfully!")
        print("-" * 80 + "\n")
        return True

    except Exception as e:
        error_msg = f"An error occurred while processing workflow '{workflow_name}': {e}"
        #logging.error(error_msg)
        print(f"❌ ERROR: {error_msg}")
        return False

def import_layout_complete(layout_info, access_token):
    """
    Complete import process for one layout with all dependencies.
    Follows same pattern as import_workflow_dependencies for consistency.

    Args:
        layout_info (dict): Layout information with 'name' and 'filename'
        access_token (str): Authentication token

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Load the layout json file
        layout_name = layout_info['name']
        layout_filename = layout_info['filename']

        logging.info(f"Starting import process for selected layout: '{layout_name}'")
        logging.debug(f"Using specific file: {layout_filename}")

        # User: Clear layout header
        print(f"📋 Layout: {layout_name}")

        layouts_dir = os.path.join(os.path.dirname(__file__), '..', 'import', 'morpheus_configuration', 'layouts')
        layout_file = os.path.join(layouts_dir, layout_filename)

        # Error Handling: Check if layout file exists
        if not os.path.exists(layout_file):
            error_msg = f"Layout file not found: {layout_filename}"
            #logging.error(error_msg)
            print(f"❌ ERROR: {error_msg}")
            return False

        with open(layout_file, 'r') as json_file:
            layout_data = json.load(json_file)

        # Logging: Technical validation
        logging.debug(f"Loaded layout data successfully for '{layout_name}'")

        # Extract layout type (always layout but for consistency)
        print(f"📋 Type: LAYOUT")

        # Check if the layout already exists
        layout_description = layout_data.get('instanceTypeLayout', {}).get('description', '')
        logging.debug("Checking if layout already exists...")

        if not layout_description:
            print(f"❌ ERROR: Description is missing in layout JSON for '{layout_name}'.")
            return False

        existing_layout = check_existing_layout(layout_name, layout_description, access_token)
        if existing_layout:
            layout_id = existing_layout['id']
            logging.debug(f"Layout '{layout_name}' already exists with ID {layout_id}. Reusing it...")
            print(f"✅ REUSE: Layout '{layout_name}' already exists with ID: {layout_id}")
            print("\n" + "-" * 80 + "\n")  # Visual separator
            return True

        logging.debug(f"Layout '{layout_name}' does not exist in the target instance. Proceeding to import it.")

        # Import dependencies
        success, workflow_id, instance_type_id = import_layout_dependencies(
            layout_data, layout_name, access_token
        )
        if not success:
            return False

        # Handle case where workflow_id is None (bare-metal layouts)
        if workflow_id is None:
            logging.debug(f"Layout '{layout_name}' will be created without workflow (bare-metal deployment)")

        # Import Main layout
        print(f"\n🎯 [5/5] Importing main layout...")
        logging.info(f"Starting import of main layout: {layout_name}")

        status, message = import_layout(
            layout_name=layout_name,
            access_token=access_token,
            layout_filename=layout_filename,
            workflow_id=workflow_id, # Pass the resolved workflow ID
            instance_type_id=instance_type_id # Pass the resolved instance type ID
        )

        if status == "REUSE":
            print(f"  ✅ {layout_name} (found in target instance)")
        elif status == "CREATED":
            print(f"  🆕 {layout_name} (imported successfully)")
        elif status == "ERROR":
            #logging.error(f"Layout import failed: {message}")
            print(f"❌ ERROR: {message}")
            return False
        else:
            error_msg = f"Unexpected result from import_layout: {status}"
            #logging.error(error_msg)
            print(f"❌ ERROR: {error_msg}")
            return False

        print("\n✅ Layout import completed successfully!")
        print("-" * 80 + "\n")
        return True

    except Exception as e:
        error_msg = f"An error occurred while processing layout '{layout_name if 'layout_name' in locals() else 'unknown'}': {e}"
        #logging.error(error_msg)
        print(f"❌ ERROR: {error_msg}")
        return False

# =============================================================================
# 18. BATCH PROCESSING
# =============================================================================
def import_workflows_batch(selected_workflows, access_token):
    """
    Import multiple workflows in sequence with fail-fast on critical errors
    """
    total = len(selected_workflows)
    success_count = 0

    print(f"\n🔄 Starting import of {total} workflow(s)...")
    print("="*70)
    print("⚠️  IMPORTANT: Process will stop immediately on any critical error to protect your instance.")
    print("="*70)

    for i, workflow_info in enumerate(selected_workflows, 1):
        print(f"\n[{i}/{total}] Processing workflow: {workflow_info['name']}")
        print("-" * 50)

        try:
            result = import_workflow_complete(workflow_info, access_token)
            if result:
                success_count += 1
                print(f"✅ [{i}/{total}] Workflow '{workflow_info['name']}' completed successfully")
            else:
                # Critical Failure - stop immediately
                print(f"❌ [{i}/{total}] Workflow '{workflow_info['name']}' failed")
                print("\n" + "="*70)
                print("🛑 IMPORT STOPPED - Critical Error Detected")
                print("="*70)
                print(f"❌ Import process halted after workflow failure to protect your instance.")
                print(f"📊 PARTIAL RESULTS:")
                print(f"   • Workflows processed: {i}/{total}")
                print(f"   • Successful: {success_count}")
                print(f"   • Failed: 1 ('{workflow_info['name']}')")
                print(f"   • Not attempted: {total - i}")
                print("\n💡 Please resolve the error and run the import again.")
                return False
        except Exception as e:
                # Unexpected critical error - stop immediately
                print(f"❌ [{i}/{total}] Workflow '{workflow_info['name']}' encountered critical error")
                print("\n" + "="*70)
                print("🛑 IMPORT STOPPED - Critical Exception")
                print("="*70)
                print(f"❌ Critical error: {e}")
                print(f"📊 PARTIAL RESULTS:")
                print(f"   • Workflows processed: {i}/{total}")
                print(f"   • Successful: {success_count}")
                print(f"   • Failed: 1 ('{workflow_info['name']}')")
                print(f"   • Not attempted: {total - i}")
                print("\n💡 Please resolve the error and run the import again.")
                return False

    # All workflows completed successfully
    print("\n" + "="*70)
    print("🎉 ALL WORKFLOWS IMPORTED SUCCESSFULLY!")
    print("="*70)
    print(f"📊 FINAL RESULTS:")
    print(f"   • Total workflows: {total}")
    print(f"   • Successful: {success_count}")
    print(f"   • Failed: 0")
    print(f"\n✅ Your Morpheus instance has been successfully updated!")
    return True

def import_layouts_batch(selected_layouts, access_token):
    """
    Import multiple layouts in squence with fail-fast on critical errors
    """
    total = len(selected_layouts)
    success_count = 0

    print(f"\n🔄 Starting import of {total} layout(s)...")
    print("="*70)
    print("⚠️  IMPORTANT: Process will stop immediately on any critical error to protect your instance.")
    print("="*70)

    for i, layout_info in enumerate(selected_layouts, 1):
        print(f"\n[{i}/{total}] Processing layout: {layout_info['name']}")
        print("-" * 50)

        try:
            result = import_layout_complete(layout_info, access_token)
            if result:
                success_count += 1
                print(f"✅ [{i}/{total}] Layout '{layout_info['name']}' completed successfully")
            else:
                # Critical Failure - stop immediately
                print(f"❌ [{i}/{total}] Layout '{layout_info['name']}' failed")
                print("\n" + "="*70)
                print("🛑 IMPORT STOPPED - Critical Error Detected")
                print("="*70)
                print(f"❌ Import process halted after layout failure to protect your instance.")
                print(f"📊 PARTIAL RESULTS:")
                print(f"   • Layouts processed: {i}/{total}")
                print(f"   • Successful: {success_count}")
                print(f"   • Failed: 1 ('{layout_info['name']}')")
                print(f"   • Not attempted: {total - i}")
                print("\n💡 Please resolve the error and run the import again.")
                return False
        except Exception as e:
            # Unexpected critical error - stop immediately
            print(f"❌ [{i}/{total}] Layout '{layout_info['name']}' encountered critical error")
            print("\n" + "="*70)
            print("🛑 IMPORT STOPPED - Critical Exception")
            print("="*70)
            print(f"❌ Critical error: {e}")
            print(f"📊 PARTIAL RESULTS:")
            print(f"   • Layouts processed: {i}/{total}")
            print(f"   • Successful: {success_count}")
            print(f"   • Failed: 1 ('{layout_info['name']}')")
            print(f"   • Not attempted: {total - i}")
            print("\n💡 Please resolve the error and run the import again.")
            return False

    # All layouts completed successfully
    print("\n" + "="*70)
    print("🎉 ALL LAYOUTS IMPORTED SUCCESSFULLY!")
    print("="*70)
    print(f"📊 FINAL RESULTS:")
    print(f"   • Total layouts: {total}")
    print(f"   • Successful: {success_count}")
    print(f"   • Failed: 0")
    print(f"\n✅ Your Morpheus instance has been successfully updated!")
    return True

# =============================================================================
# 19. HIGH-LEVEL ORCHESTRATION
# =============================================================================
def handle_workflow_import(access_token):
    """
    Main workflow import orchestration
    """
    try:
        print("\n📂 Loading available workflows...")
        selected_workflows = get_workflow_selection()

        if selected_workflows is None:
            print("❌ No workflows available for import.")
            print("   Please ensure the 'import/morpheus_configuration/workflows' directory contains workflow files.")
            return "NO_FILES"

        if not selected_workflows:
            print("⏭️  Import cancelled by user.")
            return "CANCELLED"

        # Show what will be imported
        if len(selected_workflows) == 1:
            print(f"\n🎯 Selected workflow: {selected_workflows[0]['name']}")
        else:
            print(f"\n🎯 Selected {len(selected_workflows)} workflows for batch import:")
            for workflow in selected_workflows:
                print(f"   • {workflow['name']}")

        # Proceed with import
        success = import_workflows_batch(selected_workflows, access_token)
        return "SUCCESS" if success else "ERROR"
    except Exception as e:
        logging.error(f"Workflow import orchestration failed: {e}")
        return "ERROR"

def handle_layout_import(access_token):
    """
    Main layout import orchestration
    """
    try:
        print("\n📂 Loading available layouts...")
        selected_layouts = get_layout_selection()

        if selected_layouts is None:
            print("❌ No layouts available for import.")
            print("   Please ensure the 'import/morpheus_configuration/layouts' directory contains layout files.")
            return "NO_FILES"

        if not selected_layouts:
            print("⏭️  Import cancelled by user.")
            return "CANCELLED"

        # Show what will be imported
        if len(selected_layouts) == 1:
            print(f"\n🎯 Selected layout: {selected_layouts[0]['name']}")
        else:
            print(f"\n🎯 Selected {len(selected_layouts)} layouts for batch import:")
            for layout in selected_layouts:
                print(f"   • {layout['name']}")

        success = import_layouts_batch(selected_layouts, access_token)
        return "SUCCESS" if success else "ERROR"
    except Exception as e:
        logging.error(f"Layout import orchestration failed: {e}")
        #print(f"❌ Error: {e}")
        return "ERROR"
# =============================================================================
# 20. MAIN ORCHESTRATION
# =============================================================================
def main():
    """
    Main function to authenticate, list available workflows, and import the selected workflow.
    Prompts the user to select a workflow and imports it along with its associated option lists, input parameters, and tasks.
    """
    try:
        # Step 1: Authenticate and get the access token
        logging.info("Authenticating with Morpheus API...")
        access_token = Authenticate()
        logging.info("Access token received successfully")

        # Step 2: Get user choice for import type
        choice = get_import_type_choice()

        if not choice:
            #print("\n🛑 Import cancelled by user.")
            return

        # Step 3: Delegate to appropriate handler based on choice
        success = False

        if choice == '1':
            # Workflow Import
            logging.debug(" Calling handle_workflow_import method...")
            result = handle_workflow_import(access_token)
            if result == "SUCCESS":
                print("🎊 Workflow import process completed successfully!")
                success = True
            elif result in ["NO_FILES", "CANCELLED"]:
                success = True # These are not errors - clean exit
            else:
                print("❌ Workflow import process failed!")
                success = False

        elif choice == "2":
            # Layout Import
            logging.debug(" Calling handle_layout_import method...")
            result = handle_layout_import(access_token)
            if result == "SUCCESS":
                print("🎊 Layout import process completed successfully!")
                success = True
            elif result in ["NO_FILES", "CANCELLED"]:
                success = True # These are not errors - clean exit
            else:
                print("❌ Layout import process failed!")
                success = False

        # Step 4: Exit with appropriate status
        if not success:
            sys.exit(1)
    except Exception as err:
        logging.error(f"Unexpected error in Main function: {err}")
        print(f"❌ Critical error: {err}")
        sys.exit(1) # Exit with a non-zero status code to indicate failure


if __name__ == '__main__':
    main()
# Morpheus Component Import Script v2

The Morpheus Import Script v2 is a complete Python-based utility designed to streamline the integration of both **Workflows** and **Layouts** for automated SAP deployments into HPE Morpheus Enterprise. This version introduces a centralized structure approach, supporting hash-based filename discovery and automatic duplicate detection for both Operational and Provisioning components.

The script automatically checks whether Workflows, Layouts, or their dependencies already exist in the target instance by comparing key attributes such as name, description, field name, and code. If a matching component is found, it automatically reuses the existing one; otherwise, it creates a new resource. This approach prevents duplicates and maintains system organization.

**Key Capabilities:**
- **Workflows**: Imports operational and provisioning Workflows with Option Lists, Input Parameters, Tasks, and Sub-Workflows
- **Layouts**: Imports Layouts with Option Lists, Input Parameters, Workflows (with their Tasks, Sub-Workflows), and Instance Types
- **Centralized Structure**: Uses a unified `morpheus_configuration` directory with hash-based filenames
- **Automatic Discovery**: Automatically discovers existing components from directories
- **Batch Processing**: Supports importing multiple components or all components at once

The script provides complete error messages, detailed logging, and user-friendly interfaces to assist users in tracking progress and resolving issues during the import process.

---

## **Contents**
1. [Features](#features)
2. [Prerequisites](#prerequisites)
3. [Centralized File Structure](#centralized-file-structure)
4. [Usage](#usage)
5. [Component Import Process](#component-import-process)
6. [Workflow Import Process](#workflow-import-process)
7. [Layout Import Process](#layout-import-process)
8. [Hash-Based Filename Discovery](#hash-based-filename-discovery)
9. [Error Handling](#error-handling)
10. [Logging](#logging)
11. [Known Issues](#known-issues)
12. [Developer Notes](#developer-notes)

---

## **Features**

### **Component Support**
- Imports **Workflows** (operational and provisioning) with complete dependency resolution
- Imports **Layouts** with complete dependency resolution
- Handles Option Lists, Input Parameters, Tasks, and Sub-Workflows

### **Centralized Architecture**
- Uses centralized `morpheus_configuration` directory structure
- Hash-based filename discovery for components
- Automatic component name extraction from JSON metadata
- User-friendly display names with duplicate distinction

### **Import Capabilities**
- **Batch Processing**: Import all components or select specific ones
- **Dependency Resolution**: Automatically resolves and imports component dependencies
- **Conflict Detection**: Identifies and handles naming conflicts automatically
- **Duplicate Prevention**: Reuses existing components based on accurate matching criteria

### **User Experience**
- Interactive selection menus for Workflows and Layouts
- Progress tracking with detailed status messages
- Complete error reporting and troubleshooting guidance
- Multiple logging levels (ERROR, WARNING, INFO, DEBUG)

---

## **Prerequisites**
Before using this script, ensure the following:
1. **Package Setup**
   - Download the morpheus_import_package.zip to your local environment
   - Extract the package to access the centralized component structure
2. **Python Environment**
   - Ensure Python 3.10 or higher is installed on your system.
   - Ensure pip (Python package manager) is installed to manage dependencies
     Check if pip is installed using
     ```bash
     python3 -m pip --version
     ```
     If pip is not installed, follow the official pip installation guide: [`https://pip.pypa.io/en/stable/installation`](https://pip.pypa.io/en/stable/installation/)
3. **Configuration File**
   - A `config.json` file must be present in the **root project directory** (not in scripts folder).
   - The file should include the following keys:
     ```json
     {
         "morpheus_url": "https://your-morpheus-instance.com",
         "username": "your-username",
         "password": "your-password",
         "client_id": "morph-api",
         "client_secret": "",
         "ssl_cert_path": ""
     }
     ```
   - **Note**: The script looks for `config.json` in the parent directory of the scripts folder

   | Parameter | Description |
   |-----------|-------------|
   | `morpheus_url` | Full URL to your Morpheus instance (including port if needed) |
   | `username` | Morpheus username with import permissions |
   | `password` | User password |
   | `client_id` | OAuth client ID (default: `morph-api`) |
   | `client_secret` | OAuth client secret (usually empty) |
   | `ssl_cert_path` | Path to SSL certificate for self-signed certs (see below) |

   **SSL Certificate Configuration (`ssl_cert_path`):**
   | Value | Behavior |
   |-------|----------|
   | `""` (empty or missing) | SSL verification disabled |
   | `"cert.crt"` | Relative path (resolved from config.json location) |
   | `"C:\path\to\cert.crt"` | Absolute path to certificate file |
   
   **Note:** If a certificate path is specified but the file doesn't exist, the script will fail immediately with an error.

   **Security Note:** For production environments, avoid storing credentials in clear text. Use an external secret store, such as HashiCorp Vault for secure password storage.

4. **Import Directory**:
   - Ensure the `import` directory contains the centralized Morpheus configuration structure.

---

## **Centralized File Structure**
The script uses a centralized directory structure that organizes all Morpheus components in a unified hierarchy:

```
import/
└── morpheus_configuration/
    ├── inputs/
    │   ├── SAP_HANA_SID_f039e285.json
    │   ├── Morpheus_hostname_699cba36.json
    │   └── ...
    ├── option_lists/
    │   ├── SAP_sizing_options_7ddf1b03.json
    │   └── ...
    ├── tasks/
    │   ├── Install_HANA_DB_a8f3d219.json
    │   └── ...
    ├── subworkflows/
    │   ├── HANA_Database_Setup_b2c4e156.json
    │   └── ...
    ├── workflows/
    │   ├── SAP_HANA_Installation_d7e8a934.json
    │   └── ...
    ├── layouts/
    │   ├── SAP_HANA_Layout_c9f2d845.json
    │   └── ...
    └── instance_types/
        ├── SAP_Instance_Type_a1b2c3d4.json
        └── ...
```

**Key Structure Features:**
- **Hash-Based Filenames**: Components use hash-suffixed filenames for uniqueness
- **Centralized Organization**: All component types in dedicated subdirectories
- **Component Discovery**: Structure enables automatic component filename discovery

## **Usage**

1. **Run the script using Python**:
   - Navigate to the `scripts` folder
     ```bash
     cd scripts
     ```
   - Run the import script version 2:
     ```bash
     python3 import_script_v2.py
     ```

2. **Command-Line Options**:
   - `--error`: Default logging level - shows only errors
   - `--warning`: Shows warnings and errors
   - `--info`: Shows informational messages, warnings, and errors
   - `--debug`: Enables detailed debug-level logging with line numbers

   Example:
   ```bash
   python3 import_script_v2.py --debug
   ```

3. **Component Type Selection**:
   The script presents an interactive menu:
   ```
   🚀 MORPHEUS COMPONENT IMPORT TOOL v2
   ============================================================

   Select the type of import:
   1. Import Workflow(s) with Dependencies
   2. Import Layout(s) with Dependencies
   ```

4. **Component Selection Options**:
   - **Individual Selection**: Choose specific Workflows or Layouts by number
   - **Batch Import**: Select "Import all Workflows" or "Import all Layouts"
   - **User-Friendly Names**: Components display with distinguishing details for duplicates
   - **Dependency Preview**: View components that will be imported as dependencies

---

## **Component Import Process**
The script uses a unified import process for both Workflows and Layouts, with specific handling for each component type.

### **Common Import Steps**
1. **Authentication**: Authenticates with Morpheus API using OAuth2
2. **Component Discovery**: Scans centralized directories for available components
3. **User Selection**: Presents user-friendly component selection interface
4. **Dependency Analysis**: Analyzes selected components for required dependencies
5. **Conflict Detection**: Checks for existing components and potential conflicts
6. **Batch Processing**: Imports components and dependencies in correct order
7. **Status Reporting**: Provides detailed status for each imported component

### **Dependency Resolution Engine**
- **Task Dependencies**: Analyzes workflow task sets and conditional Sub-Workflows
- **Input Parameter Dependencies**: Resolves Option type references
- **Option List Dependencies**: Handles nested Option List requirements
- **Layout Dependencies**: Resolves Instance Types and Workflows
- **Recursive Analysis**: Follows dependency chains to ensure complete imports

---

## **Workflow Import Process**
Workflows are imported with comprehensive dependency resolution for both operational and provisioning types:

### **Workflow Analysis**
1. **Component Discovery**: Extracts workflow metadata from hash-based filename
2. **Dependency Mapping**: Analyzes taskSet structure for required components
3. **Conditional Task Detection**: Identifies Tasks that reference Sub-Workflows
4. **Recursive Dependencies**: Follows Sub-Workflow chains to map complete dependency tree

### **Dependency Import Order**
1. **Option Lists**:
   - **Precise Matching**: Compares name AND description for reuse detection
   - **Conflict Detection**: Stops on a name match with a different description
   - **Version Handling**: Creates new option list if name doesn't exist
   - **Handles option type list configurations**

2. **Input Parameters**:
   - **Precise Matching**: Compares name, fieldName, and description
   - **Conflict Detection**: Stops on a fieldName conflict with same name
   - **Version Handling**: Creates new Input if description differs
   - **Validation**: Ensures required fields (description, fieldName) are present

3. **Tasks**:
   - **Precise Matching**: Compares name AND Task code for reuse detection
   - **Conflict Detection**: Stops on a name match with a different Task code
   - **Version Handling**: Creates new Task if name doesn't exist
   - **Conditional Analysis**: Scans Task definitions for Sub-Workflow references

4. **Sub-Workflows** (Workflows called by other Workflows):
   - **Recursive Processing**: Imports Sub-Workflow dependencies first
   - **Precise Matching**: Uses same logic as main Workflows - compares name AND description
   - **Version Handling**: Creates new Sub-Workflow only if name doesn't exist
   - **Task Resolution**: Updates Conditional Tasks with Sub-Workflow IDs
   - **Nested Dependencies**: Handles multi-level Sub-Workflow hierarchies

5. **Main Workflow Creation**:
   - **Existing Check**: First checks if Workflow exists with same name AND description
   - **Reuse Logic**: If exact match found, reuses existing Workflow
   - **New Creation**: Creates a new Workflow only if name doesn't exist
   - **Final Assembly**: Links all resolved component IDs to Workflow structure
   - **Operational vs Provisioning**: Handles different Workflow types appropriately
   - **Task Set Configuration**: Orders Tasks in correct execution sequence

---

## **Layout Import Process**
Layouts are imported with comprehensive dependency resolution:

### **Layout Analysis**
1. **Metadata Extraction**: Reads Layout configuration from centralized directory
2. **Instance Type Resolution**: Maps to existing Instance Type or creates new ones
3. **Workflow Dependencies**: Analyses Provisioning Workflow requirements

### **Layout Component Import**
The Layout import process handles dependencies in the following order:

1. **Instance Type Resolution**:
   - **Advanced Matching**: Compares by name, code, and configuration
   - **Memory Conversion**: Converts bytes to MB for API compatibility
   - **Category Assignment**: Maps to appropriate instance type categories
   - **Versioning Support**: Handles multiple versions of instance types

2. **Option Lists**:
   - **Foundation Dependencies**: Imports Option Lists required by Input Parameters
   - **Name-Based Matching**: Reuses existing Option Lists by name comparison
   - **Dependency Analysis**: Automatically discovers Option List requirements from Input Parameters

3. **Input Parameters**:
   - **Precise Matching**: Compares name, fieldName, and description
   - **Conflict Detection**: Stops on a fieldName conflict with same name
   - **Layout Configuration**: Processes Input Parameters defined in Layout optionTypes

4. **Workflow Integration**:
   - **Provisioning Workflow**: Links Workflow to the associated Layout
   - **Name-Only Matching**: Uses Workflow name matching for Layout context
   - **Dependency Chain**: Ensures Workflow and all its dependencies are imported first
   - **Complete Import**: Uses Workflow complete import handler for full dependency resolution

5. **Main Layout Creation**:
   - **Existing Check**: First checks if the Layout exists with same name AND description
   - **Reuse Logic**: If an exact match is found, reuses existing Layout
   - **New Creation**: Creates new Layout only if name doesn't exist
   - **Final Assembly**: Links all resolved component references to Layout structure
   - **Instance Type Association**: Connects resolved Instance Types to Layout
   - **Workflow Linkage**: Associates Provisioning Workflow if specified

---

## **Hash-Based Filename Discovery**
The script uses automatic filename discovery to handle components with hash-based filenames:

### **Filename Pattern Recognition**
- **Hash Suffix Detection**: Recognizes patterns like `ComponentName_a1b2c3d4.json`
- **Sanitization Matching**: Converts component names like `"SAP HANA-DB (Setup)"` to match filenames like `"SAP_HANA_DB_Setup_a1b2c3d4.json"`
- **Multiple Patterns**: Supports various hash formats and lengths

### **Component Name Extraction**
- **JSON Metadata Reading**: Extracts original names from component JSON data
- **Display Name Generation**: Creates user-friendly names with distinguishing details
- **Duplicate Disambiguation**: Shows version, type, or description differences

### **Search Algorithm**
1. **Exact Match**: Attempts direct filename matching first
2. **Sanitized Search**: Converts search terms to sanitized format
3. **Pattern Matching**: Uses regex to identify hash-based filenames
4. **Metadata Verification**: Confirms component identity from JSON content

---

## **Error Handling**
The script includes complete error handling with automatic recovery options:

### **File System Errors**
1. **Missing Directories**:
   - Validates centralized directory structure exists
   - Provides clear guidance on required directory setup
   - **Resolution**: Perform fresh import if directories are missing

2. **Component File Discovery**:
   - Handles hash-based filename resolution failures
   - Reports components that cannot be located in centralized directories
   - Provides alternative search strategies for component discovery

### **Configuration Errors**
3. **Configuration Validation**:
   - Validates `config.json` presence in correct location (parent directory)
   - Checks JSON syntax and required configuration fields
   - Provides specific error messages for missing credentials

4. **API Authentication**:
   - Handles OAuth2 authentication failures with detailed error messages
   - Provides guidance on credential verification and API access
   - Includes SSL warning management for testing environments

### **Component Validation**
5. **Field Validation**:
   - **Required Fields**: Validates the presence of description, for Inputs, additionally validates the fieldName
   - **Workflow Validation**: Ensures workflow names and descriptions are present
   - **Layout Validation**: Validates layout metadata and structure
   - **Data Integrity**: Checks JSON structure and required component properties
   - **Format Validation**: Ensures proper data types and value formats

6. **Conflict Resolution**:
   - **Input Parameter Conflicts**: Same name with different fieldName
   - **Option List Conflicts**: Same name with different description
   - **Task Code Conflicts**: Same name with different task code
   - **Workflow Dependency Conflicts**: Layout import detects when required workflow exists with same name but different description
   - **Precise Error Reporting**: Shows exact field differences causing conflicts
   - **Resolution Guidance**: Provides specific steps to resolve conflicts

### **Import Process Errors**
7. **API Response Handling**:
   - **HTTP Status Codes**: Interprets and explains API error responses
   - **Rate Limiting**: Handles API rate limits with retry logic
   - **Pagination Errors**: Manages large dataset fetching issues

8. **Batch Processing**:
   - **Partial Failures**: Continues processing other components when individual items fail
   - **Rollback Information**: Provides guidance on handling partial import states
   - **Progress Tracking**: Shows detailed status of each component import attempt

---

## **Logging**
The script provides comprehensive logging with multiple levels and enhanced debugging:

### **Logging Levels**
- **ERROR (Default)**: Shows only critical errors that stop execution
- **WARNING**: Displays warnings about potential issues and errors
- **INFO**: Provides general progress information and status updates
- **DEBUG**: Enables detailed debugging with line numbers, API calls, and data structures

### **Log Format**
- **Standard Format**: `%(asctime)s - %(levelname)s - %(message)s`
- **Debug Format**: `%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s`
- **Timestamps**: All log entries include precise timestamps for tracking

### **Debug Features**
- **API Request/Response Logging**: Full HTTP request and response details
- **Data Structure Dumps**: JSON formatting of complex configuration data
- **Component Discovery Tracing**: Detailed file system search operations
- **Dependency Resolution Steps**: Step-by-step dependency analysis logging
- **Performance Tracking**: Timing information for import operations

### **Usage Examples**
```bash
# Standard operation (errors only)
python3 import_script_v2.py

# Development debugging
python3 import_script_v2.py --debug

# General progress tracking
python3 import_script_v2.py --info

# Issue investigation
python3 import_script_v2.py --warning
```

---

## **Developer Notes**

### **Configuration Management**
- **Config Location**: `config.json` must be in project root directory (parent of scripts/)
- **API Credentials**: Ensure valid Morpheus API URL, username, password, client_id, and client_secret
- **SSL Configuration**: Script disables SSL warnings for testing environments

### **Development Environment**
- **Python Version**: Requires Python 3.10+ for proper JSON and logging functionality
- **Dependencies**: Uses `requests` library for HTTP API communication
- **Future Features**: Encrypted configuration support prepared (commented code)

### **Script Architecture**
- **Modular Design**: Clear separation of concerns across functional modules
- **Error Handling**: Comprehensive exception handling with specific error types
- **Logging Integration**: Detailed debugging support with line-level tracing

### **Testing Considerations**
- **Component Isolation**: Test individual component imports before batch operations
- **Dependency Chains**: Verify complex workflow dependency resolution
- **Conflict Scenarios**: Test name collision and resolution scenarios
- **API Limits**: Consider Morpheus API rate limiting in test environments

### **Code Maintenance**
- **Hash-based Discovery**: Update filename patterns if format changes
- **API Compatibility**: Monitor Morpheus API version compatibility
- **Pagination Logic**: Verify large dataset handling with production data sizes
- **Memory Management**: Monitor memory usage with large configuration imports

### **Extension Points**
- **New Component Types**: Framework supports adding additional Morpheus component types
- **Custom Matching Logic**: Component matching algorithms can be enhanced
- **Batch Processing**: Import strategies can be customized for specific use cases
- **Reporting**: Status reporting and logging can be extended for integration needs

---

## **Known Issues**

### **Component Validation Requirements**
1. **Missing Descriptions**:
   - Input parameters and workflows require non-empty descriptions
   - Layout components require proper metadata for identification
   - **Resolution**: Extract the package again if component files appear modified

2. **Field Name Validation**:
   - Input parameters must have unique fieldName values
   - Empty or missing fieldName values cause import failures
   - **Resolution**: Extract the package again if component files appear modified

### **Conflict Resolution**
3. **Input Parameter Conflicts**:
   - Same name with different fieldName creates unresolvable conflicts
   - Script halts to prevent data corruption
   - **Resolution**:
     * Rename the existing input parameter in target Morpheus instance (e.g., 'Parameter Name Legacy')
     * Ensure fieldName consistency across components
     * Do NOT modify fieldName in import JSON as fieldNames are required for task dependencies

4. **Task Code Conflicts**:
   - Same task name with different code indicates version conflicts
   - Script stops to prevent execution errors
   - **Resolution**:
     * Review task definitions in target instance for consistency
     * Rename existing tasks if different functionality intended (e.g., 'Task Name Legacy')
     * Ensure consistent task implementations before import

### **Layout Import Limitations**
5. **Instance Type Dependencies**:
   - Layout import requires proper instance type resolution
   - Instance type CODE must be unique and cannot be changed
   - **Resolution**: Rename conflicting instance types in target system if needed

### **Data Source Dependencies**
6. **Configuration Source Dependency**:
   - Import requires properly structured configuration files with hash-based filenames
   - Hash-based filenames must match expected patterns
   - **Resolution**: Extract the package again if files are corrupted

7. **Directory Structure**:
   - Script expects specific centralized directory organization
   - Missing subdirectories cause component discovery failures
   - **Resolution**: Extract the package again if directory structure is incomplete
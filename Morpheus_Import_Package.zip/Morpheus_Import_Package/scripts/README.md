# Import Script for Morpheus Workflows

The Import Script is a Python-based utility designed to simplify the integration of operational and provisioning workflows into the HPE Morpheus Enterprise platform. By automating the import process, the script ensures consistency, reduces manual effort, and prevents duplication by detecting and reusing existing tasks and workflows.

The script checks whether a workflow or its dependencies already exist in the target instance by comparing key attributes such as name, description, field name, and code. If a matching item is found, it reuses the existing one; otherwise, it creates a new resource. This approach prevents duplicates and keeps the system organized.

For operational workflows, the script imports option lists, input parameters, tasks, and sub-workflows. For provisioning workflows, it focuses on importing tasks and sub-workflows, efficiently handling different workflow types to cater to diverse use cases.

Additionally, the script provides detailed error messages and user-friendly logging to assist users in tracking progress and resolving issues during the import process.

---

## **Contents**
1. [Features](#features)
2. [Prerequisites](#prerequisites)
3. [Project File-System Structure](#project-file-system-structure)
4. [Usage](#usage)
5. [Workflow Import Process](#workflow-import-process)
6. [Error Handling](#error-handling)
7. [Logging](#logging)
8. [Known Issues](#known-issues)
9. [Developer Notes](#developer-notes)
10. [License](#license)

---

## **Features**
- Imports workflows, input parameters, option lists, tasks, and sub-workflows into Morpheus.
- Supports both **operational** and **provisional** workflow types.
- Automatically resolves dependencies for tasks and sub-workflows.
- Reuses existing components (e.g., input parameters, option lists, tasks, sub-workflows, workflows).
- Provides detailed error messages for troubleshooting.
- Centralized logging for debugging and tracking progress.
- Supports importing all workflows at once or selecting specific workflow.

---

## **Prerequisites**
Before using this script, ensure the following:
1. **Python Environment**
   - Ensure Python 3.10 or higher is installed on your system.
   - Ensure pip (python package manager) is installed to manage dependecies
     check if pip is installed using
     ```bash
     python -m pip --version
     ```
     if pip is not installed, follow the official pip installation guide: [`https://pip.pypa.io/en/stable/installation`](https://pip.pypa.io/en/stable/installation/)
2. **Configuration File**
   - A `config.json` file must be present in the `scripts` directory.
   - The file should include the following keys:
     ```json
     {
         "morpheus_url": "<Morpheus API URL>",
         "username": "<Morpheus Username>",
         "password": "<Morpheus Password>",
         "client_id": "<Morpheus Client ID>",
         "client_secret": "<Morpheus Client Secret>"
     }
     ```
3. **Import Directory**:
   - Ensure the `import` directory contains the workflow configurations to be imported.
   - The directory structure should look like this:
     ```
     import/
     ├── Workflow1/
     │   ├── workflow_Workflow1_import.json
     │   ├── options/
     │   ├── input_parameters/
     │   ├── tasks/
     │   └── subworkflows/
     ├── Workflow2/
     │   ├── workflow_Workflow2_import.json
     │   ├── options/
     │   ├── input_parameters/
     │   ├── tasks/
     │   └── subworkflows/
     ```
---

## **Usage**
1. **Run the script using Python**:
   - Navigate to the `scripts` folder
     ```bash
     cd scripts
     ```
   - Run the import script:
     ```bash
     python import_script.py
     ```

2. **Command-Line Options**:
   - `--debug`: Enables detailed debug-level logging.
   - `--info`: Enables information logging.

   Example:
   ```bash
   python import_script.py --debug
   ```

3. **Workflow Selection**:
   - The script lists all available workflows in the import directory
   - you can:
      - select a specific workflow by entering its number.
      - select "All Workflows" to import all workflows at once.

---

## **Workflow Import Process**
The script follows these steps for each workflow:
1. **Check if Workflow Exists**:
   - if the workflow already exists with a matching name and description, it is reused.
   - if the description differs, the workflows is treated as a new version.
2. **Import Option Lists**:
   - If the Option list already exists with a matching name, it is reused.
   - if the name differs, the Option list is treated as a new and imported.
3. **Import Input Parameters**:
   - If the input parameter exists with a matching name, fieldName and description, it is reused.
   - if the name matches, fieldName differs, it is a conflict, and the script stops executing further imports until the issue is resolved.
   - if the name and fieldName match but the description differs, the input is treated as a new version and imported.
4. **Import Sub-Workflows**:
   - If the task is a conditional task, the script will start importing the sub-workflows.
   - sub-workflows and their tasks are imported recursively.
   - If the sub-workflow exists with a matching name and description, it is reused.
   - If the description differs, it is created as a new one.
5. **Import Tasks**:
   - If the Task exists with a matching name and code, it is reused.
   - If the name matches but the code differs, it is a conflict, and the script stops executing further imports until the issue is resolved.
6. **Import Workflow**:
   - Finally, the workflow is imported into Morpheus.

---

## **Error Handling**
The script includes robust error handling:
1. **File Not Found**:
   - If a required file (e.g., workflow JSON, input parameter JSON) is missing, the script stops and logs an error.
2. **Field Validation**:
   - Missing or empty fields (e.g., description, fieldName) are flagged as errors, and the script stops execution.
3. **Conflicts**:
   - Name conflicts (e.g., input parameters with the same name but different fieldName) are logged, and the script stops execution until the issue is resolved.
4. **Unexpected Errors**:
   - Any unexpected errors are logged, and the script exists with a non-zero status code.

---

## **Logging**
The script uses Python's logging module for detailed logs:

- Logs are displayed in the console and include timestamps, log levels, and messages.
- Log Levels:
   * DEBUG: Provides detailed logs for debugging purposes.
   * INFO: Provides general informational messages.
   * ERROR: Logs critical errors that stop the script.

---

## **Developer Notes**

- Ensure the `config.json` file is updated with valid Morpheus API details.
- The `ìmport` folder must contain sanitized workflow folders with all necessary files.
- For any changes to the script, ensure proper testing before deployment.

---

## **Known Issues**
1. **Empty Descriptions**:
   - Workflows or Input parameters with empty descriptions cannot be imported.
   - Ensure all descriptions are populated before running the script.
2. **Name Conflicts**:
   - Input parameters with the same name but different fieldName cause conflicts.
   - Tasks with the same name but different code cause conflicts.
   - **Resolution**:
     - Manually update the conflicting input parameters or tasks in the `import directory` or in the `Morpheus Instance` to ensure unique names or matching configurations.
     - Re-run the script after resolving the conflicts.

---

## **License**
# Morpheus Component Import Automation v2

This project provides an easy-to-use Python script to automate the import of **Workflows** and **Layouts** with their complete dependencies for automated SAP installation into the HPE Morpheus Enterprise platform. The script uses a centralized architecture with automatic component discovery and hash-based filename management to ensure efficient, smooth integration.

**Supported Components:**
- **Workflows** (Operational and Provisioning) with Option Lists, Input Parameters, Tasks, and Sub-Workflows
- **Layouts** with Instance Types, Option Lists, Input Parameters, and associated Workflows
- **Foundation Components**: Option Lists, Input Parameters, Tasks, Sub-Workflows, Instance Types

The script automatically detects existing components, prevents duplicates through automatic matching, and handles complex dependency relationships to ensure complete and accurate imports.

---

## **Contents**
1. [Project Overview](#project-overview)
2. [Project File-System Structure](#project-file-system-structure)
3. [Setup](#setup)
4. [Usage](#usage)
5. [Support](#support)

---

## **Project Overview**
This project includes the following components for importing automation for SAP into HPE Morpheus Enterprise:

1. **`config.json`**:
   - Configuration file containing Morpheus API connection details (URL, credentials, client authentication)
   - Located in the project root directory for centralized configuration management

2. **`scripts/`**:
   - Contains `import_script_v2.py` - the main script for importing Workflows and Layouts
   - Includes complete dependency resolution and automatic component matching
   - Supports batch processing and interactive component selection

3. **`import/`**:
   - Contains centralized `morpheus_configuration` directory structure
   - Organized by component type with hash-based filenames for uniqueness
   - Contains pre-configured Morpheus components ready for import

---

## **Project File-System Structure**
The project uses a centralized architecture designed for component discovery and management:

```
project-root/
├── config.json                    # Morpheus API configuration
├── scripts/
│   ├── import_script_v2.py        # Main import script with workflow and layout support
│   └── README.md                  # Detailed import script documentation
└── import/
    └── morpheus_configuration/     # Centralized component structure
        ├── inputs/                 # Input Parameters with hash-based filenames
        │   ├── SAP_HANA_SID_f039e285.json
        │   ├── Morpheus_hostname_699cba36.json
        │   └── ...
        ├── option_lists/           # Option Lists for dropdown configurations
        │   ├── SAP_sizing_options_7ddf1b03.json
        │   └── ...
        ├── tasks/                  # Individual task definitions
        │   ├── Install_HANA_DB_a8f3d219.json
        │   └── ...
        ├── subworkflows/           # Sub-workflow components
        │   ├── HANA_Database_Setup_b2c4e156.json
        │   └── ...
        ├── workflows/              # Main workflow definitions
        │   ├── SAP_HANA_Installation_d7e8a934.json
        │   └── ...
        ├── layouts/                # Instance layout configurations
        │   ├── SAP_HANA_Layout_c9f2d845.json
        │   └── ...
        └── instance_types/         # Instance type definitions
            ├── SAP_Instance_Type_a1b2c3d4.json
            └── ...
```

**Key Structure Features:**
- **Hash-Based Filenames**: Each component uses content-based hash suffixes for uniqueness
- **Component Separation**: Each type organized in dedicated directories
- **Centralized Management**: Single configuration hierarchy for all components
- **Component Discovery**: Structure enables automatic component filename discovery

### **Component Types Explained:**
- **`inputs/`** - Input Parameter definitions with fieldName and description validation
- **`option_lists/`** - Option List configurations for dropdown menus
- **`tasks/`** - Individual task definitions with code and script content
- **`subworkflows/`** - Sub-Workflow components for conditional execution
- **`workflows/`** - Main Workflow definitions (operational and provisioning)
- **`layouts/`** - Instance layout configurations with provisioning Workflows
- **`instance_types/`** - Instance type definitions with resource specifications

### **Automatic Dependency Management:**
- The import script automatically discovers and resolves component dependencies
- Hash-based filenames enable accurate component identification and versioning
- Automatic matching prevents duplicates while supporting component updates

---

## **Setup**

### **Prerequisites**
- Python 3.10 or higher
- pip (Python package manager) - check if installed using:
  ```bash
  python3 -m pip --version
  ```
  If pip is not installed, follow the official guide: [`https://pip.pypa.io/en/stable/installation`](https://pip.pypa.io/en/stable/installation/)
- Required Python packages: `requests` (for HTTP API communication)
- Valid Morpheus API credentials with import permissions
- Pre-configured Morpheus component files in the import directory structure

### **Configuration**
1. Download the morpheus_import_package.zip to your local environment
2. Update the `config.json` file in the project root with your Morpheus API details:
   ```json
   {
       "morpheus_url": "https://your-morpheus-instance.com",
       "username": "your-username",
       "password": "your-password",
       "client_id": "morph-api",
       "client_secret": "",
       "ssl_cert_path": ""
   }
   ```

   | Parameter | Description |
   |-----------|-------------|
   | `morpheus_url` | Full URL to your Morpheus instance (including port if needed) |
   | `username` | Morpheus username with import permissions |
   | `password` | User password |
   | `client_id` | OAuth client ID (default: `morph-api`) |
   | `client_secret` | OAuth client secret (usually empty) |
   | `ssl_cert_path` | Path to SSL certificate for self-signed certs (see below) |

   **SSL Certificate Configuration (`ssl_cert_path`):**
   | Value | Behavior |
   |-------|----------|
   | `""` (empty or missing) | SSL verification disabled |
   | `"cert.crt"` | Relative path (resolved from config.json location) |
   | `"C:\path\to\cert.crt"` | Absolute path to certificate file |
   
   **Note:** If a certificate path is specified but the file doesn't exist, the script will fail immediately with an error.

   **Security Note:** For production environments, avoid storing credentials in clear text. Use an external secret store, such as HashiCorp Vault for secure password storage.

3. Ensure the `import/morpheus_configuration/` directory contains the components to import
4. Verify directory structure matches the centralized format described above

---

## **Usage**

### **Running the Import Script**
1. Navigate to the `scripts` directory:
   ```bash
   cd scripts
   ```
2. Execute the import script:
   ```bash
   python3 import_script_v2.py
   ```
3. Follow the interactive menu to select import type (Workflows or Layouts)
4. Choose specific components or batch import options

### **Import Capabilities**
- **Workflow Import**: Imports operational and provisioning Workflows with complete dependency resolution
- **Layout Import**: Imports Layouts with Instance Types, Workflows, and configuration dependencies
- **Dependency Management**: Automatically resolves and imports Option Lists, Input Parameters, Tasks, and Sub-Workflows
- **Conflict Resolution**: Automatic detection and handling of naming conflicts
- **Progress Tracking**: Real-time status updates and detailed logging

### **Detailed Documentation**
Refer to [`scripts/README.md`](scripts/README.md) for comprehensive documentation including:
- **Prerequisites**: Environment setup and dependency requirements
- **Command-Line Options**: Logging levels and debug capabilities
- **Component Import Process**: Step-by-step Workflow and Layout import procedures
- **Error Handling**: Troubleshooting and conflict resolution guidance
- **Hash-Based Filename Discovery**: Component identification and versioning system

---

## **Support**
If you encounter any issues or have questions, please post an issue on GitHub: [GitHub Issues](https://github.com/HewlettPackard/morpheus-sap-install/issues)
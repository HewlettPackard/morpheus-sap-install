# Morphues Workflow Automation

This Project provides tools to automate the import of workflows, option lists, input parameters, tasks, and sub-workflows into the Morpheus platform. It is designed to handle both new imports and reusing existing components, ensuring efficient and conflict-free integration.

---

## **Contents**
1. [Project Overview](#project-overview)
2. [Project File-System Structure](#project-file-system-structure)
3. [Guidelines for Maintaining the File-System](#guidelines-for-maintaining-the-file-system)
4. [Setup](#setup)
5. [Usage](#usage)
6. [Support](#support)

---

## **Project Overview**
This project includes the following files and folders:
1. **`config.json`**:
   - A configuration file where you need to provide your Morpheus API details(e.g., URL, username, password).
2. **`scripts/`**:
   - Contains the `import_script.py`, which is the main script for importing workflows and their dependencies into Morpheus.
3. **`import/`**:
   - Contains sanitized workflow folders with all the necessary files for importing workflows into Morpheus.

---

## **Project File-System Structure**
The project is organized as follows:
   ```
   project-root/
   ├── scripts/
   │   └── import_script.py       # Main script for importing workflows
   ├── import/                    # Directory containing workflow configurations
   │   ├── Workflow1/
   │   │   ├── workflow_Workflow1_import.json
   │   │   ├── options/
   │   │   ├── input_parameters/
   │   │   ├── tasks/
   │   │   └── subworkflows/
   │   ├── Workflow2/
   │   │   ├── workflow_Workflow2_import.json
   │   │   ├── options/
   │   │   ├── input_parameters/
   │   │   ├── tasks/
   │   │   └── subworkflows/
   └── config.json # Configuration file with Morpheus API details
   ```

---

## **Guidelines for Maintaining the File-System**
1. **`scripts/` Directory**:
   - Contains the `import_script.py`, which is responsible for importing workflows.
   - Do not modify the `config.json` structure.

2. **`import`/ Directory**:
   - Each workflow should have its own subdirectory (e.g., `Workflow1`, `Workflow2`).
   - Each subdirectory must include:
      * `workflow_<workflow_name>_import.json`: The main workflow configuration file.
      * `options/`: Directory for option list files (if any).
      * `input_parameters/`: Directory for input parameter files (if any).
      * `tasks/`: Directory for task files.
      * `subworkflows/`: Directory for sub-workflows files (if any).

3. **`config.json` File**:
   - Ensure the `config.json` file is updated with valid Morpheus API details before running the script.

---

## **Setup**
1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd <repository-directory>
   ```
2. Update the `config.json` file with your Morpheus API details.

---

## **Usage**
Refer to the [`scripts/README.md`](scripts/README.md) file for detailed instructions on running the import script. Specifically, see the following sections:
1. **Prerequisites**:
   - To ensure your environment is set up correctly before running the script.
2. **Usage**:
   - For step-by-step instructions on how to run the script, including command-line options and workflow selection.

---

## **Support**
If you encounter any issues or have questions, please contact our support team.


